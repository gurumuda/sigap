<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqRXPBMsJ5sxJr7nbb/sJUsqybo9PWxUOBYuTvoqSXuIMphgMetONYb0o1OG+zAswlak4Hes
iQSMz9SD42u6BLb27U1vqf6EtJHhVpEvNfbvGlrSZginArp4KcMSn/deEsM2UAVALCb9vKQHnhum
ymfX8+BeGRLPZeldcM42+2QCKl0hbyJlfwbSIG6XYxseW8PyMaiLsMmFy6yvitmsx9QE9JNjpMSY
sJCO6wZfNeyLTjkErAHX0HJhNRjv/XgTWDvuGhWqwyhvSKBwmrKh6lp+lHPhLuzasln4wWGiNIHL
Ej9H/+SF2YtkaXvDtqvZKv4Z86km75Am4xQLZzDn7JL/RZzreZ9taLBtAyIzY6EGsSEvK4pIGuB2
TA1axTp9TFqsyopr4jTlOM5CO6RHUP+WZCSRWh0hYNsyCRLIj4fo8+4150Jp6m8OUZJjURuHGsD5
EsITehIeHc1u82ztvz1+Tzjcdd/1pNPNEZ/4pVOUobZ2ir+NXGJ/uXolXkEMlA0ra17cUdHzsn9i
yvgwV6DG5hXjHHQ4Fr9OSCjr5OY9lw/AOqQormFyAnyhCxUbO6B3wZiYGVtWC559vTh03wx3+VDi
ILzoVxgnHM7DpxyA30eUtk708SUTqihfBa7svqy/dWvbJikYEUnCtXHR1bIeBs/hfXenqKC87h1L
JVgT3uBYstTXm6BK2X7maQL6Cnq3WjFTJbAnKiDAK8Rq2tJhXhkjHyLMwn0DOI5mE51gEeW2FRbp
X8qS9Q/77wi2lKK5rHoqPLS5BxwEaLX+hV5PYMnAMVGx5adO21jR8hkVEjrI1PP9fbpiBsbypfPk
/z5Qn+sk7H5WGo8rlO/SQa5SAB+SvKPQG0JLGPzNKIXC8V/X3ou3nA7F1xKULw7JixPYg794Rl82
eXuEQTyzdUAOu+v7Uhd6wI7E1yqUqYbCeQaE5bY7SURU5/3ac8WH6YZ70Gzoeg1b/qsovIAv8t+q
O/U8D76FjNQzO7H2rUyKrKqbk0ybk6hnyVaG39W1LGWIYUQX3imlW3CT1UOV3o1Gs8vh5q+R8s/1
XjH9i73g4ZuaTcjBVu8kSPoyvrDEwuIRy/WzrV8+oxRa1p4gzdZysrPSLsCUIBbCfghG2DKQwQhv
tac3vyT9IWBjoJ9Dv827OOhS9w0viwRG5v7mBDuHiALhjiixffzUX21EbS8dtVOe/AWCAzQSQiRw
L/BK5779Re8Y5FVi14/TIfxJcrAOpgKDEpBrHVkQ7LJVlt5XIhKxYTzDfyUPd2Nf3LwrIXMkdnaq
RR9v2RaLoeIHbv+xUEU3aeJvMKyGouFCWuXo2ZeqNvTvdLol0eKa6AriBKLu2RAIJatTvSXhRjGn
KOnL2AJlzLLMxzdmM/XUaxuBDUasJFxUr5JSxVwSVOoBKj6GTDrzs1JxQ4gnHx1EbMWf0BXChz1I
mvrPk4FItwHOQNZRHeS58IKnRvDMkXWHdPy6GNbVZE/M6hVKGkl7+41+UIWD/XuwlnxyauSnYGgv
O7kXKbkN36JUr6Ry5j6Si6ON307aBH7izNu7EF2IHmn0ypMhMQp2auAjcd+JxeG/EqkoOEvBcLCr
hf2ZZAEoangeIj7JfrNduUlIXBAmmaa3OGp2LMGikrxzpgQxPKlcoVrctm80cT1zIe7JwKhDvp25
Zx1L+5c8tuZCqzZCl62JjdSaiQ6u4+ds3KEJpg/9n7VJ+INDbCICFzzikmMALftr3UvjSypdbuuh
0fylYuzuNdYcolhvppS6jw9k3kUbzOxbnIfUiJLpDQEI/5NAPqpZSSoQLwy5lHIqZojc99crQZik
e/NvtTrSEu/VI6IO627I2apD6dwgn4VbfmwlOE+e7B4uT+uT1QbwYXZ7MhcOxmjuaf+tgTFLOGjN
AXsuTrofPBFHV+EZxSYwdNmFuplEN60xGMadjl5nWPYDNPEhRdDnuiECXx82fwtryWQrV4Cxr2BJ
tsr/laE9Phco3LPJUhdcpXFro955tqe96x4PQQU1U1110exxjDO7z40RUoANi//NoCk5Yr6ZGIWx
0B+/SiJgqMHOnn0vPfCpkBeoL3LL4BspzkX8gvI2FaA6m+FrQ0bsWNqqratxr5uqlf21QNSZBF/M
2EveHE4VzODmhwRtkrqHQ4olHktmm5h2GqiwkNB4el3vvAr8MZykqXLeK7qaxTe9/x9MZ6YHR6om
TF6eQPhoERBGgmGbED9fdKDy4ha+NpK97/Zd3c2Q9FG2f1L09Olj7AZ6sWceN53i8GF0OOv9trd0
GYby0Yha2pGuK8/7tRpPM1PWq6gdBdFLr5vcMw6eaY4tpydlA55JBvy3rbc53ci+G213OvwtXrY3
rsqO6QNEKISbxNKnGTJ4J70UJk0nMFEilkI3KtKELF8vo6PGz2KuK61e7MOtCvOLMq4t8fp5aU/f
WIV32jqLdpqQyUpPRE8pITyx5PZEZTnv7e3cT2PKS55z0B+wxpj8hSnyM7Wp0jXAiGcw6h0YluxW
PA7eDJde