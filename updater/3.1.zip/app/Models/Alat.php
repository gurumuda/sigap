<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsYGX5YqU7sVGIKHUxbiVshka0JgtZHiUuAuOCSHStbgaiJ0L84M4fO6wjvlXx1icdogMSUr
QYSaqCDF81p7YPp9XUlR3jmVn5Ceb8Lo46qeyvHLSQQa+4veQ/DJuEkZICuPXtk24vA+8QtQdNrA
R2ebMWgaZ12jL7v8zSq9Z5zd1jL3SsBCL1YJnHdclZtd+GuDpVQgdBAMWJNOUjn2B81n2AfQzwI+
W53s8aVWEAHdEH8fFODCpASeJj34ApyDaXSLGhWqwyhvSKBwmrKh6lp+lHvdxeDGtcIHxYDWxoHL
Ez8O/veOMlljoGbOsZ01Gvdw1D4i4tMQSHw0qd+l8yCYlLjsft3F2PE5R7621Gof4XpjZeTt4X7p
KjkDetMqcB7UhP/yK96qzx6yD/9ErmYgYKS8EKHNtmS4G0/AA7xgYk7QQeYzOpAIftTn4dxyuMZJ
OGI/GARKBGeMfVX1rkwKf41gKhg4b0xzeEJDJZ2RWXHLZWLLkjIjl0qgn2PZXyNdA8PC0vJOKKOA
oVaRuCQggGkMsSjL3Hsvs8x7T665I7kjL1l5cVH8Wu7fcjO4aqOz+y9YAwWleLFB6oQQIch2dQ1r
vPqhYsmbqsB23NF+ZJw4a5A8jydMWPBuQzMXNVw6UdV/mkVG1fsERzqp9kAuIjz+IUAcEu3chkba
MetHvUlH8gwc0i2YElo0Ikx7wXhq6V1onWTtJ0WIgMqns7H50aG/wWzGArFZesY1eDQy0BTJRum6
qV8tUXh2YJWeWjQo3N3S1awUPaG6KjMlzroeX/c1undabXot547nYzsY6FcsIBzrQpRuCtrJ6C9r
j8fj//oWN26mzL2Bxh8VyKVJv4Oh/hBWQ2b+OEUlO15pTCIJZCVHhZdZgiqRdy3cyEXV5KApAFiT
fE+AcfBIdcUFrUs2lOfHk+xfmrUFu0ZQczalyNtMWXgf4uSs0IcO6FTHtcmP+VUQe4mldyWsPrj8
7SUHCt9sHCuOIJuJOU0plizljnOnKbJkqsqkHR80SXtvH/dTZEfVcyOooY5Bz1niAqu0IXAqE3Qw
rKitVWFXsrUCzO2i7MhHQqWhndkpERTD2Ac8seuE89vgeTVJRh+b6vxiYbkP0KhoOJdBIspAL8tM
mVIqtRsJKdICBUVOwdW7Irf49PUhDzDE/FTf5VmVWbJJZkhvJUOu+U/YfUsxqYzdfHICPC/rISUf
mjj/TQrwWizNH8StMVzpPnnUkWzDhTiQa2EJ0yfKqM53FxmXYohZqf1uP2uT66eJmkCTsTny8y4h
HXhn64rVlwFMTKT6xENA5SIaHDZ8HXfzUVJCye1TZd8KdIj+OXiOhOmQ4DLxzhqZ3nSzb79FOooL
s/H1hWUIEuzj3ctbis/wCdcN/pjtbRfJp7eYeZutv5U702Y033U5lNYATljuBghrdS/y5c/NzaRK
tRTk92th7BUDNNku/Gs6nEaaXZGqde8D9dxsvA4AKcyxnoHJBJg1mosUb3cE8EgOM+Q95TNS0S4b
I8svR71EgRNH8YK=