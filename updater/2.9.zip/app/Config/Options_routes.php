<?php

use CodeIgniter\Router\RouteCollection;

/**
 * route ini dapat diubah
 * contoh penggunaan kirim jadwal harian ke guru
 * sesuaikan dengan request pada cronjob atau http request whatsapp api
 * gunakan teks unik
 * contoh perubahan : $routes->get('/antrianjadwalsigap', 'Home::tambahAntrianJadwal');
 * kemudian bisa diakses dengan alamat https://alamatsigap.com/antrianjadwalsigap
 */
$routes->get('/antriJadwal', 'Home::tambahAntrianJadwal');
$routes->get('/antriIjin', 'Home::kirimIjinSiswaKeGuru');
// NOTE - onDev
$routes->post('api/rfid', 'Api\Rfid::postIndex');
$routes->get('api/rfid', 'Api\Rfid::getStatus');
