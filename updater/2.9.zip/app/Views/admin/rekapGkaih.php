<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnITQuLBJL2h4b7+ff7185PPBQc93OHYRCQNQG3TIc3Ox0B+wIC8kJ4nARHeVw1QfhsKA6TM
+ju1O3DsAZxiXdblneqTvxWHxaYPhu8VxHuS/XXYSLtx5u1/9uEN+9s17jw9WjpE3tjaW3jjny5N
YjoSBcoXtBTH8q7KZabCbjHcYl8nS7grcMqomWvVGcBOwh8pQGNUo1t3S832Zw6QirXvBefng6AH
5O9QpnZygxVJBe4Wt68xlFSdpKhFmPMy7qEM+JtSxJ9t6W+9nIwEAo0Iy6qLPz3yfpDekQCQWqSc
pSU79BIG5QcsFGGz/GoCBnhWhuuP6Ad5usy6kIDMMnfFBTh9hn+U6Q4IXvE9B3hS46vVDv+MrDHd
+FEwA3WoI3hYOwqZ94gE3YkIthu4CcVRxq1Gluf+h8clA48zvPA2hHW1Nr6M3X/bfTRybm5KLC43
oUmXwEqtLgCgQ5V/dMHMbevg9rBAZ5ne3jStn04RIL4iuyx31nz8HC/j+TlD75K9o4OvPykmZ2gc
UsaqH/8gFj1g3GQykIY4udnApZwzJSBZ0NSAiR0VDQf78Sh+C8w7CQKTSUKEd0d43DFBOaV4rrl4
CaHCDmo40p5YsGu32gpUV+r8k4gtXhTqGYDJmY3Z6QvvkYrWEr9OQNa55TG25trt+S4GTM9/Pmzn
3rRVUv7ft8K4UDl82Vkbw6cYmGW62QcUfyaDRSrEcpBeL5MIWfreW0aXm/Afr5q4zMob+qY1FrbU
dKSipoawc0udbJ3K/vT05OY88Xi9MmYfPK4i6a71pU07fd7SZMFaymUHjnwPXBlqIAteYIlhq4fJ
cl3u5GhWQNFoKW8GsKHQKXGcgG6N5C9sm4GJN6IKafYlEqRX3U733QlBsLGgGG1HVr2fODLG3cOu
VOhzVBLOzrRxlBGmlI405ESeZ06q40s5fZ9ywn8IHApAjON2fAqOL2DgFHVYtI2BPDiraX1nJu6s
A83BuR+9JEK6Ft9DumHWaNv9o4WrEqfHstyo5ifjh5+yPDn758/Hty6U8jW+xMfRrlpVbklt4kkG
r4sIx3FQngndqp6FdHr5/Fw4iHeDBfSJrqCDnn424YkIt56nl/vpG+3yM+FyYcVcv+FJ8CHgYDd4
y9SfgDrApCdOJAkK1aFARXbdY1VvvI9sbat8SjacDrgBkaRjYAWVp9xRmFWCKrZOfCgMPHo3znsk
+8qt3SFU0UXP9uDHlP8WKCsBeS/ANKqI7QwbHBYm/5fFAQppbg04sJDhTPoNrYRa8NKRpQ/zOCO8
jhoCoC7XukUczNGQOXECs/GKYJsleQdpmSH0W+OJODlT2taBFvUVvZhjIFy91ofCpz6gSzNJfwtU
iz+SWgQq2iV2/Bui08n+zTBNz1GCdhgMi+WCQL/k8gg/lCLdYYWN+EUtoF8lGdYWILSLYwSJbhZ6
jtYBQHB1ZAHo1qvBst0GEuwxjvdLR+MNq01MXffrsAWl8F+86PsStRZmxgMk8Il3PqB77C4sHo/R
Ea5tUjLufTZqDsWm7KVsKM4qq0kFkuIMe9CdVL7vS3Zsvt5BkQn27KrrUuPBEN+EGRvJJcZRlBKb
6GhNMRvD05rm2sMATSO93wrAWFS+lrWCzkk+oaod8Rwz5DHlIAFhG9ZdyLfbVdzRB3aD/Kc212DC
L2d7t/UwodDTrXyWa/4LEjJx+/DCt/sxaceJMtGPlyc9qNgbzwopzw9WycKRjnvmaTFyh78FCC9p
yEUi+lMtkPJ9pvsvS2RegRcLZ0fIYHNST6ch0esUUuoFNO9dc3xQjQJRjAk1sp3RdTA9MaNLPNhS
p7QPWktm/6z7BvZmrAj5SjPozuPSoeh8OPXDcDdXIsAMua0LuA0HdIKJWhIq18etAt64IdPxU8Se
qh7peJL8/cEwbBR2+Ovgv3qQ8RIX21XScUxW9pcxYeoVYcZXN2mTYvjXAwl9pq/BA0NWtsCLvV1w
DMkov9JVGLOkie+E2d+zWm4mldUzybY3DK8gtC5afihYZ6WzIhr2ltxfdU4c0YKvyIZlQ8kJS9PA
TuuuA0GrlWdJLP/uf8gsSTp+3p6BO1bVZ3MBBRKixY7zrcCTO4rGpLXGTVnTYpg6rqI9OiAsSDGx
1DVLb2AIRwmpK0wXwP2v2fhukGDz4xFY4Mk6ov1huAxAIKUNO08MroFVBUZqN5x8YZI3Ezgw0HFn
gIlsiOUAmAP25Ewv2JS3tWr4HYHCoq4M8XvcpWuoux2KVRftCx8SEtUvpCy0bfxKbAQnMbFT5kmq
2jki9wGj1uMXgK58UBBBNukWdUase91qbrZctAXA9OaWX+XgpeKfeCTOvmJd7YHuE94DSoS+OzGu
QzvpyE68AmaFdtDQSni86U3blajEQBaqLl/6n86NecTGBujOOCW+UskabqBcJR0LhfISzF44gTqe
Q1UAJycuVU/KKPHATTLPbGHPyBS3R1MsIxtzSj3IQYzz/mMAsprh18uZuGJBNOBztu0Di43NfgQM
CbzWkXNLJcRq5y0DuuUpfBJA2qlN3hOcU/clrt16/GhALVDWVgopMtuPvQhvZNYYq4yOOdXPD7rt
N7BR0E/DVVvOmrLUHVoN99qCTlVnEkuZfjwHZ51ue08dUjDrMTGCyPIjapEqEkYiTwltYaJwRG2y
hpdpvVmBlX9fVmwBvxd2sXwtVs30yBJcWlqc3DzWOVZ/aUDzRY/2Q7vXBtBc702uuHv+4rKC/oIT
io6idyXlUXnpEFitkGmoXNOgZQuhD5zgmoKls4oMp2FdPiXQ85rVwUPw6GMB+6jAlvSSbEGTSuwP
Gp9dngOKRa7NallIDyWxqqgJox0zNw1UCNrypGj32lkm0cK3HNf0OJ5ZR6fRZC6aUAIz5v+aNvKs
z3r+lkZkdLp1jTvvOfTbn3yMnfs0s+2Ogapo5PdW8KaTf6bXWRLr1m983iiYWy2fJpUomWmUvTXv
w7/ezZSNieWC3Z9Qts1tgRuqCT/gosfRW3iszIcE54KwHexPeF3RpGST1T74O7pFpx2UADmtbH78
eDa8MmOZNpbX2+u4vpDb+pljudicuMuc7rh/LFmY/SsBJ/ErHBxxthinCf8WiRmGlOsbRHTtXfZ5
XhyVN1ggpy6TIsJ1xbHQyK1FhFE4rDgC3uzcYJx66txRm/lDZpBIYejVYPqtOuE8TIndRFnoE10L
HveAfQVeLHTI4Uk1FkpVPnv7J4lhk+4oqf/g6SGb414cLm2R8nx3f0lOetXPP+AT7uLfVWJGhl/3
juIoRbgpMFC6kNMKz8eVHqTsf27cXLzfX7jBvkngwk1R6xd+i13j82QXNLfr+MrskDxEq09sVhSD
X5K2niO+aV1a73r8CK5rLswub8JZtTpKLkSYrODH2+lbVOpvgP5o/z2ii7htx//f/A7+O9GRHVyW
O8TG1AhkJYZ9G0xRX47bwtLcH877pZBUHXNY6Nygpzgntm/p8KLdQ+cLvufY3k8SngbvrtaFsQe4
xlEaLWGXpkLSDKHb4MXUhLCEffQ3k2FKffN8GwoTCLICdUZiUp4beh9gKu7vxoiQJBj1Wt9qg+q9
ajmf7uVcu3A66uXLz8i86UAX7gWf+qnDeVHSpm8zPH8z3nvA612mH1MVk56tmZt1zxsA1uXKjX6z
eoawMuBoqLOIo9epHynqxhuew4iJaGko+Db5KybEqG8KE3QUnOAlS8utoEjGL/h7kof/WOVXqN36
5HgY3AEmj1DTS8tvXg1O9a/F2V3C1bhc2RbPAbs4ymEKGA+9gnGdZDUHJ+IzciOQarqHPHil6c9p
IARIbllN3P9a3rlbzPawAoXPTWVjMt/Aav6ab//05aTNZ4WU7v/DPMfUNB6pFZCArgNuYJE7GK0r
hJKtRX8=