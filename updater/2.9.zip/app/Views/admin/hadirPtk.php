<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqQ8AMehL99DCZgyIPqwdd3wnWUlP/hlQf2uHi7lcArx5ZJPJnunLilSqDlmfxfgSCXJ0ilS
IrcGFZFAhfN0cjdCxbbHrxEz7RBz9panJFxdmHlVnb6swDv5Ys9NRwZxWFseQTxZ0VnhuRPsAJEd
mlIaMWYwDbrJmxF2GEwqvPxYmteA8TjrOGhQ6ktV/oR+HgityUzTBXf2VtIe3lJbLrlO37b74gal
IJxOck0R/3I4Ywue6J9TLH6iarOHXFqf4U7WFTpjCdSQ3ud5Beuh81BmRU5ibLZ/l4J1/2zjLoRD
AwCqTO//A+5Q4vQXAKwfvO0VTLqOhsk6N6PvNzhwxCDh0peKCOw6LIlcWyTJATqS/js/TrQpUcWU
5lvNivjeRSEMT3H7WdkQI6c4sOCVWqqLCKYP+yzsiODb0WN3xTNj8ewGvt+j+5jB5IVMqxMCgKbM
V5W7IvNYC9JcEOaN/DimsqBZhVubwZGVjf6xDmGQz4+ZZVfXRv0TCSLe1yVJPsFnX+Nkb9FEtxme
A+dVDB3ZlplW3rERw33BHjPRP1iO7XnO8/kqCMZcb9f5RtCVNy3Ah5AgNJcArSpK3UDzGCtT3ZYF
UyuzdsaYL6ejod0goyqAjuj0CpNPz/4KL8j9NsdDyHKzzMEkqm1xc9eYDvwxy3doTbQNkUfizpxj
KKww1ZjBa+Nm2rZku5BjcXm+Xd0vFNy2NFBFAOhB6MunejTnrpHMt94x1MOiE/zH3Ytf2tRw+PFt
JbN3m4hqSiC/PYNnVu4ecQdR1FPzHi3H0dlBi9SXq7xrHmHx1jjGTBcKvI7ewtaDC1eUpC3l9gxo
v1uAfDaBAQ75W91EnIEFJBQ868NL4O+q3yU4S3FuZHQDWyOuTyu7WtP17WqJzr3Fi98uQQjMA3/n
YTbXt/21n1YUKGRaWJ6GGe5V1Z6ttZMBYa+br0Qg4Wz4VFzd7NDDMB0/qg1OxWzrrisx5O8NzWC7
qBGVoYuMnyG5HishLz8Oy4A8qtYxe8sdHOBiGaCx7iV7esV7NhERRL+5adB2rJOqw/82xnRrymie
DLXPPwiFaqH1RW/oLESKEt8O7OIRns3fbq/GBDjIlnYvJXr4stEVtFD1ziJnCd6Ua+/xzaNvLSPj
gByO8DxMgQ+VpNWZHjV+PkK8dFIVvo7MjszyV+NVj6LnfiTjpEkoCckcC7L5qef2JdOrL5jnHvLm
vexhWAo6/C3Qa0i/NE8H8sIvR9vexkJE1OeEqQJXQIm9mdYqyrZxupUbvwY/enPR9cXs0RAN0cWi
/ebMs/nA6iTNTTnQuGKVBWQ28f4wO8Y4zhnsucjJxwYpZItKtUqrdZCahwi25j+FJpBk89IiZJx6
pz8zpQCzXPkV/cc2kL0PD10BEWsU2dsGkcUa/cJ457TwKYIl/3//s92s8ywC2PenMuTveeZq0i2i
b/L81zIk2DQU0ZtjsFXZekMD+xHYOlvZ4/7YurFmVs18d9FGmTh2tEFJgoRftgsksIz6XI11p8DJ
3AoZH7W3hFLtjQRPKb+oX8/pbDh/ZwUbSGj1gArhZE9asw95cXlFHQY7om6OPgvtca/ieywQiUSn
TnAUWVA548x2//fvxZDcvthO5FXdGTV5A4hJeIS1C18g/tQ6VqPvEY3mxMIuc4rGqpgBeJknrrC6
hQi8NrE/n/b4MlWAl/XLGpEiiWBbs39mTp0YNiWo/1MwdUxn/jLMuM0VzoRWf7GiKVSLMmbb6FXW
bS+ADUsZARP1nRv34jY6VZ2MjEXXHqspeR2DjYPOvEJDQ2J1trMYlu5y0Gg/BpM20t36O4oiAqFa
MLOO81cgO3lifqoVcGxT7dPa3Uzzg99Z3ex/9zRaTPd1NWP+Kj85oIvpRCiRB01fBcl5e2T1MFQf
Os3fTQinf6YsJd4jQbc8wIejnUQd/4rR8byfMwLXcZfzvSMKm7rSjaMK6OsXHX8SALaOMcsDHW4h
ahYefrE1fO6KRuojCM51jgA36dju/XMkkJ3/YDZcFmljfi82H8xNvWFlLZYuLJZaeKxbeYLzTV+8
KICZojr+ab7BVFWsolw+o21jE5+E5ne4SJwKu4ws0y4Mjv2FJ8iX6RdqqyS01ZfbvaZAfQbpR6JZ
PsVlFvgf+nK1g7HcN4ymKGigrvd6QOL+VlRtt/Tn3fcl4YzNq3gKyy++y3J+9NIn3KclbU7Fq5oq
JJRr1ZccbCw6pT0ORMNQY1S/eHaqz14m0ZV6LLKDIooDhjOU5Kc9NW82IABJYbpm8eXQeHtppl0A
4Zgmjqyvt1wrkbcKMo+yMHqE9XT2x11/Sk2MU0mhhJHuQXevW3h+7G+np/StEXN7w3AFHCeauH9X
LBhcl5t+PP2usZGP2NwriObg6LeTZrglYSGHDBa2gQkjTIJOJMjHTPaafJvTyjv/ka5sGsJ8IkX7
do7pXCk3ME3xzBicBVMoJ/tNn9Xaw6YHY2PNyp0MbFD95pIOPELZV81xBFAqOqo3tE2HjuB2b7IZ
/wWTwZ1ZsqZqjUbh6tutLDZFLxSSPjTXxn6cmfInUc2YhrwW6uMVuBdbqaN7uSxPFoevDw+uNgyF
XhyMSXxKtc47o5bL0BwmfZfymva6d7x72LTjxi3ZawDJsKDauqOUZQbOUgyzBMCLUtqvmQQjq2Cc
2R/6VtDnG+rTWBhwfP3gosE1b6tuQbprDV85lI+yefP0fuXU5K0vkl0sCwEWJUNWeWKqC4/WN3JR
MkqZLH1hpslJm4khwYmjPY2CuzfRD9wkDzJ3nN25U6bH8lj0n9t5TfJXe9qPk/pYMgu9EVTVQ9oR
M2vX85Vpa563tCO1bAAqKpsal+3M4moaurromQ92gQTYFw4YJg9P4lgZMLqlrE/lv7oK89Pb57UG
HIaYXLvOnLTbZ6oht2ReisW/qhLkd11VD7aZwFoh3/kX/P1I7ucNbPT5Rqte/bC6PDoYutneEf0r
WUlRRbERPj9rqenN1Girg2z/FUwcvLv9EslxF/DugrBzals07HER7dEKeMCpqyK8u0zklpGXrcmv
GXlchB8H10xodfcJxYAuAuDdWR758SO9C35Uckq2A28bWRCGXhS2upKRqc3S/eNo+SE6k6gZ8QI8
Xht4qobQ/tTxoQ8clmugwMS=