<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpiRui42vzRsswjtuZ26SFO36Jl8WtSw7O2ub5Eo8jwNvICIDn1jQMktYn6LSlZ1xKSrwcJi
w4lhHPbV8aCA7Lkm91KTX56xD1a2RU+YX1YPVqAht8O/vot+hKb/CD3Vg896i348pPObXGiVeBHo
mdAxMi6hs25Lt8e5qvtCU6fVH+ci1on4C+/L2uo3D2EQLNdYzOLyW1rZdFW1CWfo1yfbcLQMe6st
PtYxL560xmul8vt8Mz17zxSDjXlKwZym2MVmFTpjCdSQ3ud5Beuh81BmRKzZ5vDhxvHv6D7S6oRD
g78UaI6j7ZilFtUHvvoHVsHJC9uTWl7owlzyL5liCMSnx3Pq1Rv6+rrrv5iBTVX9hVjJag1pLZBz
eZxLpnW29cbE2hyrIb48BjpydjLSMP946xzKELdAaCo+S3iCHMlwEpYI/c+qx24WJAU2yQ/euhCF
caN4TvxGmN15fbwaq7IXkO4YeVfd7CCqNFej/TwFaFwDwLIUvc9jDk/1wbx1KQhgmAAB1pxWyoSB
BgGaoSgPN8rcycrURG3Qswmsi42nC0BTltpWGJiLtmjKNB5DgB81HOU3SsCu9748Edbtd62UIT3e
kNl7XAEBQo8dKkKjeg9b1ZO6mm/0ixp3hnsJbraKOteg7qxgHRnTTJhlyUHpCV2KCGdRXR3yuYTE
x8MrGku1RZdDLzvjoxsWThBSLFYj/27qmdbvcm+r/0PoSq5MPxxT1+7gYRRzB4QJy0euKUKFnK+5
BGzNZyS3wn/TdOH995MSaqValMew8VqAMn7ZBob0AQO4YIE72zWbUaY0AwKqlnZcywwtGlv6mmjH
vkZWXEZGTJDXnyGBKEe3Z/zNELfn7B67ECh8/WAjf4aRPa+4bJIHNqnbuuS2jCFS9JWrCq6R8LmP
TPYWZGHazvbIeEj/uz8uYSTL8JMlcFv2I7EHgrQDdiU7fa06CbrdX2e5ZZ8K0V+KmruIta4h+MAo
JLWa+TSTzK7Pf2PwUh2JVfcwa+tcvmeM5OqppN46SUQ0jrApo3xi8U67KgsD1EhggNVMamT7aTeA
4mSXbIB+EzldWxEgXlrCj6qeziaizwX75bC5yZUhgOjlmap8M448WCqo99QXsi6ZY106GZlrqLdM
WPk0K5UUHP0dsskvi9+dJD73aWHaJwdD0ZcuOntv1uhoETBXbInxoLDeddpqC9eX83WPkDF+OTHs
pTrr/PxSa2DDEYbC/vtA4elC8vhp2KvxQfSYAHO+AFk3byDrHiZ82bUb/8ARZNDX3t4kKtdYCi6q
Yy4L9sRWg+s6XmmTMPAXAafXeUPi3yT6YtgDEUmbkdUY8c3EfFoagngZ2UqJ/xz+hvpC1+1oU3Fk
xJDrXoLRZGYzFyZ+P9irepy9AwqvwCcSPecdWBpqyoaQKMiuyHm2uwIWL2L3YVBZTv0VfY4k0FSz
mpWG6+gYiDAOkgt+jh82cm8K46tv/3wMi4dFDuX7aZhcWEUQmZ9Tokb05znViTb8RWr3a8hCjMZE
/fOI189fZMAt81GKf0Ccg4AzSo5hQvLHkEbCo/IRMEKOF+CtyrlKsNE3W9OI/swaOjwUIstJNXD0
OGBbT2AIhGj9OTnnXAlgp7NZCDrfZLs2nIRW/usHDg7nlGbLCz4rj55wWf40bw8wfQldRXEKk9FW
JVk+WDdWY4Ns2dX1arQovHCpQ8hhgCVDT8Aj/kp1/TdzELtksNq35eCpNY7SP67I803VUDadIy9U
TbCsQDfPwejMyH5qanbvh7kpSGQJkqveXn8mA9n7oPz+1VZWFaNPBUjVCzu0QdfQzNf5iuR02jjS
WS6JOJAyFTpImrAi9JGTZVwGmxKx1Thq8EhCvbXa3vliOBjBA6rkvJAuAj++JrlgpUQF+mZd9Bbg
Sojzc5Yra2LaNErmFPu8TcGI9e9p8We7DDAoznJ7lEBS5Pgl4s9CXdpsp0ZmGJKJPUMejrNTgnrj
e6CVN1SxCSD2rgXkmOdUKyoPB24U1kdzFwJWUtkjGCW+kbD/MJX2rm3nlbdkq1csyPQNC1WzJsjy
QbaQE3gYUfSKeBmfBE3Yix96dmUGV72ck1q2lx4ZTwwA2+HeltwLBtLS+2Y0K0ptzioPwrgqyRSD
TwD4lG/iwAFMmKc95vw4fPvEZrBOIpkd/J/2/bYqwTHDn0GtwWzUOLqATRQDrV6o4CHXrVyrmWMD
bTlcU9V2uugdBkOO7nH2NdghH8uGoXuaSHnmHtSzjhmoK34s9plSEC1sTo8zGFPHR4qQ3opGqkvA
isQaDRrKWTdw8WLgQ+QV6BQ9rRFGwHpq