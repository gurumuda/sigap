<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrJ6D83XAust/7UXen3Q59fL/jhjUbEb1AsuzkpZl+X8h4+H7ctRt7qLLLuzudprOSE0HAvx
vsoWoQPpdoUexeLyVcWOX6AdX55u3KJT18GrPxcLttXhloKNtDXaJ/kCWJWk8XGE5DaSnpG/iPPU
YChFnURqILAE4s5oHEbRbrOixsxJoCX+Tib0hZxIc1alM1U0kpk18VDawYpx85GVCFUfw+cUnSQn
8jlxlgW6L0EzsUjfIVymOhNr0tplJIC5G5BkFTpjCdSQ3ud5Beuh81BmRJPhoONgbBn6VAx4foPD
o8S0/xF4LPl9XnLt3LtYHfDBxAhgirDX8NYgpNWd61NgHqloIuPStuP1bRlo3HQxHx+t4yHlqRI4
S6EHRqI9XjrS3PleAYm2z2dG4C26j/10BPBmg7PiwT75+SgCiNBuyXI+NvjnoN6kFLBA9ZW0sGIE
kRnhhk7CefyxsokGxgggLLcJgJQ4UWAtJAZcIBkr8xUKhVRvWQChfobsenG0cY9/2Mv6GKsBgz4W
lsfAZVKcLO9a2PgybJlbXvotjYs3fj2ybTmhrwpqS4lfDQkELhH6vhlW4p7YZi+hWyN5Q3aTP4ec
sXaXuH61Bx8w22N/RH5ZBojQkThSBNt3G0LTR7gEP2layIOYhb88K7Bi31x2ejvBwtvTNgZC8jJ4
YZzqdnQCwmuVYrNLMgwHgJAFI7igXa4wlhUKjF9M5t/oGOrG13Zvxt6sSi0XpACScYOLKl9s6Chq
MnqAYhd+H/PIBSeYv5RAWOb4jif0jkI1C/XqpWAboY13hL6eLxtHRbfgkCBOHe2cGuvCxe39oqb4
2qAQOhTI4UcO+JMq1RjHfN6vTVQ/7PjzMJwBUJOumtyc/aQUlTHKzfibajt9qUxDmAFEaB1AFM5u
AYy69GLkz9ow3frShQ6egIBFdBtr33lvnEf2KLx9JBd2Y/KT6hnUAEyixiha/PWuaublItkIaY1x
4KhZJhBRAfXPTbt7dA9jnUQcniUp5+LPSkORVAOrzhHC/YTOf6SDk0Olx6rEt+1GLfSAbQkOw9S8
KRqk747o4lMyYaZQx5gKBH1lwHjtDJ1YWkrK3HTKZjHRng+GfOr3ORtDjoznRBFKJhn4iT7UmQyv
umNKcQHufPBXP5+TY7e8KXRWnJEgKOwkRhNUosWEHEbDAuVZAqqcgnaVrmY5M8h8RYOCAUPwAHM5
kZbevGFDVwKpbSx4ItqG02lPi4y7de3QlSxkvZZAtewHEpypD7JIs4c0hm+aaW3pgG7o1QefCCy1
L1ZLL3IZPtJe9iW1YPTaFpybxvmXe8IxEaxTP53hfbuKdZ7zxJAknHae/uRO/647opsNT0vGtcaU
f54kE6oqcBUreun5bTBt6t1HdlNnC+lddclf7GRDFw5PKraXTE/N0+J8D4sf5RMkyAekvZ3Wfu6O
Gx03TUm+bECbvSLvWm/P4UeSxgv5IpVH6RaMXcWRtPqeOI4OjM3eFX/AN6ntFWgPJa4nEKnX9P7E
IMifj14RXH4BP2gxUVNCS7rhz8NADas5gOVyMkTm1Ez0ywYjU0Xt5D190VQlSA7w50v18E8RME0q
BUP52ST+QBdUgDmdRk11+aOekjVhscch8kFtYAW4cZ7DrxJzLE/FztCk0XuVg5JtxIMlPvVa+hZw
uwAkLfuAfPC977FGi4YN9WoTJh4wUxSuBumz0Y62dTYsjpfMGOv849e5TygxUGkWM2FzQctXqaBU
00zwhKkQ12QIw23eMzhfc6wOZIK9yEdvdQgX75uONBGf8ZVwduFdbiSrKyLnELmtpB0ElJeObrEy
WP4ZV28OGF9iUG6M/lnAgJ7QAFxJ2WQw7kawBF4wRtqWzYC9WRDiTM59uyzlqV4lL655HeWSR35p
jln0Y6binnz9zqcPqfCpZM4lndfUgVyW0wRXn+3Fdsr5ZLhST4s5p/5mqLg93czjZBCfDNaK5t4e
zhod2M6wykH3ada/CFuzWyjJYzt952X1U6QeTTKZLmYoYc4R79VrVcxNNFH+41QqGwwEsc8/Wc2q
mAuRyjjpCfwQjf0zeEIXswoBJ8HhTIpL+wiBvK8jcoqr2oePt7Lo+RYf/EDj2BL3DOw7j2ornBL2
JnhbErNOxrr2+fYaLeX/A+sXCiWco/QoLMAJwDhACOBgLiiPv2Tk/Ky41efwRHJ+0ZkM8zwR8oCT
G5dwRBXvRP0+bU3HdVb16hl2LbcfgMlyJeFD7VHP4sY5D1rUoMAp3bC5e+Wi37livnOaJT63foOZ
ti5QTvNYrAqWxMIzIVJcQYs64O/Nx02vDGJtMfUVADI5fwQ6yHK1afM22of1uJbM5xqX+VPUuplC
gK1zBC1t3CDiho+6jBVyxoYtpukL2WWtjDYLfvDxysi920+x/QElv3NmkYf8K4CZcgUHH1WFa1hM
suufI6kpRM+V/jzrC13oPGY/z5p2mblD4G4Ggka+EijwsU1XoUizYhCoYGe4IgMNPa73M+6gKV/W
zW5eIlpNPta+mvahsVP4hjS5AvT67gbUPnoZWc0XWRiQHcBGBPteopdEGLCLqxAP2oUUVKp3YiGW
SRu8InmSrGDWDL2vdJFwD2Jc2n3cPLT1qXV747jDBZeqqNwyaZe0HrAtxymkFTRy1OTWA38tBg58
WiEscGpfBTDUYbfnnKACK5t5XvA9+uNxoiqpMO9RdusIAYzL3ls8YqK8+pY30RnTW2oq