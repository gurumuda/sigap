<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxi8S1MSr4XRMRdbDeB0pmna1nqMjPEQUCinMb5N2odxPiLjyhaaGn5TqaxIeiqFP+Ntuse2
Ujoj7nFHjCZOeE8gDZk4FHTJJ4pVFfI633T8QpqB6afGYJjaj4BgZgYAkN8f818SESJiLSXf85X4
yjSvpmcKbOfKjW8jQe+posZ3fcaz81gB+/YI3LXglW0N8WiAHnXvmQgug3A+a57eXLA6mscQFniq
AchgViEMQWOWCOO+Y/NrnH4PHQizh50kSm+A43tSxJ9t6W+9nIwEAo0Iy6qWNVXep+Hw2+kCqCyc
pSc76ly1tIhAlm/APYjPPPVBXXlz1gdHxcjqRB2xKjXqO+yPDSs3rIcCgkzXmEaFJerlanBTs1Se
72ru1PJXk3wDqFv07qj/S9o0dX5k1SepPT4N6AllUiy1JbuHJ6zPsQVB/VaSj4iXt1Xe0zjmsmFe
bTGLuEkk7aPHUU+OSXxXwnxrva2Vf1JVAWNwhES3z3vlwuowwxcCYmwPU5EHRjzz8TojXRMAkJg+
b64iE4KLHI/NTJdlvO2ZjD5kJGZOH4Yx1WcQ7vsEhyz9QATKr51FY0gK6Ar10ndOIh01o4xy/PMD
m/Y9Wj0qByBd5693UoM3HvYpoQuQtSfniPiuUrLOf4ffJHzpywaWueNmsGk6g4xGopCHQwcCIivP
0RV3iWgPIYgANjQVgiggt6UfkEE6Gk/Y2reqR8RlkQbzW35A9N4PWPb6XaHiWqJIM1ySnh2SYVGm
iVPPybExoAoGNZPup4UPafaQxUuKR4ZFq2jqbYcPXOooYNUs7ZcXJ0pXxBs4O1TFCSgaYmCa9oAG
nbwIEIPVU0idCVZykINXhT9E2FHsmasnXWtVgLtcEpFrpJhAu4333dMciRiC4Is41NZdmk4BPDFG
6XYgL+DF91LSL6grfVqeSxpfCwicBblEwjsB2RfqEh4Q15N3BA93BgQd6RFrRMHsZD5q9k2maQZf
tT/mnpzvRccAehx0QFrhrXRz68yiP6lPtsSiumOwyWf2MctkCe2rcFQADolAaV7jSIOeDautVW7U
f7W2bEL5xPb65AiDoIJo4Aot3cvMQWLDPFjHkZgUZkofzQnMc2EhnOdJHs7rFIbLiAHhKbaIDpL8
qti891Yc7pxEBC1sMRE84vxW8/i0eJKCQ7Dl5Hg5pN0bYTaULvvQnzGA/fMhTwVX199oy6Akfqc7
Zb1w+CNse9ZEfIfrtXNBWEjZoskiYGtvve1F2S+TnnugcJYSj8l29bz2gWT/qshR8bADTPTDoUpx
jV9MmHT8PgFDlPvRQ1m4yEPOVgZ0nX4x+aRE/8ykPBK3AQQp8vAz274TClz73ww+/Iv+Cs3E4Lxi
oJygK2GU1/K5du//tPxT5rkhKBnGj3xp7jkS2oj1rmSIQZg/e6dZ0mHR9SgWpayIy4+oV9pBU85R
Eb1DLNNX75mvrPucn7FMKPwOh7TunC2/MzuBi3WTd2CCie/BLsZdf72UTtucV21sf7gAL81g16lE
XkEqykh8jUUEz+IRX5wT1ZOrYBbdPibQZPQgr4r5j0zQxxm69sE9si8R56wfB3uO+UUEbb7knoN5
LtuToewLJXJySnLImoUrk98IhRMhpSEqrDoxhstc4jtXM9ha22FOwCczFbv9TdcTs5xrFlOs3F92
4xSuYbeDsbQBkPr5wi16/wGM/nHhTklzuDQ6BlwzgqumHpQ0tF+fcFT9w0Ne5GUiy6zgvSe/a7NY
sSk8Yun8AjdkcQI6RVhMFir78CjPoVXIJVwW+K9Q3uLqx4Jdf/LgJEAqS0tv59xIXrUrSaN28Put
swO9Ftnm7G/knuAjU775vFB144rjqp8l+9C5je16tPtGBziKfJ+xXGarKs0NaN+31aeQUpCFeGhT
XbHxavqYv7hol3BqyrxHPxNigOCYMrp0i6+oZG9Gv8Q9vnDnarIuS4PfHN7/1sVjhNXqOF2LcfPI
zJP5+yJQMuI7lwMGlg/2X0fzLqpENyfILfUon6OcEk7XMIcAA63D1FngN49bj9HaW+ArDpuoPfaN
Uxq0x2yVKkao+0OKK1WUts32TOq9LpUDal8pZsTMqakO5VRdZfj4mbuBPdzW4dMlVUN0cOSNdGUk
4Oi9wszbksm/owftwj0enlbyZEAj9D5u2jum/fdQoaA26mEPtGEIw6ZsDumBJlyHTWTYQ9bZXrYT
dyy0AxBZctzCFZKX8RVglMIsevV4CD25XOLbgIfsLMR2z5zEgoIH7VFzdaQl1s3wEaw/I6CQw3GX
Dav8RmCs1bTVz4kZ/eIcYxBh035UUaWiX87Czxp5wf0A3srYbZSjAMp3rNsxUMTNGASIcAPNwY00
EAVNmrgOqrV5LyBt0HRv/2lz7mOODYhV4YgVvcHDnVTryZiomql5o4+fgBatnjYLSuGE6QRdCcKw
R6WUArIkYopOIx4HHy0FlE4CH4JOUZ9aR64ZST1HcwWFZNRLVwvjCwWpsHTB5FlBzSc4fcHfvcae
QddqRosCspvF7xHnZ6ywUAAB1cPNzFmcVOSe+xVfbkb9kBGX2rS9IbYte8cyv09XH6u3Jz2y0W/E
UnKIKxCQLNHQ+Bnsys3rdtZEu5zVgRF4eHX2jrtO/0fd9GtGoXzDyvz/ZYzgfT9eQp8=