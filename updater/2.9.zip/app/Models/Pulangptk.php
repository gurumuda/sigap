<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpbF6Dy6bU0Gt/cD/F4lRypscQJE6RO2LBgu6S1PJ5pkQ5t2oGET5wH8Nr+kukFboT6kio1v
Qd4GSNbukMazy3zbd/JYWdZ9iE8zneqJsG2zvmxJCNZ4hV7CMPBTX92yeBhxUKYV+GiOE4hMLMiH
gIefhOI+kwULpERJDOYAvJONzdrDi3MEU+cj99IcgNtLJ5inQbAbAHFdZ5IjAYj83p8xTo84wYTx
41IE9r8aKN2uNdzXuSh7zZYCSsfteFiTQ4KQFTpjCdSQ3ud5Beuh81BmRP5eVNiLwWM1MkLrW2RD
kuT8n+2XPuMW5jvR9LeRfYQndrI0lcrxL4uCprCrRt2NfmrU2cLbLAjgNyyFAyYSpXEGZeC8G3Y9
2lL48Hq9mD8liimDiqJvOshVKptga/0YqfXsoehsGPNF3OJ+AKMfZYj9+oDcqWRg46gPcL7O3b+8
/nznuFR9AmFGh9VvW477vOUls+SWxTrAFSqfjGgt8jQb+dC8Z3qCi36aoKAHPxNy+964/1jR4V8/
E/WRQKz8rwSYK0kzpSwQabjKxU3edsYxIk19RCaBAzE8sJGtFoWNO0bfiqO/tdlEhvcMZ5u2hHAb
S0M8DVJwGv4uKt2O1YgxJqzTdgyFRHNPwJa+5D0YHR8kM4039k8lW9DHYzuRqmm9KM6FA80YDsxL
PhUEN5EXBr2VZ7tL86jzjqLlKG1dUS3Mt/PQfag6Ay3quLtEGXT7C1p3dYzPXA4+qX56eBIdr9Db
lMVkO4/BndIZAJx2omYTaSvTVsBtZagtU77FD7Xgd7J8/g+x3WyXwpBOkgZw5UeCLt+oTd7J8z+y
dkrLKAYCXpJGw06H3HvlwaGKq19/zl7i5Tn7XQOJeD8FxjJlBir/1j8YikV3GrB1AvqN5bL8ix7h
FkTKZ9ejmzb9eGCLJUeNgzCOyCD8I3jRuDnUKMVtQZWOK4/jSEGMj6hXY4lYcB1D4Dq+9aObmfUk
PCihKSRhWcpJAEv0QVzjv+OZR9oLnFUWR4xkCZK0g95LvnhLehK6RNT86VqvdcNPdP3BS9/GKrUM
OAdm161TFmfHovu0Kl8FPrrGlOyAwGd/7fU8jtnIzuzzS33BikWw/IpdoOlf248T5FBhKR+ryhkk
UN1jlLBNnDh6r0rXNYdgw+tzMxM0hsLAR4keliZt79tM2/puDq0rzZgR9RtMEm1MqGfSgmTOneg4
+A5osR7dniFpvHIeTRPSkug8OVAcQq0dTAj0lq0lhYXr9kn0nZ+tWdVYJkOjuy4k/DZKMAcTfXoi
nG8JRIGYeclEhnS40N4LOEaaBT53ALelGwYv9BgzpLbP1AIsW4+RREfKBd+6m5REPmOvnf6POi0m
HgNTvwlouJ4bWw2/ez2l/VMBD8Cjrg7Ahb+M6LLxFkMKsqHE3cCEePNuwRSdZylqHE4uTscH1qcz
Ge7j0PPUCE68y31Lfc3G4klE+3JcVhLdzO1we7ZeuVaFiYhnRUlalvbxA3XJhNAak/+DwEm12ay1
X5u+G/e2OJDDMRKaPhN0woQGDSiqZ7v4q0GbXFSkvxMOqcxoYUNtElSWJ3Q3mZ2PKlF2DBeLarPS
ZX9wbUGfNdsPmpEznRsvGkw9C0==