<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz470b5PxVPc9B6NSkvxZKNI3FkojhMBfwYuJwSKrS5Cfk5CNhYvyZG36XdSEuk+um+RSsvN
L+p3DBp+bJCrrh4zrNkGS0IInEqgSJHqx95ETT7cs/RUX9ZnaWNPW9k1Vigx80LcjpYR6tbhB4d9
b/v6T0yzFfM39TlT16S4PCgIdVxfnhJ43QK+tb5ocJOsmlsr0GRxeEo40yrgU0hk3WmIDjPlCB2T
KQujUeTmW+HqADeMUfW38mT3ZI9ELRpRb4aCFTpjCdSQ3ud5Beuh81BmRLfdTDa/UVUhM82wB2RD
CADqEKuLcrYNSBLVM1L1bsSxEVKFzsqQFOG+h4jcVAnJkYqZWXZ/wUKQbkL6RSLQ4pctb2MtLodn
Hramm9ITECNLYJQquS2j2K6KIgvs1wNEGVLrDgZtgRO2I6EBNtl9tkKP9ZHkyGopmGpzdvGv9dYa
lts2NWm6m/hbxROVwjl6W89rrdniPv2eBgcATV6ZWWFVjIhN3VZddXxGJDlnSkQ+RqNNJB3LLzUC
FxSP+Ios0neElEAngpEo/b5cy0fxBgY6O/cFzk+vek62LN7EmuYl4Pevo7KSkAwRbfYHljSJx2H4
QddTv75Ic+Wrb6pQHFATa5tKBYvwdDBH3lSS9LPd0r3vs77I560tEQjRy8CDB6Ub1y2PMGsVr7W3
SWqLwsDc84LJz/Ejl8os0QLFj0tInwCpJ18RZ3HMV+b3VxJ5vZMjQi7NJggoZDByfAP0hQBB74eU
Q1iXkWHzOFhaG5mXKeOrJWhstGvSgvXZW6VkYO0tAM49mGhOj9xEhqFPW/u18ajBbugYJggyVlaU
M9YooWm0/X6r5FNUnAJ/t9+6DMx7Z8aGZVfz1SJ9fPsf6+sxUj7kv3qaJb+PP7UzBMvnkwA1GeRB
wodbAY4JJRuAi8oh1XyMgQ9naTmMB8wesXpf2H5V2PpeLZDc38DNuRo/D/muZ1MJ6+OQHeTWBH1M
KkmiFidvItg0BVzmn3qJVR8wcOGfTczDRBzvhjk8zjwBJ4iWeY50bdc5X6duHX7xt4mjch8kHmP2
eXVJ1iLrYvVhRzBhge71smWXvBo7Pm3Ceb0wEf4aAoxFicXZG6pp6LNJkR3YzbHGTbIEMhLA04k4
5I2gqrDiX/iHN+Dh+HnjsCkRRzFZH3Neec43g0aeQs1d58TeEM/Safcb9qLh8naXf9nBRBVFcwh0
q6Fi/fwozEwTLPNgCuP5w60I9U0mBLxzj4Cwl2d25Pyr09IW+mp9qJN6OdIKVgqB5tQHAPpPf/85
w6q3BJfjX6gaBEl+GEbaQzXYB3xi5ZEaY2QeHZ1Y+iXC3RtY64eL2+BFxDnUrzl8qY99bM03hews
WdVuEdWfCQ3MAcSHiXiqS7tLaOQRrWdtJDeDeOcfoXG5VH7UJU3ZPL60o405rLf8pNf0+rHzsT2T
CiJTBIon9OZBPs68Or6mJOQ21vWGdChs+cug5BVRRBqtuRzATugYCJJfEUPVr0Vc3KkrFOC+Etl6
gwBzZE15E8HgvTi3M6aM3DKap6bns8VlUXwK95xOu0aWGeTDC1H7qTVUn2y948hHQ+vKfYhu5FcQ
xgDPtvjl