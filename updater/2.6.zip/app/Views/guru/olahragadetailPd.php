<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPxdFOV+UBH5QD2Xzz1+Lu13t1YCz0xd68x6ua75WonF0PPxvOTC+Vol+dE2pHN52YnF6bwSS
HjFnxYN+fb8Y0u2903JXWRaSZXiVfUtkqjQueDkQosuQKKhR63gZm2Xwu4DtEIXydG6DfAS7hY9W
fIijM/3VV7jM7sOLaNuU9eKlBw/n+JEI69aOvAuFj/o5no4/ZAmLywNeh7H9zyrJQqrV5ENpHjOk
RB8fxaVsBQrv65XCjLW1+e6d2WpmwISXbefx8X5jdQPx9E+sF+Xmx7Xq3zzbmJhNGDfBkhfUehwE
cz4zeu1f94q5w2VCqgVZTcf8xwmi5NF0EQpF2ERZn8LFr2QkoFtRd9v/2J3yIfxL37Ilg3S+6J4t
B0u/zVNhIRq7CFgGz9g9LIVJTyN+U9G74obeqevch63gc8+NS634femX1VuALziZ89u95Ywr7kRv
SrTv4XuFjZHLrqP9cnF8dGcBCZ4hyc9I7Kg31VY3Gbg6fQuni/VrLtryRmqNHQocK+330dQTtXnR
QIBjrxKl5EO90l81WttIHqlIsYvl5mKvYcK3xLcQRWorZ9mRN/YD94M1vi2soKUQ+FOJV5b6uO+2
TAd3179XPGeKzyK1de2+XKir3kuruo4QS88cRuh19YVo8dQk6xD3CqsNN+ek9ICWMOeNC4SG15bV
EPfmDAdbRy0fAUK7bzFIRDD4NN2pNhtZSUSX7ecelkGWIDZorpb22A7e/DgfOzYpKQmGuQ+YawmL
JUDcQaUfVFj1ejQoe2DnhVqZxfO9R7L8M+dLkPxNp0KK7FxiBMrFo5tciOwsj01Z/Ic6lmIUcgrY
PDvpwqW2jOnGz+Sh+e4tpMzsFnP7NSOChDdCo+wP9XzqurdBOe9obXT5KBZm6VgR7ZI1orwq1dIO
EVYrJdiMZyyNf8urFqCdqP4YXAwHscsB75UfqjtmCEbz4e/B2PFEjdgT2uJM+3MInfvtrFGUuKdF
LJuXkuV0PM/r4i59S0i51uMMgRyPli60qizYDDDs2f6x87WP16zSaQn05OPzb8lWtr0qZibCvC14
diCInPF9GrPL0FgTfdDEmMjrD1Jjfpe4QfzcDV9VsWs/mowUmQAh2Ff+KIT5pqVCsUbYo5cPaF6J
ktVdWD+0uV77SBId1a8ixBTVbByjbGdTCuo1PJrTp5DSyhbi3a7V2wIm1qefaLawjonw7HFp11tx
yQ0Wl3Nbb7ikMRiKsIRn7CINwuI4W0LfzgACK2Z+euHOaiSKFLO/a3LAN9AV0cJdGU1hqxcPc42e
ci1iTYnA0uk7xqzWMDdXZjX+T2FKuvHm642pediY40WQxe6ZmqOmYJi2trM9DGfJnIGx3PVV6NKL
U/NfJOgoWhuZvDsv/QXp7+wzdjxeP01oRv/+E1aahCzqgzLki+u4lb8+8BALYS49bCsJgKrm9siS
Jw0bnfznUD5lmraOWHGjq91ZJvTsS1KnQlyZU2FQexiX9cIK1GBbft+SOaBEOTQT+KKC+lZ+QeKX
olJsILD6IHRCXwNU5z+1av/aSkO3yng0fqv3kkoj13jKt9VQtZXnAVLdTVrqqEm7vhmAEqLbQ67T
vzen94OYEPYiAZwAWkF5ubwZ8YqZX8AAzgIy6Oj6bjINmB4npy+2VH4Vew1aNoNWKBHCXOulwr8x
dUtKkTyuLwF9qmMtldYFfLADq+OSjiq02E/mTpCNBhMql7tYWtVDeQM3h2K+hfhjKh8/ItUP6Rr8
Yu6kji0PObmzUKdNwj4KvY9RngkXex9II8cztsianxSOLD3187OWLLEMQnJpOqwtRJRNQL5WViia
Bo9OQ9mV9gEdKvrXyhXxQeVmt2xYOAOK/295Z5tD/QDwidig3Qp0yPQLL+cjaZHvSHniUhFNsbhU
Dwh18Y+5Rc1iNOc4f6Z+63Z3HhGNP7iJwH5Z2erL6bsHgdZ1YBuE05uuVdSZqbIdsvX7pqxZFlnn
PPadMxq24uDadwLfyjul4mytcxLlIcSJTgJf3YL65yRnoWDcffWP3rLkVolb+VxuG7agUR6ZxyKt
RYSPrRJZn4t9Nv75HMfDzC1jZyYprmbWvvCrEeb9fGfXH6OEbzt6fRaMvvCXQiExwIyIbN03hqQH
A1MVVw84I/e0pT6nSsaNOR6OL/nBLwFX+95tdz/iNu/7JvF4Mjlht4BUC4L6Oq1uL9115YA3j+Qp
WFSK2A6rQWO5qHUwbFPsV40RO9rPMAo9NrcSHnwPeGcgHq7ujrBYy6xqZRupSI9SW20Whn6fzVET
FQgYlQ2K6wrkMp78PQzxw+b2UPrJ0tWcKlWSFzy5bUjMXZQwt3lqdvUV77FAJ41xRi2UeaRfNENQ
d0UWKh0dV0vO4ThAHWWtqTsjK+56vobhr2QDrHt+HGzyvs8cd8OitgJcuaLRE2v1wsOCizRYHvPU
9Jbx3nm+4AHKggduefB1pytBwQsmjxfYOepxBCBaHG85kICYcwiVeJ9rk8NrxrcMDJVOHZNzTQ/v
/18rcCqPFdMufdlwkgi6iiAkcU+9DTUjfCnXulNUZNsLIZ+kmzJ1XKsHVrfNVjAt1byXvgh1DOye
lBOSleJRPDjF0WqTLPOBFuOrdZ4XsmAx+tg/wfgIfQsQJWR1ygPxRdxN69rNhStEClXkOZ0I4nYt
DTasLe/KOr5jYcqC4uNzvpJ83n/AjkrxUUXXqhIUvBzqQkNcz3CoNhCHmolqj275BtbzXA5HkXam
pIFQP24Uh7OeWBOLlpx9k/qHgSmkkO+evV2oyRxtSWBtdmL/JdRUJY6eELy3xTLBk1K6q96MMMM2
SislirAOJKlRLETbeYC5f8XM3igRt0DSCZ4Y3PnIdoAeTnDh/mSfKhIbIlWRqfzkIS+K5WDJjODU
Vm9q1ApqI8h/hAu5jWdVWHzGHbwGX4LWzYPO2ZiLAYnvuoJog/3LnDTiH5VWgD1iWsHMrIJ1njZn
M78BCVMySZ0Gra6/5chb/FPbWOFGroOuXMNhAxdkqgADh3MmkkuVBW==