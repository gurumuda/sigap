<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/Ikv5AuSTrbHHnnSORVGATF/EzfLEEogB2uRAOiOyej7iNog9CSqIK1N9aMoKFrssYELAR/
FL6eH284C0Bm4ZMPlI9xp//0kET17X5+3gW55fFzd7mXnGX5cvmT3OP40TR3UlFWTFRe7W7XWlE7
n5mLzcUlhwPQd9uEfY+KGAyLZVn0JALX7itrEEITc1fXySI7rQ8zzZgbyKREUmPI4GY25zHs6kz4
eBkH1Acj+uUe/Vua+naGtfCbyrDTezmpje7Q8X5jdQPx9E+sF+Xmx7Xq3zbgomDA49BHW9rNvxwE
wi0a/tW5yZF/pczui7Pyhckpe3CRbEAEc6rQ7c25MfwImhUh8w7NzgajNorro/4MZ3jmhc2Lojnf
UiMe48BpkstgL4nj/S86qCsq49PQ6HuOA5RsvcvLHCTlrIq+hHpx/0w1lTqC9lkl2Kh9EdxPn1Ed
USu+wheGWQ3QlIKRtYc7X49nh3JeVKdl9oFaz7FCMs5u1VaNDtsjC5Bu8wJ4Cn+FeHZ+ezJHJb0S
dRUWq0zc/EV0WaD7d20Em23kvifMB9nNdiLrDZE6Y8xWqeHRS2KdoL1AJdn5f7dSw3Aj/S0bITN7
Ms9WnBpBNSmUgyx6cBRSDaw6yPnP8l8DMHtrI6SjxqyxFa+oUnxqbaUd9P4ey6fT+a0OJ6Yww6ia
PW1L5hnKjLMqi0Mbmyu+YmIUZ1JmFQTEaDN7b6/sc/bgqPUFz7zDrAbXcUQ6JhQxWHoKOBKlbfw8
drnxviEXTqkx0+mYDRWrepK6q7pf5UmRJ2PcelrbIAnA6sBs2MEpHi+HYB6n+B7jMJezMwzwbO+5
2ncVOXPr7gcfNCPrVTan7dCRwyDZMnzqOZRupyYG/9izAOGYl7L7sa49i1r0nkKpHUNwLzEUqUTy
t85F23LbfvGjSSYRwiS91e/oAnslTyPVO23x3xxKIBsU0QTDSQEjE1xFEo4eWLkgRwJ63EUDbZ8F
g3QiIHc5lZKr59qQZMC35ukh+8PNf5cseY9Qsp+5801sPDU2dTcnOI6vCkElFqqi1svNJQU8X/z6
FGypQWskzz6TGMzpLf+gPUMGCmbQIHSuU9X/El6hY89zirhqyKmEgSRhirfv3bcmLi2lI/x2e7hj
zoz6lZh15SXXyBywgEGW6D7mAwBa7q6+Me5bvomWkkr400SHFq3IYRO1nMPWHoQSbEeGHOBzb1PU
ON+E85sQumoE/rM55BicUSyRQdsF1mF3zslabnLm4s1YswIq2mGcsYPdx76CR7OgZ/Zwass+y8+U
uhohRcjZxd2E5+eztPUM6CpTgk/lGxBF+OxXD0nvINUwG4FAHpRU06HlqG7ikX7hP2H+YhTUre3p
PFwMapVuveCWMO1NqeCWp02T/yjkcnQ8goZYH9k7qQltB+qXJo2yr52Oscc+ASKI2f82lwA6ZVXU
B4Z0aAXsobDXsXufWbHF7JY1ILNrR0xVpb9tPzlb8eFGWly/bSgTbPCw2ahHMr3u8bl1wpae9KmA
bVXV0FfWbVkb7Oc20eCjrK8vez5kuT6EjmhbOut2cU/OO+sXIi5CSplFaO0EfzR7xSogXs+7cLkL
8agWgFVmOO4pSRd5OpU5FtOgvosi3N83Zn4rBRaizVJTQ/Z2TE4zL7XUa9qvTxXOl8tS6QlI8ftS
2Y5CBv3Z60/SDxvObQJd1Md/Vo0safVXEnwslp2kNkj5YIZzI6rDSALziNb7pn057xdF1ai28yqg
FKPf/Tj/PrhaCpz15VYZ1+a3j0f+TwH+Cv3OgqR9sI4kCUnSca4Ns9arvR2O8d5O7ATFJ91bzBx9
sjoPPY7GTHv6Ew5g0qZmLTynGoCuyShaVgETs22bCNdS8oQpw2KzwyCvqBWUIpM7GocoLD1ZhDq/
PtDOJ0SXBjCZ8OyhPB+VhWwTSMEwh0ZEoey5GQJ9NYTuRKOX8CQN4cpNe6DKXaaQ3D84ie14a6Hp
XrxvsflWnHesJsx8xqTLO2OaOa2gsH9zGOAJNE+Sz2R6O+ofVV7+y3ThwyNnOBHLXZEShY9cuX7x
I+n0od0zfKbE9MvD23KUJcMYGNdnSvdnz/F+x2xcnerQ+yncmPMZEamo1c6+5xclHmVEksVcz8Vg
y73Bc/J+6zBJasC7NCrG9fjP5RLVi1wqcYlbMtsNlbebFIwLyp9xCU0letaQGEKJu/emCs9oUnPJ
Mq3Zh8K5kwRxeS9rpJTofZ6Xm7xa2GavDHCdZJbDqVBqeeGphYvQSQu02v4b04ahSRhO+QwEQeE0
0IvAz+h0r9vtL+yosgXVVLIanD53nOjQX0wZyb0+7+ItjPs3FoSe3FhBeJ9d8ad+X5CtDjlcFQDK
ExtJTRvKq4pfYaaC+LVX31lHKPvPNs+YwX9oHI3mWASv9iWzDXkHlznO/iVI47FbEB+t/ZAgoD4i
opqrR1lDd4tfoJZwz/D8qVRBqiQ4n0kFiTKlx8Zf3n5wjxvKb9HHv2DdWK04njfiUJciQeM+Q/OQ
rwjCcVXZ6w0lFvKSDshABdIGDTzw/9BV/e/55wIhPlZaKOC3IOF5LuKN6k6hsz79Q1t42/tDMfwl
ZC30XejcsS2N4glZg8E39RQk7trq2jYDf7QZnJZi7iL7VQzzAmc/erF8yVTp/+Qh0Ylh/DgFDext
orcRZ45tITX9pAAjoiz8OHMkURZ0BjrBqboMZgVa9HtV1HFn+jXOeii5pSA/mwjax599BXoZj1Rk
zikb3lXAZaqzNGO+ToIkYqhWtznsARolquN5TkYTSE2Ti94GlCn5KM/Mf5u6hH/u3OFXNTGBr+cB
hK3JbDD5J+tujW6O6TCc2pXBedXSkHtC9jkvH0o6yUg3QKNaiU1RYW/TdkuHXLstWe2fhQ+wmIsx
n9VAyMcKR7WsuSrnmGiYLixZ/lL4AKhPCqMuDWm8/oGI4c4u1HdkMX36bhr5TsgjFHt1YYrbhYD0
M7SgPh3dEtRYsJXz2NxowDyINIO2AMeHQtjkjnS3D+RlZRXKH7R9BY4bN4Onu4+Vl8RG1GWzn5SQ
ulnZN0nf77F8Gw/51sT+