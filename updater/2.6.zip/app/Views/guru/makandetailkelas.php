<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpCM62d1/k0EdAID2hz0DK1ZDXGONXphrRcuXuRTbYY5LvD4bikkFh+MGQQlscBu102tVrPl
VDEFj1nHrkhwAtxYC9QZ4JzmxGdlovXxUcarAVGRuKJ72p8nGnajj1PRjcIRmD3pSvb4AaEDlIeI
eRNpuw5GMfhcaTJP5YHrSspEzFwTJ1K2yo+orW8QUevwi4F3ZoJd6XseTL+3jcKbL+u5VZQx1SsE
wVREPPBIEt2xeYiGVIbB7rnxMXs6X+fWRhM68X5jdQPx9E+sF+Xmx7Xq3p9bYA9JGMnZTaUiqBwE
eT4r/t+K006EzPswnQ86El4ojNsYTWfKs/rTuKlviQNFah/FOj+fAGzwpVHcyK0BV9IqLPCC2pZe
Tb66B9Z6GeSfoVbHbsl65iyuMPlAEZ0AeaqqJz51dn20J2qQx+O0oLr4jKcc8ksZPqGhj+MsP7xc
Pca+cuU7U3tRQq42HNEo+RYa/ZWrNXLNcrmEXPJ1UEK3dCmcVwarZ8Gzys2lUnS0j6nOb6+Bzsdb
wLTbpdf2cV7yqsydJNUHnkFVKDLuLgtdJrHyI+P9Or7z7im4M4T66iLf5pEmv34zpS4N5YK0beBv
FQU+qBYDunGi90NN79lDOfbnkosmLLSCu9lq5u7Pzo//ZJER7bR9ONtqOSW5Lw39Hk20jPGCJ4L8
8K2bp1huPayz3bd85TMyps3I3LdjibkYC1ZGzVjif+3/nI0PyymCNk4JNa77YdAWRS/pL1PAPyhS
WzR5WyOm7c9SoKOICiypAxiwGQiptuwfHPK5T1NswdIbWC7vPFIhSyx1OzNWLz7HuvMWFYI/+oZ3
cRCINddjEPxKyU67Lss5zeTActMv/jZcCLobb32jCnEzVCvtNFXaa9ikPkvRSjsGWCYLgdQQM132
eN1frz1b0Cj8Vk8W/ujiYEyJKzHKnGHnqRTR2in+VbXnUecTsJvGCQeG5bt8pYEmtGKB2IZvgUDz
2hig91Z/PiZMOTUHDn7dJYq/9Nbmw1DHLa76DVY42aSpOsr1Y6bq2AZgletgkjMZeEsEzO43qsDq
2xGAsg80Zx7+7x+YsyOs7jjKtPWpXgYG+AwVX+DPSHtGYV6EvwA1hxrzAbJwB602iYUDBFOW8sTF
oKbY1Aj8hZ68wnJfNpXi2JcTVohiyitans7GTL3rN0Aorc+i3Zxi4Q5DnXqM1HcDuao1knGj9/MP
XNdyyT1SDS5p+bavot5TUcXF50bbwlLzeW01v831cNCcG9Ujhjoq6rk8p5wthAL0MbpkcTETVks8
ktCq7XXHEFPBLIdQ+4ltsPxE7IaDLANFZOMADJ7ZVFnHjsWU2dx8B1WW/mKjowmJD7syPkJaFIdH
YA26xXzbxjaj1MhvOnanK0+i/Zwkra1sykyG0AJwGhr7IjziKGIm44fNplbY6xo3Kz665GHk5PFC
IV4BeVi6HTc7boS+g5jrJtGtOHsfc6LVegd96neUB9kzAjvdx92W0wUoUVA3UhGVYx2xCp/WvpU4
9gJtGtNOa1M77gIGtXnx6Hn1byCDFKpgDTl5iMWc1bd5UjIB106Jk4z8/b7ZIG4DA0oCHl/DCAPP
nKkL0s/CUj3fyH/E2fUyeUPEISja6x2Eidb+XWn3UuQnO+/s80pXaXtKnuE3ZiSv4bToXGZtFZhQ
SYHCIUPVPITcefWmbHp2aCUCu68oN+MDl+4mdBOE27inVBA1g2n9XTSYOFQuv2GqPZreShcQE7hU
/IKwW6p/BRtZZuqT443bgYJdRoxZGIkUg+mVgKXZh6tHksb2JkMEDHvmjy/EsAM+EkoHPn2xJrP0
lb8B22vPSQh5ouGUejA8BPlFLFBBhShC2U4wn9HIORgmkSIN8JRBH7kM+o81AWAWQupGBhpOlFSS
mOKctt1UJfy4CwKnZKUFHhKCxaWemtMcG1xhRVg2Ky9uwkEaQx+SmHyxxs/zUP/i80SbEeRW8dKn
zX9PIL+sdI/uaghYnUqAWPI1PP/UVexoQggY8Ow9+kJgYnZYtmsEuFn4ZsEVvWm8WPSGObpwzUsC
bc8Ab/yMxKW28nUVfOBpFkiluV+Vlg6XKPhrzvAMWXJQBMUjOod2rLJvHh8Ob1WSVxphxJY4luTD
la0b9Lm+wyrg5chlzBsUrr/nA9a4AB1UkNT3C6ET9dV3kYZLqN44FofmBFEyrxgK8CBfrhBnAJby
v6z7H5LEJLFefdX+ES65qAqCJFuYJ4XPdfQhu+Wf/pFds91CpGvy/ECDUBwSBhwP0ZvMUpcpn59e
A5dyhRh05Jdn0KjQf37/jMVjBQ7ijVydzYa6iCzsGQnqAtJaXZQCqGXiPutGMJ8cAG0VoYm5aMRl
2i08/e0c8F7n7TFNbgIQNxWmt4nJ99CVIii6Gi29w1IaplE9a8ro7ud65czporTdtacOfZq7Lm0Y
T1Iyx0FfkuQxy02BfOojNcVKaEZ1FlszlfKT+eB+cdr6zYk9q7QnLwpjrRK+LKQGqELoR7b5bcCj
RzAHHT8h4cQs2zuBKOOGhNIjRzAV4YAQvtRuj4BaLCgULi98jQfOLnXA0XiA6EvMBUhEjjQwgAty
vdqt/oDBvqQHwooKSikrIZqY0PbUr6AJuJIycdXwq8NzPOoMSNW8t+YzgXPbN8vwr/WRr4QXFjZq
guhYQJEpbe+/KYBa/3s8jiO1Zwxda6ezs4SrAyhLPal7PSW6bhjk5kR5s6OUZpkM8hpBSoikc11o
xs6m83KBB/jgqPswBehMoRYqPiX/hnwd4ZhYwT58BYVVQthip4L8O0eretT+YOl1Rmz7Da9LfFuY
pAmYx3JdURw1mc5320AOkKTG551ZAImuX6hCTglI28HbYY14T3JagZwYROsLp+JPRSk8IA8fGu8e
JNXSsBerrXNKMT5ESAw9A5QZsa0KWxUlbNZTv9WEGUUcOtzZll0PxrXW+z6imC0lR0wX4BzdylZJ
Qu+5Sb/qC48rcC4Vsm7ESUKdz5yuntIR1lba9pitAq3MJ82Ejaf0cFrwyHuEDF6ArvIr+wHxMV9g
GDzpBVze1KU0V+xSj0SDPnO=