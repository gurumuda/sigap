<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo3hj+ZzD0pF+5eYouQDZWffRq3YbB4KWecuDMwkaw1jIepRqw2uT7ia5+LsyhYWXr3P7sq2
OfdP+ehwb815ZlVsO9HLENpFI1sC1aj4153yXhiWv+G9cFndmOvn7lSRelFqamyG/mf/WUp1NAS1
2vnnya20OrrMlx28hRnrOJYRwy4PkzKOiTNU0jTeuESzQl7EqNIfH3MxnysLB2/9mKQepV3gSPLn
Q/kDbvNDueG9y1EKwk3YlnH0RVYFVfegiupB8X5jdQPx9E+sF+Xmx7Xq3tbnEJ2C9TF7zNyF+RwE
ej5aY5L+PkGMhk4ZEnDd6/9aYhpe/QbI58+PL2pQncZDA/K3An3dbGgS1ZMge6uvSZlmySb21m1e
PQNZdT1Ul58vkKB5irf/7UEuEJ4EcSqbW4ucfquVrBM5oUwCWfelbHetEoXragYF0bXzuI7fzB6x
H47rCqJ/OMRSK7RVcX5IbWY9KpehDo82ujQ43Ivsn8qsBF/4c0GuIsPQNkZpfPjDIj7VFJXlreV2
On/OLN3gE8ik5kmrJdl5XS1/wtC8XGMsjKe3kJXP7mON6oKMTFLMB00LVljxytHpeiuCy/kSdrHG
LGdKF/lx1vDYmtrfUJq8WAlOamqQT86Cl2scWT8qN3w97Mpoo8xR22QUZdesNECQrNo9T51/D/kp
9waoz8ACNikD5pcaE7A0o/ILV+pzkehfNHOit9KdiaNdizm8xtVzmOcGLhPOD9mQJGSq/HbnRGOB
RpYcYlGQIQgGQWRwz9PXkwFsFHlgnXvhUjoG8hy/VxPJNJyfrF1cazzVI+ON368OyLoQvoLKaiDr
4sYBZ6wOI5aYmTVVDWA7wcn0DL9och433DkBIAsGbi3oP7vilhiJxWlsBpOf1xNs/lSEJB9DgMFe
PRH9nXtzfZCxWoyBta3IMeO7w4wWkfS+AZ+NB0W9dm37uToN2C9JNstuOSEw+67hWrACqKmC7bRA
34Xsth8s4KHtUFzRj7Ak+bMFT+ZTPUqYydTKeEmgUPH4r0uAgCvyUFQof0CVnjahoGShhdhD55qv
odDaptZFxgnUtycPvJBa/ic1GbHtElcOahCiScFXjWvpZ6qXXBGH4+ofdB4BDsKHWYaa0ut5kOFX
baYkNGb9S+HjQ+d+H9Nk1jUBzNoBbZzxhzTIPbSNWH+6G2hWPia13Ysgltx8i9QOCPP1HLzLQ/Kl
YZQQ0MNhRGYFb+jim2Z3/dkGdY4/qM8lVwMxUmufa2FL0bPsmyVHUB5xrlTpPLtlnbKBSAbEXy1r
bChN5HPets9bjUgAeqUAbNPTEhhAUixZpjYctAQ1mr512+ibEvTbdwgQC8A4dmyulVV4/0ac+A+x
QilqjAkAcPg+KR6jYULCcbbluFd3OrIiYO5+DkX0ARj4Y98RInfwmTOHNpHp7mNvsn5J8qzOonPy
VCby00vWuYhI4isMmAHIL6FCqHJD9BUTMKnQnrvzxxuwE7raGeTdGdtx4vZtRopuIbIasBMh+cPI
ABY2MnWRv5jVPdMK51BbTZxIhJGT1gG+Om4EaeLrULyH59KrKROTVT6vTAdAUm4sEI1es7BUMvIq
zZLGORUA3QkgeHPDsHjE36KsErMaqYP+rGtElXMQFO9KmAqLdy0Fy1BU+ekUcvOOJ16IXSeghbyq
uW9NrPTxQY9r1dDXwmA+sY0DayTOo1Ww6wXwdUI/WTLUAMTQ2WI9Ta5ywq+v3KkTc3BX0lEqXmLA
o7QrJeaQdo3sZodyc9dtxup6uOv9GDAq1nNFrnCMwEdeuiU44dvruekogu0AC2GXsKqSL2K8FusF
mx9YLLm9294KSD+Vd3kZ/KDgJAsl0+1Gr7xXPWys/wsd8NZrKAOEJHwjFXGzNCUoD7W4YQkWdlx2
VCTNht5TojGpffRA4/4ICeG2vo9miptF/x1kEOr9pZbyFOB2Kq3Hj+pYBq0qc1MPtnFe2rbKR7uW
s4xHUmlmUvofJCLOtaNfnZTlGIVjbGQt3C9GBxVwWAoeg1WHy9+o+yXWdx226F/YjkvknPZ38lK3
dBnOWTc2YCmK8MJSwPd40rbYosFVcAtYLEG8pEuj0Q8UtCK0yViIQX7AL+22x4CnbAnEibnowTjo
/Civ5x3ugwYzfezF/Y5khsWbrPqqAx3YL6Ac6fG7e3PU60hiUpyvrx5Pu0Tlje5+29l7FoP/6l6r
9ltShVsknkvHIdYwW6Bi9IkuXe90Evytf2+NpmHrOyv4keTKmV+6McBb7mf0buWjti6og5awvSI9
+PRulh+HbVR1f1miHSGusuDDK0jXHR3Z2SPvPMl05DkVtjtDhQR1WsNkoyd6GBnVFnc40IroYhx6
y+oIBi79ZVt25hsDdNyUQ0ejZqS08B5TchaJK+3zE8u2zual2C9DC6dfO19zCDg7i2Cizerc7LLq
lHInu8N2qmM6JbSB373NmZ37H4+GHSVN6mIKfaQ0R1zB5rxPnBDteb4r4ob09PQyEI4vyZRnSyjY
ViaM8YnkE+dVTM3QiesITxm4EiFrtwSitcGspaQYox/FDhRNRi4ZFTQo9aZTjnsSiJX4Xd4=