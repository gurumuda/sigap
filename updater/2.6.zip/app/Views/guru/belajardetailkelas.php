<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/ztrsDugZbOSBDbzbjmAulBye8ANK6lkx2uho1T2Xu1QZly8kNhecYRXUiMQ6umb9Fv19l0
77rsC/u8ypO79xk8OunYoJCw31AAHbFVkC7plbTgg61SfLQ/Mv+HRSkLAiGCVxXA9zmqB8J4Z1gm
ItrUEFO71K8qWRcHf/iZBVfu07etlWxBfsQGHA8avAMDPvRh5UQgW7rp+h2QHLZdlSTx9RXw2fPL
/OAHeo/z/6bWHDjh3Hhs9SCDRqlx5kkwECSm8X5jdQPx9E+sF+Xmx7Xq3yXc6YUwHQhMqz75+hwE
eD5f/pzeID8hMuwW5rIx2mKqk45AfJ0WuYPKHfwPGg94SGYfWwOYVeZuo6hPZt1h+NAVwHq8jaq3
QWR7rnj6ieBTNwTJu6m+W1J9nVROG5e6cWoHtsFqeC/8Il1003kmav5lHnsKr0eh+eAY1+rFh+o+
ul0YR6t+fWTSzL1W0kvsvx4dNLCOSyEGaFk2rkwrMpX3IuZgBuhiY1PQ/Wbr3vGwxcDU/QTujR0q
kX/q20gPIADxVAYfkMCGXjz5CkuABk9O6V1Oe4wQR2BodD2ZbQG0K97/QpcDyFcmSGR//zVXs4nU
d3aII8K3FamUorEzTojxfeuz6+vhZqFwZfqxqVMcRGN/gKjxEa75WgSXtMT6RnRwgcQ/pHWvdsD3
XeUuki04IT1RmdovjvdxKaJMEARZ61bigtWRu30N0cj0qdkc7WuPl9T6SaZqvi8f3pXXFlhtMOTn
ztuzkjTJnqc/IMk61g1H0w7d/KkzIsSkPD9+0jlju38x473sgl0c2S8cL7cJb71Jc0NSu/Ne2Je0
8UGGXNeK9A89IX9yLTkgQffxYr+0AOwicE5Dnf4fV8/3haoIw4PBfwGYrG+BaT3Nol9Aw9OiZdUA
JNzzE+/D7sBYXzV0GuNmYr2S0OXG2/aVxQ83laXzbDiJBC8S/7At2me5l+orjjjMnTDUiHc/LPyj
1BDhNVzAZ3ts8YVYArFWtu/NCL906tEDZ0+MmVFbme+e1uxpbAjbi1wf4+Q9JbbvhXPm3XDCxgoW
/Sqxamj1kFix8gdM6/srXAt1ziPGpNs9y9R5gSKq/qczXiHjZKbSkHxanOnwvPltcN/kw5Ed0QE4
57PqQl5wmkD1seQstE+UJzRcGaDKO7BqeWFitDjokl8Rxx5mUBLNGDY2MK9b85UNOHjbbKM01PKt
TCTF+yDzOPN46RYMjjw3xacqV1GleD+7yr30v/T8DC9svueWJP0+TvhijXh6djaUkVJDt2b1a8sZ
mhMM2aNe/GCnZilbIxeGSgV+xPYi2VTMC7T62nKGueTv5OpCQisLSrHcgauWjn9Zs0prZHu1R9ci
QycjiNwpJ7Xeaf5tPH/WFn9KO89mfebgPBwiePUZt4YGE29OQN+4aEyDbodYuYwdLe1OrbH/GwGY
6oYpGZzCkd5o1mmGF+jGTfvv8yiPQ5fpC0RVSDmB/7bd/0oSmIXGDLOdmLupDSY91SDs3FmqIr/v
uE4XRt23WCgAt7MLy7hSCRBlaloAYFv2kt/HOmmMkkSYoTbs5gs+whKVPbNWa9CKD/V12AkCFQ10
GIj/2lvzIw8EV2UZfJlrftRkhj5jj89CqtFHRJ6YqxMBhaCV80D9fZZTzpf+zlmXiOAA+JjEWFBK
/UQ4NZFj02NMKb81qP9gIWeWK/sXQ2Rdg0A2YWDdyi8/HB0gnrL7QS3xkoyDWHzMTg3Mm71X7Cm4
+5865fv3Pha9aAaGvdwk7ujVislfIIyMh+LU68NrAen+dS3GIql1qe0sTu1VuELeLbl0T3+39rT6
HmjWyOs3ZhIU7Rg3CZUX54EKD7QuNWCBYXhPvZ5WBbkGeOLsfdSk9t6jA4/+ePOVfkE+5tSRlUPX
vFVjlx6OgxzA1vDkSgRJH2yIqYvwRMsUus8SoE3hYdJEncgHotuSB9AbS3FIaYOYIwofYBp86LMe
jYe5/CegsGdmkBEQQzWWq/uepzQRFQh3Kb0zDT8Ia670C3zbDeJOKYJa6tP2K4uHa4ViKsrh+NGO
R1kFcmcYrLZ6W/Zhs9C0N/qcwV82uV2ug5yp4C5Xdz7IZ2WxLBW/Wfe5yjzLW1BCMN6WAaaElkT9
4VUoi0oPn+kyJ4oGv66m3okbkjtnhSRroia52k1SVobcGxlXzsgqwBACIyvdw+8Ci3Lb01hbPgRN
BvRcpW/HQuL70geG6f14DV/VGuIGxTjxx9qeQpRs9kKRxHeNlltAoltqDw3E/14hkQ5loY5vzCUq
bRCjyGtdQ4luFvhPsQkWCx/TVfMI0IBnL9oVf7BEeyhAe0R9icqTP/PXDQ0FM7kMqcaUQED0wNUg
E1Nkv7DWboL7JB84kHu7iz6RAQzfNKWDPXcxUJMsUFEsfVVcBaBk+IDODkg2kwwmnmkTRAQO9zBr
5eJfT/5YNfSwmB8DGYxaKvsQ3BbdJnr+S8pWSEtJp9Hnyq8XfWuNB5dc1YUC+lPGjGlDTzAy6P7e
8OduNA6LJbDPvfpMe9MyjMfDuZ04umGdzxXcNhanR9OjBVDSUd87LtAuEcFxJAGjeqEEeN/Q8j4b
RMp4xHPKuj68SULpXLTWfr6HlgS0gyVrx7Y6bMupM+IAReG6nsp+HRlGjK5r+H+BwnF6CXWA763d
JrrwpeWBv5yXeI1l/dHL1gI9c0dm6IHnDYod6IFA9vyOiLFqt8/52A0YnXMdWf5lG4fj5av2KaXW
EcWudLbGSq+DuTw1y959VEajZ/xJ64V0pPHJY5JqLEFZZ5YQH4gzs6u5yr9jG/iCV0bDn0kfVXAw
MyOaEW9QZjfI0+hxSf8W4xZj/md8TVERM6zz24q54Z0OBorxzpP4qEsJL7b4u+OLNmw+YGyZHh1y
1+gejjX1+HMwfxf1jSASVP9HhngJJ2qPLWpzX9Ob462eplVrPu7+WgTwk6GLIE9hj7wDHAkw/5su
I2fY1+TZpwtKOu8X5e/BURpQLJ3Y7eTkOsBLwDsZccwwwES0OxTMiGdtRhjdwpZJPRF+zEYoIIWv
Hcya0k6UDLQJirhUrk/XINblsXSKzaHc+AeCTc822Gqf2H3kRhVNVy6ryYblipKSfBq=