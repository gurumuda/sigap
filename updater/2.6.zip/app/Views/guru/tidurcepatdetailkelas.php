<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvZOk0pf904Zz6ejBrSQzXYM8pJqCTixowguIlv+4DQrLXRYPJ0kQd+dnEfXdZeYggijhk6p
iD9xqiP9oluIm6iZL/E5/ilsWDlBHUCge4uLRQx3lTBSm2YjFOPLZ8A/prz9Xk9lREoUevzWpLSN
vEvQFV6mWU3URv1XiHUuRx56JjJT+ZJHvIE0pJu8tDUYv5pEwVjXjpZqoPpmsPMV2BjMY6qRsJcy
1iCeh+MJRchkzZ1tYZCAgcQUK4urtHnFOCGq8X5jdQPx9E+sF+Xmx7Xq3zfmtvKrM1GvwyTzBxwE
ej4/0j8Ddry6LW+WnWwJGJLVmkFHXdn82klQ7MR0lzMUAKm93NA3bvITyxaqUantY0XcPpzZM20M
UxXM0iABNbNTTIuqDhXbrZsp5NJxnvdmo43QR53jZH+RnGy43S9bXYfhJZRImGLhLEXbVp8lFqBG
Wcw7uJ2S4qcxquKDp7IX6wV5cmH1XHpFjD2NqAWb9uWVWg/7AFYOE1G4vkJM/GONVrYtX7HtojjD
4MNx7EF/SOlB7LPVsj2A/Xm6QIljNWemBK7DRYwukbnSP7ojhqWBrYevE/Z5uuhfZkW5yQ0P2jha
kdUpET0KnRzpoSV5qFMrT/wvG56F9D3afxWXABG/PSjW+cc7bNw8V6c5PJGjsekw4iAuhsP2YamL
oyhaclyPExBapcoTHvH1Olewn575c9184FoovumQy0YqGAZOCleA4+dMVy3VvK3Upj2Eq9q0eHqc
0KbjamLqfYueCxOv1jqVd/2trsoVn86J5ZahqZOhhHbJKKnAjtqas/2wTOQ9D/daqLGTdObeM1ps
3Lg0SOaKKNdWPUTf6ZDD3ITcNaLNlRE9YXNaF/zIPNuHu23O5kYUzPkP01JaJlDXT4koGWmNK0Bt
ITLF6lUSoHlRh2P5U5bo/kdsj9VrgCpgAI1RSOhSMe1RIkV945B6MQwToTK8tQSh1uA9Jmd5EIwn
aLFboh7wCWvChBUwALkP2kYtzdw/TR113LUnVhf8ODvbEZMHJsC0KNfkfWZ8Ya4OdFr+pLi1/0Fu
Je3hOyBPyzAKy7qFSsfDwENX8R66yrnL+KXTk/EG4hm/k1tMlRtxX3119VUZ53HoeFhdcAKUjH8D
LmYi2bql2gKkX7UwBvs34YpW6nM/OedOKq6uMSE+ErF4y+Q68YQU7qpNC5rjCsk/TBBIinI1qUqS
DJiVaIoZcai1/v1129tGTjM3CMwGEp+6PIRSgBEHH8BYgJd6ahaThl8LZwigLPk/nLdmAMHwP09v
geis2VCHFxbM5GkMyjXyi0MReun2YjjW5ggDSAemevmGJVwUSkrQBQEpP5BAQwKg/y6WWluf6IHS
qznhUGk4dU8nXtD0eJVN7MxfWjPBJQ45dyA2y5VVhmFOx/ZM/QkJQ3+KlJVY4IjV+k9DkocCbUNW
O4gDstP/08rf31SSS8T7WC+k6jbn/v2Clcaa2I68dBq+0cd+DU1hT8f4WS6iDuHniSZ806oJnGSa
+RTFqyFYBsproXGi7+KUTRb3dmn7tJ2t1ZcX931JPex5u//f2wvR/IYRgvSAfkTSmD0+qv8n0I0Y
GF6vAX9NtYCMt15ilQ5N7iSqQJ4xi/Wc1CfCupjHcPUDZiEXagf5jPhuI7fy285kXGmxugJSwNoR
AvddqeRbSaYHhd8V0UwkLyZ3xpuYlgn+TO0VD4y4b4mMJU5a0Rl3yvN7LL0o9gMf5Wk27sEzTfwZ
ITm9rSLIeX7fE+LEBE9rStrWQnkG6ueTNopMhiKk41KLqXnEyGIp9lEUG3dXdaAkJkb3uFQqA5v9
A9vDkrmwebG1gio+sx6AUnF/jPJee+/Nem/u55nvPn58p9hmJ/s3g7yB+hls4ZxA5s1vD81nwxMy
ATtxcXatDUgKD7ir3P5A0VHYWn55TBjtkm+hZYtOThjN5UAy9SbqR+i4rvYy3YeTfYMxe1yYc3KZ
1zmkCDzoVDniK6DBRQvdm20fjIBus/O9rmGrD7lndLyI2Mo1fcbTbQ7SZcmZA1o+lTPwBoIcdElp
MiTr5+i0xy5p2qhjunEBNfHth2KJTOz9ixcCKiBAAKIFU4WSCYTD/RA2OBdlf453uug/PBDzpQSE
+4ODytCxSOXk8qnLWHMBbYgqkuhzYg+1CtUn/outqY0VvIWJvM4PhSgvGiLEiOBnMNEDz+KYDN7u
MWgSbd/QLtyjtGNTm7rodkkrVkRClG8NGsPML/XMWmPrS0PgxiAsmkUN+fJbTMW09yKQGVxSt2Fb
rs2P5KUFE4xg4598xX/vWH9Nrev8mZb6J75PwT3cqSZdZ5hu4QnnSzx5x8Hk6fSDxakvehHqCnbW
5wUSHwgAjxvE+quRR/Ktw5dUENsQ1oS+biBcs05JCwOT5eUrsziSHpPrvoJ84nJgvqB0ZIirkHsT
/WWT6f2TLR9lXMzdQIsbdWgbcKJbvLEixoJZ2g5VSTw896JAfkw1Cs5xeJ9s5KK7arLa1NpaUcwx
AmoDXe7R22y8W/n4A1WFbhIx5hz16qmRf28o342iTkezrDwiISeASF+8j7lRf2MmjJxkvNBkSadk
9uUbgrW+rRlQWGKY73Z5yuYRLJWeZwZNFP1Uv+WLFMsD1hAgE4uRc0nyDlnER3k83SOKzKfM7svW
8iC7DNEgNAejALk25aLK6THLjZa7zbYrOH6huGmcTFk1quCdgD1ndfC9ItjNk3IO7eIEEW7OXGSM
MYhYxo5FESgQUoAqrAeF6L/8S5TdavS+49JUsHlRrwatDbDg886tX/C1FqqUzcOb74xdThYoemZi
uAdY+HvadBjLSEILMM4RUBc8PyBd+0W4KuU/0lx0abLTwRYq7eENWKTp7CiRwbUfBtmsuP2mu1qk
EJRHUHw8coT0zcKpwoQNW1/6dzQ/ng3yavgb4QGkFqrhYJyFjq8o/AW+OhTwnOS2UHP/7a61kiPR
2jDqpx7W5z55YI1rlArC2HwWP+oFWkbBIYkyTn0HB4j3iV4BjPiKH1mjMNlBbLEo6M0XhoP0QpdL
/iSqyQwLFwid7Nkwxg1715i8bEwlbhD5Z/WF89jIiDgsf70K6rj/Zer1RY5YNE+peoPDRSJJb7E9
iN+DK3jS0sho1iIpOVKXstOhXa2ohWTBkG==