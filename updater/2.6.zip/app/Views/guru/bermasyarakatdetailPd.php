<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwjmA8Geqf2hDS2zfpxK0j7WgQyjGHNzTEYL6CBdoDWUfEIM3k8iXMzwh0UveNZthpcPYtIL
UHbRPdJdeuMG+Dh/L8WVUL+o8LTYB4erR20Ojv5hEGNeljAIm0NCyDWH0ZVbhTb9fb2tbSl5AG0c
JaLV79x8IL9qijZJ3FdTXNa5xvcj5+Mia+U4XeUB8TiMzFudWXAyA1/yR9Z8JiCoP4xakDBn9q0g
TCkircC4IKwn8fmEshjYVINaLovbBfQjuY46G28HRPscUoJljZ/eSEnuT0+jQN3HgxfDd1juULI+
Zkl0D//qs9NyTo1CHJiresq/k0KjUJOK7HYQZFkFaOMNhM4bxtGu1npesu9VfetDAD8GqirpS70L
4dCMK4fqkcw8FoFJHgMMcfTHbWymbd5m8vzFKYXYS9KrLGwrGDuc/gRKvsNxTNteP1ape1CAuHaq
5Ykk6ekpneRo2VpZvAmmzkd4sI/BxaxBWT58tudF0LU8gFkc/o5VDo0GrhwGJa8VnvwH+hGK9rWc
qFkruteewEEmqdEmePRib+ldtkek77IS7XTKY8MY61luyM32Q2whKN7N2do7KWrUEVCaegICU6OX
OOzNd+QQFcIQKTG77OVGwjJMuMIOkh9C1+Fr+IhXobe5WScFdEXTJnyaiSDOypugQpB4vRwba24w
Ea3E20iVjM+epdIIFP3MIU33mT1BWfHH1+Pq1sT4QXJS3FLs6s0GjKc6Gar/zEXhTkOiOkEmmmTV
eU+WCFjx1nrqu/TC/HFMZhD13QkPeAZrrD6yVT0xI2pQPhnRoVNMAnP1I2OCz/8x5OMGSYIXmKvF
2oWw03sRGLkkyuLAuP4VIrMKKbSc8C1Ujmaf3drQ9XUIT49Ok6RQ1HgjkaLUM9JPLdpuIMH1XqQ9
w+Ewr57Y5IW6mQGIom7/0RBM98KtTVOXdfZnYsRiT8x7eWBWShHWJVyX1tlkJate6yM7Bcx4KGfI
hW+aay9CfsPaNo5CuZKH4FN068g5adDUp5AUJOnqSLUr721b2PmBEqPwgYnpnZYowthbev0Vtsb5
0hbUjBUYrxysx5zaAh8MQMLy7KyPAEo9EbwciPSRHe4BEcyGBgoBWD/f58bCjgpRwQbu6eBrVoKt
cHXGA1XCTjFYmSXHK5ZyFWAQ1N32uwgGwRd9hPFMKJJAe28Du3NsxpxniSX3LtvvPCmo98YZRc0u
VDEctVde6qCQE0gSikrWAZeh1/esJTzXlDtKrnaQ+HQQMMmVYW97vQ6BXhN0zXuNVnTDuDGYs1ho
JWwkUcYpVjk/9em4CWyikBGWQyB7423l8C+yGyYIeKWIYQGrdbrcjYklqbCUajRKG3LE5IkgDtcv
yHfuvXEDmhsZAZ7NW21vUDa9kUt94g7shhdRgKZy8blhlkC1mEPsbTmv5zGHru99NVmUovUu+iot
zu9J/6TYYhtHcJSk0nXusOw93MzeY4LcWX0lVquoLSHA01BMNmY8GmWFGNNXtr690hsFuLrVvOQa
H2rsdKrY60Fp6tRyuQdMlsRKc7uaT7i4vAzLcTH6/LzbHc0ByGajIHgDPs5HbZlumBtgu3F0Arog
VH7OpalfnX7gFxAFZAz9QFYDhbeFTJHLsEtcokShwxkyItfocerWD/6QT5JdNle8gem5etn65/zN
C6bSV9faBASZA5xGnMC/PXW43v7xq/ARTbHOv+VcGHDKvFC/wx5G/w9OowpSq9P4PxLwXWBd7/o8
r4bqfqMVV+UpagAtx8ghpwfvxqffT7atHixulC5UJ5PRnKxQ7480dcrjR1WeoM8rkwyX2mYML/ls
55T7T+BDJiwUw9p/5HJravRVmVfOu/1IopyBiKlnC6ZXKqqpp3BRir8fI7NFqpliAVRGyPGhtMQi
L6ZJ/VCXtpPUgXMjWXW1j0lEi54eyVTL2LtPI8Gf+/ukjboN1bx0EsBBvaWfK2E0flHaELILfbik
XbVta32S/R/utCl3jzGEzS+12pWl0JfYvzXGxH1Zn3RG/2Y9ptPpvoub2Us5U9hN+PLVfomnEJI5
hx5UQnjmMEzlqNmTwvOYdy8Dmrk8no6NUgNzBBqL32SSZ8QzQjLc15wSUGDMr23mRlNxfkgIV6Qd
TiJZBFfRjhNLYUxsxL3ZftO8zYTtc2Ol8OTA3UVihx4ey70eiQatdONYnVPkXxFosue6lNMtfSuo
WB3ubEIHPK1l/jb6jnuOdDw3xKGDLX1O9iHsYbLPZf8vX8JpFIW1tesAgNI37eA7z9k5ZD3ZWLpF
NswtQI4X6wZq6SNipW+7HR2f/Rchktlkrvi=