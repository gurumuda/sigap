<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPq5QnhLHf3gwBEfJbfeHzIypqnqqgZB7aBYuzytytqlNeFJgSs7VbwBavRhuDUPq1owVteJY
B7ANOHSYq1MyS5ybrOVr3Lc8ESkgV5Lx+9pASWW27ypf/LLCCI4j1XNnC16r8uUXtWauGG9VB5AF
y3vtQioPcC4OBAuxNF/wGsDXaOR/B3sL4x76L6KKvpyo4cqKJs0oifhfrq93urauw+ZGdv22qvwc
xUtdm33M1KPbbWqMVbOBc8ic2KXJeasNxJbK8X5jdQPx9E+sF+Xmx7Xq3mPdbUeOu1KzyWbyzRuE
bz5q/sb00hQREzsgkJv8YA5hO2BA1TRKk36qpoPBHebVUXaet2Mb9mQcUj2wj3SWc26Uhgc/1yiW
MFTzUAxW7//cb7zsCT/K5oIjrFs8Y5c5upq/2kvRMYGCDdvQlklxU0zdIbAUbYQggxNS8KI8dhFU
Bjie0J6IPZa1kLx4yLGtBd5kQtDOiwYCV0mTRcTqmg7tZ2bRhai8Yp0NG+6foKZc/KLxJGJPwlwZ
33Wa8hJrDaqAP7U/nrUw40TzZt9M3r0H0gz5TK9+GZSrtj+zkDxFCw97HkbjPtjXAWhNX0oXDXct
goP3ACEJHg3pBtAZnZFF1cnT0tBhx6IiEDbkdpb6bpluRMIw5kjSGpUa/FEqraxZtCoCdgPGgD5U
cCCvCyFFuhF5PsMgPttc+xFxs+Se27M6t5cvCqUy7OqiW2v9ghFPXjrilBmd8U90AFfwgVZyjURU
bIOAVfWl6PJniUkShV2Slk4iin9aFc1n4CljUBcdU0F7LrC7DhsKnyQKdGr/g49Gt0IrOfaGFhM+
jZ8O3KhiZJfx9OyKvWUeFKgNnbG5o+gqYA+wRk+2veEVjbUwg+Ra25FpQx+pA1ry8NoeBPGMDc0H
9/0FpjzwE16Z+NOfRg0j3WbeDDNTbynuTN3PdICNuF6CCnNT2OkJV0LEJkMzURwYgb2QYt+R9Im6
2xsK6pr602RAa6lY6umXjtAVU90i3X7rcFQgciFh+V4GsbLccRruyleitvnWEO2oQX6hTP6Eg3xu
5wPei84tkL0d78h7RCQtoDtEr8cO0uvT9Y+LfHrsKoOndVuGUhwiC8q+r/W5VOreN56MxRQJsgPO
mwfQPRNQe5y7Pd895r00n3AkPdNZXBwvtv9/1kcuQaOs9hoI9s7LGtFNJoPHHT87Qy4oZVU/g76t
ntJ8Sri0lLQZzOt1r3iRoTzC96YnOkdATmac+1du95pFVMTuQNmSfANgdndcFZ2OIlLqhVKK9Guz
6ngcmBWX61er9bXxFntQIL7inEN1wVDw6uwiItO0AvTcc65EfvBmnoi6mJMe3rhrgREw2463YkNO
3Py1mmadDi+HtFs2qSJFg+Tke64sfDekrZSOP0jwVzC/WcRNDYKugv/RIpJSktM2hayURFaVrgLb
NgWozVvI0vu7i8B434kcKynFXC8T8HakbbAcI9XBWIT897V4nKhoKQ66WAxIgYn/tUBLpCEaIL2q
5zUvJQvnA5Ji5rkbgNzo7D8+23R7gsVC/puB2sLqwCPrA7Yooe7JXOi892DaUddzSwAQpvMphPYw
5Kfwlqw0M4E6RX0zh5hunjgabVa0hs5dw0YeQX0snvAwkyTwtQqoH57f73fAQzZ2LhKWNZJ1ViQO
sVGGe/jbNam677pSA3+YiYvmUvoA+7D56pO7cl8hK1F4hVaS5lTNPS3rA7B/sWbpImm34Ccbc1pe
KiYpPatlfbsyU5p5yTt/UCtaFL+h7Vj63ZJGySBnqA/Ai6nZ5XC+FplAixKX0AbOskFNiXdQhkZe
snTsgyb3z6PSrnGJUT3nxuxTFOxpvM3I1jX3dvUlGiKfZUxqtz4mTzyTdf3CUaWvGAgSDRRAgV8M
QWaezEjvE+HnWKHB82B4u7G5Q7tYX1k4eF+upM+Ngm3CzFO3svfxpDfoC+0SMP1wi8tVEdhLmwP5
G6CLk6kk3BKKH+Okq6diVBPGKEXd87W6SySrpnm0y+/qQvB3OT47esQidJbT/ZjXB1+xNgLuag42
4XzG3o2vk9UDhQ4lIbHfu1RIkNEAB6sUZ3vltxouwpLxYJYeDSY+6fscd4im4r7abb5Z3M5aE+2f
aaePNeY7fEZc/HOsrblx61IShFFaJO0MwME8MKYQVVLUHuU6DNmTGvadPyVHSbzP2ULaoe8I8tiq
5p6h2HNFP+Dk0N+FJrdJA1mayW7MvQvCV5rsjR1oa9Ejp0MdfsdUzU+9CoxpSWpWheFJ2a+dTq3u
/o+4BaJtl6q3KjDQVR3FXkwy0MY8oyo59+/KYLLKvnSMPEtajKxUWRSNQgMQL4ul8mtiJsyI53ZR
ZqmV4lVolEBbKx/vi4BA8hjwvJgxnh0vDN9OIEcninivhEkIiJWxrPgQlWgRN9HrGxcOm4q30uU9
4Ha+ErvLZsKfv4Yt2LigkVTB+Ttbi40ZC//p