<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpV5vxUHAjouR7Tob1GRoP4gFTO8ehu6PRAuZ9232D7voX3YO1vpb/J1Dm+0U+iNtCFIfEDQ
0K7SNMIN1ditoD+DqIBDTjMPAP/dV4F0PPGFX6LxcEjzi05JflTzzBkXwJBQNrnNXUBFTevHAglM
4X3JaX24G9uiVvh0CcMAmetuUMe73gfLydOH0REZfkzpUJgg6M1ZuXTv+rTO+hjfI91GxTYKt6rv
nIFQjFkyWPExkVFuxTrFWGc/BfCU+flgPKO68X5jdQPx9E+sF+Xmx7Xq3z5jEUsZTCsY3a9IWRuE
eT5Z/yZs3F9sImbSSj6HcK0vL+3kpXomV/uK1iEkLzCgKMHSFZii3ilraDICKIUQ7K2h5/GvuKCR
EQ4Z0d1blpsbNqsgZgAMwqHK+/nR/J+7eHPw7xaAauTN8qacEFuEXICAlVLlvVqiY+wxszFmqH8r
PlN9MdjKzBP9ca0iz3IafQW+RKWMLL+zY9+bz2z7NNZIr0BpGHMtGIBvaERr8idyzDVfyW74ilfj
mn3JEca0FTA9TY8nXheYL3GbE26sHky7yyfCD3AH6gxCE7tMkldW+qiQK+mqHYYYBxisUUBqzMif
dbk0eGHjGFKw4u1Y1GUhPYFKWV8HMrRvdH6cWMsIZ7PzFMXGH88bqcDv6/nNU8uSCwY0KsVLiUXm
s87EwpQQucGbHaah2xL/JEh4BMc4RnBRXfhuwkLktOuYfxo/PXURWi25wmK7rYAZ9gAFrQJMwiOc
c4rTaXl5NOHP/h7PrYDxkntkTKVskq4g2xRt09gH5sNr04/CW8AoZR6EA4UMMZ61YSJScauOJlZZ
2s21F+Mr5j8KkFkZO8Id5QF5cD1aCiXHzh4b+5+WImiITq475imS74dcD86YSbhVBR/Zf/C3U3Qr
cMeSFZt72kgUP37h8MBV6h0RudgnNuyjUfXFanQzQjMEzkoThzx9Vfl7hdjZqOLmGW/LEXowtqTG
ePxKuncyJmStGCqMeWlTZyLfzyBY4zV2zBsHjK0TIT2QVEsiJ1CtUa9w8jfiYXMGCpB9gVy/qjaL
TTar3/SH3GPD/2Huxfgs4WsjUIsxBXcq4yB9bWhIwREkn+DchEvf+UGg7nZ8NPVPaHOGGp/Th99i
VGKZUb2hvnV2LGwI5EXkDdynsKa4BdTkeoLV7dW20WIk5Lg4Fhh/XdntRPpCdWkpFl2dO810M3N4
L8Yfrc45nmdQ+DpkOn2r8Ru/NMt6BHnGJj1mlFAM58H7nwsojadoiDtl21MSN5EHCiq3/iv1MqG8
3xD0UWS4lXEh5sDMlfLGC+Hqq9MJp4ZHr9b6FOIBPyvjMofimgS4oTOzEll5ddi+Crr648rY+pfQ
XVFBSJBr8pOrLnwW7+w612JiLFkkGbkHTX1rfkHKzbhXRnnZXrjm4R2l1gWIS0sy6eM97YEcYHqX
GoJUuA9Lm9KkePHmx5FBPrHxW+ZQTp6io7m3dUMUHGwZTTRjxK+YaNviWCskWgPmoKskC6IObXvw
eKXKLaSSLkhI6JG8744MQhvw4HaQd0SAY6hPKQeTRLEtO+hyjshImnWw+yeiDsC9IoFPmS28CwC8
h2T961NBfODQX8nRbuIqS3KjtqtgcZiOhRuL/Hyck8Cd/vQ6A1fdm7164BZ8uqoByrzbaXMcHdcp
RCRhuj1GBWl3Yw5Ri29O+ftXBjJFNDgM58ctQZ6IEJjmk2Or86dhJLTf9erG3ZS3xZXu6tTTnLpK
CdEueVhNFxG6tKDSBtGdbOHwu9FcaCcEtTl0DSnskoN/+deMAbxQeA9h+memZ89WOwRTrSnqJbfF
qTtzA//Q2qG4KTtbLK5mPxn0q9kt7OJiA5XSZbTD2so8mfFD2mpX77vapnFyXWHHTjucPinb0xA8
UnIRHc+Drc3cWzM2pbhS9JThtch/XIIwJZ3lGRIVucCzcmgC3OMk1flQrs5UytgKpZ3eQbsjS5us
Jt5T0n7BFuOBnQSNNHCbeT4kSjU7h6IYvMZfkU8+Cj/TdXBsUUOGEz9fKVxBAHg8GuzJaK5xlZ8c
EoAo0v0U0wY8xQ4HOzYM28a13UIBG16V1fQTXF0bsioVFhMaQ4VKfl04R0Z2V2/aIOksKfdXflre
nuPpbN2nR5TOXf2+Tgi+dAaAl7+sqq/FpCEkgg+964yF8fFvKXmx7gtWDTCD8JWMgp9E8qUMIYFn
s37ee6mgqsXeBE1wKCNaTYhEhdpstwQquZBebmpHtwD4aAxjNmAypW9BFgknqU3A+uzd65WkyMQ0
3rQZIGtWrv2Mmcbhts1XrYknoaWgRM7SXlE4/MA8EN01VbU/A01fr4bJ89bj0g38VEdF4EgtAyH4
FHUhamGBPOE/6nSfclsdox8E+rf5Kf1lmlB0SddHVoAHwTnd9Ii7lKJHSv9neN0uAbpH9vmfKrpH
cCw0O6lQXEwsVONpKrUimIpLVuhhrEkvZbdxAwaY5jl7ubYNekgi2RrTQDX2K6Y582UHVDL2uVQe
IrqWSEe16kljKendUnTNx/fgCHkYBzcK6bsSjI6Vvy3kvEJe3LibnMWjwZuDBV23kvvMg8EhAHbR
ZAttRkB/bbq8im2356B/1a2Saz8QZbjrv4vE2I8I7d4SMrAIUwIZ7fTvg1yihJ8kJ0pgvFh3DWsi
5LU6j8LTBHGlBOEWjh2bdHuMEfjvutODCuSvRHh4jUZ2qjYaz4umDNaT2auBOBKzISkmoTmri30j
0NnX0COLMShvXPVS6D27bYyCh6yb/1sYHwmrEs6NLjGTbwZ8TzbT07xLSSwYa78bRJYaDN3Z2aIK
tB/BR3BDCZ/TCks9EAD/VwoUA+wiNA59mnV2qEcF9sVNEbGiM2jyCGFCIl97X4vg37IWUvdl63MA
RQBPEdzn/120Siqw7F2r98X0w/++JR6EX9tlijb2GUWtvEok7MHx9KzovM255LKgrBWVT7yPiZZ2
luaEBtx7/vYCcN17G8EtCCjBZ4aotuhYPQnyMUoudRhEbG8l2CxfqCytgvCbZvClA11KSrwq32hF
B8P8VZ0ix3D2QTNxWCV8alLyS2riR0Ygu90EEiu1qIQc0VWU30==