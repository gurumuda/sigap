<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP+pSxU6d8DRMlcvumYpNU3N6q4sZSgfvSAQuU2KNf2sCz3RmFQOMKASxdOxR0D4OQlVR9waE
Fhnk99nUn3xOSsQfkcN8D8hdT9N0sDlgqR1qxTtJc8JVr6WsbSIliH+u4JdOV7LnAg5e4bD4sjQv
DipXawcQz9Amr1kKr9oCuK6n/kp707SfpAXcI2T7bqyZLP3DnfX6re9oAlRS7+sLzE3yFlE8c6s2
prrL/JIMQgpFX1O6VkRDCyZIglcOHoEXoQNw8X5jdQPx9E+sF+Xmx7Xq3xfqYas6gwgeLlUqThuE
cz4/STpumCWgXbcVbwQ8eLsXiOLyQM+4RWPgwTEAO+PR42Zn2/WbZawfJgtZU1Ax8TgSvQN5VvPV
sYUXsuMicKKwGJPHoQBKjl4NXbLSB5tuap5Wg7sfqtwYaljo43tdcmmVJoIrwcHGsBZC4d1rERV3
ZugYdpTCZTIQO9zwX82uAP9u1iuxP31frfQsWzyPQYXNhX77YYNprTcdvFtgb09bN5QOOOxKr2T0
n1fvzMDDpbVelB1O8VHJ8/dZfXrqyGAIwYvlzuPlK4FKi1hEm4IuoC0BKPrO42/x/nYZ/vkIjiky
s+o3E9Ra81HhfN0nQnysU86UTS2ipgqZSas1dR1oz3wdS1Ew4WyJSsIOqGoxQHTEv2kmyuvQfGQx
86IqDNTZ8ARPtlHY46KxV6u+KQjgTdNyuF/Q4jp54+GwQUSoh2dikOgZxsY3fri+dvTzou+voZjW
bJGTCzvRofHZBRLqrvpaasRQD8ONIpagt/M7Mjfa3uo6gVPsyc5buWaHyySNdMfG4MC8aIj3c2qm
cViHRKxClZLxS99MSstB8fznp7YGv2bD5+v+MxHj4Ax9mQRtAW8DmNmUYwo+Hp8S+4Lka+brH3Jo
9iNFzszY/jzFnSF2y4AYfQqdz1GE7TI43clZ+qI7NZ1o3HmT/angPlF4C+utcuJmwlPs0O5st4fo
Tro82CamKShlCwg0pBkoKLCMaEcKDAQniEvq5eoeM2Oxigq5OQ7vSlERioi4jxa1s6VuLUxo1KAy
X/N/TO3WVTenw7wiru+kaOGgxO5BeElglX0a6nZ16wqYWozohgxuRhe1CsOa0PanFTb5DU/DPM5L
qZBeGjlPiCrT7PqkxpqhSlTY9sNUi07xlDyJHFAkM7feTIN8FY6kqcElhT2932/i3E8G8//EyvOc
S4j2nWqBRJqnvfEOO5J0Rd22vcS2DdaZOkQmFxfnhqGmKz5fPkQwW2fOjfZg6zR8a9gZh6ecYvCZ
+6Z/EHV4Z5tu5JOIq5o/3IjXIy5Uc1ncSTHknc7UiCkKAhNdQi9a+85K/oMqNsUvcPuUbVmlXALl
kTJNDhjQ6Ht9kZPCKP5l2i4aIMgnduREC51tC04dPKUiVGZREAlZV6vDGDYI/6SqNHwWRthiEOhl
bKSVGsWaUKC1qW7yMsr/DInLYFrC5oPPQsKuI2HtPQaqCckSdE+dOH7fUSHvMU2xQWI+96vUXv00
0QSqP2xzKRcz+brEXNR5oZT0oR3ccAjUCv57eRO/wl9ZHODRc7t7U6Ev/xXeZGcx6zEKm0m2m6hZ
iorEicMAL7lZMyRC7gIYOwDRMqhmbVn0FV5UviKauJeQVW2CBfJVroN8xHg1W/KFFWSH6m7y/7Dg
czFI/ETUqEwt4w7JRcp/jD+541X5cEgLfqbb6EHGaGN+MJCzaO/MA67xvP8e3AV/G3dbLrsiEQA0
UnPY6rFf3nfvKiJrImpaqNWkb3TT78pWvWy7HjXzzBO/JfYB0OqKI3hFeoeaYrbtoCAdM61rVXHO
YBfdCuVUfQyLskManw2RmENSkrK0c3dZtLVEAbU8VltZK4X5MStwaSAnpIT0tvwszdmQU5QsY7Dr
8GizLE1PhwWWwS11/noazdIQs9HApKIYV8tH0sITp8Zl9Qv0/6SC66DTTmBtHJqVH2+lcHIj9Gy4
x/zH/fXT2mSz7Yf8aTXgF+ZZ4LsMuhv/kIqexR7JJEUVAYsj+eMd7M0eT1k2bED4UmMOXKx518Wp
s03cuGSVyJskiR8wImAKt7LyehAiWMw2vwMO4IKOEtLhZ1MHmCP19Msgo1ZvwQK7vv60gumqjsyk
w2+k8Y9PsteUMrk/4RZoM2kwZBKRXAVUDPFQ6IDSfMgNtlE9NSRX4tkvJjA4HfHOrYGdHq/3Fw9i
KVyck5cX94E7n9U/Hk4q/6j+BBppO3ZnKJchVvK30Xq4mRtCj1q7GTe7N4sZDZ3EVAAi8XNfJ1t2
fsFzZ88+P4ZrBTOIXI8m1/bIYueT9HkVdNFKSbZIlDBk2v/8RPdHHyO/6FWW73qrdpVAZ3akNlyW
IsItY5jqpimAkT/ISIfcni8ct4DPcrH1YkSv50M791Ag476qTZQQ8IK2wcbSn+wh4TMliaixZk0b
5kcrSFbJNWkzgDlLQdQsIoLdtEM+vkAAHSlphyQiX/0p72ADCL2bzPxNXnmiaz7eFtPRIFEcWgU9
AboLyHcO3SuJrL2Dg/xKm2PDOiBysbAnpVbfpTCzYhtrSLviptnUnxm2cWF9Z6s0y84a1dJsWr5C
4JBoK5d4Aeq0ij4tIlVY7jgCb0ZrCSFYvBecX6ZEnBcJ6TLz+sFN/sgjKJXsW9RIP3tZTTeDkVfK
9KANRXls1gD3oJG9pyKj9TmzwmpELZSjpH/i9WEedYCuTBi7Gye4bSfLuwpjaV9IFJChvOaI+pZ/
49mbYIsbiyxytENjvPa2jlirsyswgWIEBuFQdkpMoNV+JIWd/tiWgehBxu8e9ToLVlsLSxFagR8N
Oqejbfvfkeh2G19eiPaxgZ6exiNDEw85v3vWgBdXi4tpqr/stGx78KOHsgE6NI4BBO27dGs097gv
Y7wtndStq+mK6qy6xXkWq4nsA66YRZju4AoZten8wNGwo8XPYYdYDs5TGfEQNzBDnTy2QT7aUyG8
9+KUyx5L7VQ0+xUMeRTmefM4bXdBcsDIA7Kq6Ds32vl2b+hFm4nmNl5Mm6i4JSuEtr2XNszMizi9
1pdVK3FhQPbXkZM94Op8CKSp3QGgxZLgHIWLKmhJ/dU9wzNoAVdpkY4OsoG=