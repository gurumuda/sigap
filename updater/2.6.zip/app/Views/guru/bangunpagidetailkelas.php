<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrGZLWK90gigr9339cI8+8G/zDzA90S8JDj4x4LDk8XFte5nos6itPWK4wChv5QmJwq5CVq6
kvumSMxsuH3yR/baOBXcn3unRH5B6+gLbQ/9dimtgOuIz1qaNFiC6p6oSrp/OGPeU6zd5c50BL8G
2oIVW7lb0eUw1SU9WYbtufi1odNd5vOo8uZgKSrzsT9vTmSqAWHVLphw5K3b+MC/mvXcRerYiywG
/x0XDBsTun65B0w3vihk3CdcZUmN9KHZm7IyXo8HRPscUoJljZ/eSEnuT0yBOqKS+G1PKVn/Zio+
3g3HH5oBvlhuYjtFFVrLa8jq5+w1y4bUcjDe9tmK9/6Lk7oRGRoUiaJRVUEv3VAQEmSuLAKlGSiW
Jtffg6ky6S9eMLLHMF/J2pRWGNRMvc3gv+Fwv2FLSsKm2nK310iAx8HMQn50OlZiZqnYHfEUUwEp
pAdMcej6SWY3z5QO8H44Kf9yBYcpnWaFnFdbZviCdzGtE+qVTYUzu2IjDLMPoUHbioh0M87liRQ5
1+IDQOxTBax1spJ8Pkurv81hb6fN3y55xCH8iGvYkTeiHRoo6EZipRMiZO+JgtQXV8zQFrIZYdao
4d3wjlhiIDOetV/QSkDho3Ez+3aekNndMAoixBIEEZ4EWkf9yY2mKK7ETjUYEPaHNcSGaH9K/uUp
UYasHZz7UPNfiEjn7EVLS6dyqpEgugdS9ds3925R24CrxxczaqeBkvkzeeEfPT8xpW/WAtx8JepI
inqnS9SuzkJ6j7vRCxlYOYTqqWcypL7JUkZvR1kH0pcB1e1xCxeXQ6jidi1C26hDnkAiivht2+cA
XlxHl8mjE3sc8anKRz1tQHJ31rr4wWE5p5GQdTWRX10Qwtd2UUFqfLtex3KBA4slGRr19zdOJTR6
J/xy1KI2FSqoKwcjXmRkKALXKUOOfvL8ZGyKtCNIcmOHPE1N/D2BA3UWsDIgYIlCPrmHjYNNwidT
hPbeS1IFpF5f1yKxniUV4z68u7Bchc0kkm1U+5+IK4ZuZv7aOJ10QamV3EL8iA1q5Gu7nLkHNjQ3
aRdgRFLzsar73vQvBhe8Sy78LUF3zO2dFSy62ue9FmoFFsCib35/S0y9gVuwjTURX5FRsAHyhX3L
mhqBZhYp/8140A0MGLAgWFYULNoXWJkFv2VPoPaqYzB1YCyRRxcm5qFCTVBD0RbTnEg00WN+ldJS
jJFFISqrzUf7k5FbUB/5rZWIGZ/h21jHquF9jzHcYnBO0dxIlmsyo/OkZqAEM1tkDE7zs3BPLGdR
x+eGmLBO/8hVD3aqsYWzd6pxUXev/M/qXZe00nQlSokf7exF15KIUwOr1Ch4EizYyUX3/Dg9S3yk
MMk7ml/euUHpe2NaasFAXegx6/4Hudx/XCDw+gEPKhKYBKvGI1RVxiWcCI3XRzxmaM+eyC1pq0CN
jOlE+Rm47UROlpV+7+uDhe581Mfp75zXfjv5Y17oS9XlA4SScoRPLWCnYeBet1XxxRrYs9cpCqlu
xLq3aSSOBpIzYaklDzqQFHJR+HaA62ZTf9/93/gFp01TFmNSRKR2VwgsJ4K8ZbasK4LPxZq7oyGf
wBQ2jdOGbk9FS72PETJIOpwJKbL7xwD6bE3xBu11FVOnGdUUJM9Lr/V0AwFtvzFSn8O4jmQegE/k
V3Bs4RzyOT5oPHVh0dIQUnSh6n2ZvRB4gVOGmzdPEKaw8/jLjmI0110qazgn1ZriBtfqUdRFnZI6
ekGzU1KBaY7jk1CZy8azT1cKhZV7QMEQI2KDW9eGIdnpVcFSiSqmzfoM3l6unbv8HPs+qlrdfEdn
8ifc9tnfLOgphca0Ki8nmkLm7KI3P16/zWl1zIooo+lfoqO1yRYNeN4JyFeCBPN1wQ54jyH8DgJ+
z5X4f2JLETXSH8kLmS8MWLUbyin3RKv+7hpW4yspqvjqshepcoh3v0Lo3QalIETlofMt9KSUxq/f
s0kXELCYr/TYdNcjR/vmIVaWMBTox6BXf6dkZWXJNfDKbVNdvqei4rjjl3IxTgqKbGwE8Crh/tgp
s2MbdtfigPCcXrJ/e/S4Yz15r7Stg/T0UkiISntUkNx9TrHRrfRrez24Zb10p6sIdF3gotyFcxWP
rag7RZVrBxj7GOKZs6w++5Yeo/box85YbyDbabkGR4ebpMBbvXX+wNsdhIrP1B3FPyxso1sYcmnh
Tjj4ymVcK5MsgjFQ9DgNoWy1kh125N244tmJnPY3egXddDSMgPTk+9JDIzBpLpluTsG9OXIkpk3Y
1M1UoRd83u+4WTKnGr5j2Upam4w2moRZzL/USnIMzFPv06UVhS0hk/TjPOSeA4rWX058JSrDnGCY
V13ISBmM2GXs28hj4ZzOVUw25klWpikia/52OYAGgDdGNW5FWyb4Il+GnrwqCPh2BiIeyLAelRVW
vW8+MCF59boL3oTblJ1UuM75QmaWesk0HRBD6NSNU5lU46teYHZC/bmie8ez0fq3x63vyGSXhlKR
QaNQ5+ScYiGiVXSfbpF+/FKvqgvlNNBq/zy32cYl+xt5LJOfH8zTOnH9u3SbJWYEXrUXMGYRu3Jh
vv+UTmuxvpwLs+Mws7RB5LMnZ5glAyOFtarfq3cohmtK1EqMtkW4EuEmcjBYJ5cuuYNd9HK4B10F
YNFlgm0TLAYRCTlsZ1qANWXt935oUxk95m5mDULH/INAQRn9yoCLD0ZZPzrwAu51IoIh3rgT7CQT
yibXguWs0J7dv2i2EBrdgjdKuXrL5dg2n8TWID35l2878RKcYkQtxonKwabO4flLao4An0GGZscW
u5YGb8Nl24whM5ylWgKVlsVZjSRrzzyjhSXx8/bV4CZQqUwjaW5KjY3nrQPZZ+NCI5Pqbi+0q7ac
VQTFargQlB5iJu+N1BZT6GWx6xih5ELFslm3Pa4zyhiKIEKoJGVjsTDdHd4msgSBLHrzUlpEvCNS
9W+jjCviEYps8P1BfTv51FX2joYfZWEObTI9DTQWKi45j7tH7Koc8BPFDqXS53J0hfd8k/OJ6EB2
TG6ObXCRWBV5JUvUv4ofQZ+vfsmzH0iI/VL3PMabYo+svGsWdtTj1ajUvHnJWdvrRB4BM3IbN7ip
WrBaHAZZ2ctgvWSVnXlOHn50lVVHwBeIWoCvn2XJjKQlZiRPHslTvapRd6ICYev4q5appYulRMbC
OBh0yifEjhzKsdPZsaP7SAA6jyo22YpaVer+JoJzvGcsMWVvo1pT5EhcQFSBr3OM/njYdlyAKFSi
XIyItzkoiWpnLqrL6GtSjhgYBHkXjREGwXrd0XzRheTIZSWeveX3bn8DlJLV/rxg5gwNxGqIbkTh
TD6ylAc3vzc/M1xt2wRU+tM9RmbwkLM6+Ni=