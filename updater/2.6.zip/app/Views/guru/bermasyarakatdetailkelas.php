<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtF+mSrLHZhY84nKxlEGaWyut8WS7cONsvAuxQt2zx0DY5sjgDH0x9FznFYHWcaAq6UxZPXa
eziOEnp/xlzYAx9/126kk4a9ts0JAoj65oq5ch/Z9wNBH9tcVBT8WZyZ7SkzdG4CgrIyX6yMALeK
Z4K6uyURKvmIUsR60np/25wcOp4pi21y22l0ZPl26vZHbnz86L++9jbt5+JWm6uhSyJefO+sSvsq
EcDqAxMnF/OmQrsxggFzi+bPzAhwID49vjL48X5jdQPx9E+sF+Xmx7Xq3ofezGGpG18e2iZxQRuE
cT5O4H7dCF6NViaNk4yWWOF4ki0fcBHmwe7GZosMmQzPVw7f7hdsPeWRifVMRMENo18OiDlYdkQM
DGvmuCRMqwabVOsQSdITSKvAdrMOm2iEVzBXzN7N8tN/vKlLXNUNnMgVqNFhlex3hkcCi2DvNLSM
dJtLARdm2PcnWqtSMbGOt6LHPhazZmtCNCHj5JGM4qrJDaHMjl/DlWWxBM7l8I/AVTpx3utGDLEx
gS8EepjPmziAdKcKFmZ0WnOCIq/4N3JZ+EHw57253v5zb5ufAu8RZBQQlqx9XcCaLJUxwAHIlUrh
G9u6+94Sc/yrkOKXC/Keb6qhiZ1V4b+KpL8TDDpo9P3dA08SnsZ/U9aKlxvO7iiOjZREGCcKt2f9
KePEjjUOZ1nM/03EAfFSPbXY1/sZ/SdvI78NrWt9lcB9VegBaXHAPyeqQfWvVsGgn/AvMbU7aD3J
/u4l7hPgsKD4gJt+j294R+x5oS+9aTTPNlxVV1l/UqcYK77uaG21K3MQKJG1/MyIo4sntEeGmtJ2
yYqEtZzWMDg49ygL/Eb5BWFNH5biNq+MYeFc2RN+Fkx0sldN8A8cUfZWvHHVWiN+lA7ea/T4qiDY
9QlHjim5zUJYK3SNLzu/EFHcIoGRkZOguGoz3kMDRRhACa0FpCIqF/Y8PCvREvpT/8FWG9E5BFQt
91rn+s0YKpFTH/zq9eSg+nt5/sRhZhlADIjRRmqsC966ouLS/XvukGRqoNFqPt9ZUXCTAa+25eRS
sixCofTipG/qBz7AAhhKir36IXsOn/Yw6j87wwuYNh0jLmuxsmPzpMZs66XCdX7n8tfBuYozuZaN
6HFHW1pC0OSmKa6rk8esfqGKKxcC477Zo+nCPACzk1FZbVRQpZ4mha4KD2s1TBmzCiHKV4/CIddY
5XG92nK4e1TOaxTLT8052YSKikGZZ2rP1pdbw5Q5tqDDLDY2p8igZAMhY+T01EO4KmabNiIaQK3v
htoBFj3n8a1yBjobbwdfQrDbKlwdr1Z5wLGv+4P7hrASCU6MsIjBBEcMPpHRFGB3oLIS5dWYh+LO
3Ef2clZH4ggvuj+/kEQOuAKhnz0epNPZUocIY+8NqZ72rH/ZYinDU+OMPq879N/M7BwqYgNldegx
j71LynkJsQT5GwgmiJAwlTsdkU2C8/xR0QUlQFHDIWMKYkSKWxnFR/iOVfadGqgFdPFp5WPsQXbx
bX3pTEPvsSCD9wQ4MU2C5SGEgW5N0dluOUcG3wDd5E9fK6VgSgous/wuUVdrr9yML9v6Hudw6xec
1GImzMF6dCHmGuWuKL+glbfJ2Y38FjwPZtgOyu9+iw5wDkZekj/xxZDJTP+u8jwDo7WVEgNAHaTh
PLyHmKKLMBhketjs7m8pATrPEsw45Nxq5jeAYcqQHaCUHM6wTu9SeAjE5RUtJYecZkLMChK3bcVZ
o/4Ko4aIJTNaWfjworbBw4mtOmycMPnQGumY69Z/7KJPm4b1gk7fjmRVMXfkwSe2k0H/1ybnD+0w
lBU7Ka4C3OSTh1SEZasa+naq4ulddfgcMIBd8sjcTAFueOkpUHu2LZThvW5iIwjcb87ySyQKEbCP
w14pgpHsW37Yx9zvoDuAzLVE+JlDkZq87QWAJRmmh69Wq+pM5Tp9MeGWXqgIInCBtLQt3FgOVie+
YyigeljqQgvULwS8xBSAoKPyFkXOfleOYsnr0/87YTdDRAarllVwqede3Sd67eaebb3lU14QnABG
sRXu4kMJypDdlJMP8sjyvJllPigmMeGk36q0G7zTMvpLe+aaBcty105v2WqAVB6k0/XlRr88atE7
voDhzpInp6wYEovpngFLD3V7Ijb+zHZpKA/Sauu9DzDkAOiaoUR3Uo1I8T+zQybpoaRc4rWtNhDM
gH3wzTHyZFyTFhdYvvu66NKnoT88InWfDfanr8b5bPcp6yz5dM2OZTQXJKBv61X09c9aiNpbOV8l
/zgd7xL7wHJmctggrn9iZx9bY4NjBJhi5PW9qGTFOR9PRPuWMpz3NYp6/EnDAVViiLVuZG+xILcn
rBbbtR7HAQq77cNJf8K5g/Q2k2iJgmtI+Q47q4e7cE1Q5rCQ4SEuYFMqbZStGfw536ck5s1tHNZL
+0YhdVECnVtF5B+75gzI0NWLQLtO4F0aLAvBlQFB1n+kT9JFqQ2v5O+wT15weKcUEO3EOO0qXP/X
t5XapS9HjZ96IFFbjQwo0tzE4qxxRzOhhAPlPrxgK8rIcYxgUQtjeG5mQv60xJi8Gb+Gg5VCb0/f
WKH7f0AMjbTJln82j9j5oN0Y/40UXfEzM2pfo3sqljrD02FCTNq8ScUIGCiziuIy+nhxmZMkVMFi
EfRe6S0/QrLKmfzcG9ZyAoPWj8NmIVXnMrVs7YQ68j7Q8Hvod+V32y1pRahUxbJxUYGbtFFP66xn
q19l3jGByBakgB+0upBQEProokn27D90Vnu1W4eGxgv6WT7H4H86VyDmEZtXJZ2UOA0YbgTSlhpM
IjYCNhnJ4hftk2M2yxRufEuHSHXw3VhiLu1hDnKgTRT3nFY2SNImgSHn93qn/kl/FWPfwG7pruGG
MVg8+NifNC6wXNMzM25SR3e8zYPlBGe7VsyxXqrd6GCFwnuCdQDDXvletAITp0jfzwh5WOCudidC
IItm6H7EFITenfwQqSqIFR47L3LCsmdOoMXPllsw2MBPL9fJBlNUcfDBjl3mdKOc7rqhkHBwHHjX
Gw+0PdOlZZLhTH3aY8w5RGREsrAQDfwDZ6464RZvHofSQWMjSotZQQpg28B2