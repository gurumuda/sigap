<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv7/TATZgaCSLBDFCa2wS6Sgd/VWD5OFxucuGadUXRb8woh6grrdR7Z5Ef4Vb1Q/uwbn3Crw
YlX+ZYDd7onj2iFfoxvqR42jZ5nlZ1gQyvKbK+ITyLq6tyjtgfX4v4rd0x3MSVpo5ph3yn92lG3n
5Al+WPp5oP5OsYKK7f2ftkVyG27eSj6PWS/W8KZ0SRPRnNJlrRtnKUJZkWIoYc2+V0J9e3RJj/qV
wHmmW4qjunulxMsYOnXM+9cZRo4aZklC7YD98X5jdQPx9E+sF+Xmx7Xq3uji2xOEuwA/fZcyfxuE
eD5+/+hW+dYbpeyQytzIee9IRMGYBk560v+r1YztgF2sgwT7BRTO7EyPcDbIIlHQLaQsTasNLPYg
CR5JZVULU//wy2gOVL0dIN7VU1HX3owxiQK9/04dMr3XlsoRKGTzKrolrREvUl/nra5RjcULEA4b
ux8jNwrDCUDzmYBijUyp6UbaqsM1bLFMnpGno1k87voyVzHyXIkQ/odbvQDxJ8CWcfti0clJbnfn
bU18pzWo2LTj4+jB/SCH1pwBJ6qF6dTCuXosc3QoIT9DlpI2xynceMqfbhTZEGgKfYmtkBUPcfCC
GaaQ+EH932KVlSS7Zgsow68IZ9RV1ii3QuG0JExTQ23/EBn14it8MlgeofFGXxtu40ziU6ew3ZPH
Ac/pezW/ufh5CaQTvuyLzNZCFIgz1hikwi8luaGD+3GDPhxv7T2zU+S9Qea1zQTWS1NtfvP6l6FJ
i8AJf4+onugyTrFAumnphn+LYqxXsARMr5ly+lLJfWQlHWAuuApqk2Xxjbshe/I4v/Y77s5ZH1x3
EFluVt5z9Mr6Ex4ZyJzyFltvLG+2EwQs41iX4vCgsypRrxRtf/naOW477zAyOJqg9vWVcozBNOnx
fhitxAWZss9wwE4Bb2xLCKEr+xDnZxzHzQOr0ILw1v9k2eTs5cWTgBH6kj7Yl8wwSwaYA9ijOrX8
uy1BP//sMuYDAVJnudzbOYgIIErmRI7VUH+o+CuYXG9+zA/IAixUeZPtAjvHpGhTyrpsnUXtCl3d
Pbik2h6rxFeC3+ZYxzsFFbAsIWtCJXbNqEz2LaBoL8AXUnQiIiZLwCRlmYN9jSSaR+BpM/Xbb78T
ohdgpUzgUUwsGdDh2MyBWXUBKYvLNPatpWE0FJA/gGfiaaHl8cO282JN3Ih/6vmc7YikqjyYNcBW
K9xoDo8M19uDM9YvWVvbn/N8naSBCtrC2FsrdtA+eE9bSJVhfcXJeABXHQyV36pUl1FK4t6Q39z4
RMp+VjZZ799hsYPD8gVMLkGI7x3hL8ckwFaIqf5fTkCu6akAWyYzFctS2aGllIHFp+kGMidHbg1k
zmZocCKWvAb6UK0Pd80mGy/I4w8NAyt1e6aXcgKVHAODJBExTj3XjMI5t0RJpo8dJYHKsMR9ZxCM
ajwx8xlItEP3cYLp9enr6BeEXA3D/WTDoUtijhgzNYbe+KETrY0pSyipYS4FyDeGUjwV+SrEIOXW
YNujGal2R9Mo0evWQo7SONnE+kigzN7Pib3rb+XsfBdRsghT5xzcCBbY0Y2eZv9Qc0RNTFkeNuoO
y5+xUrNYh7GeWMl+vR0D7EAB7625HhxcA+AyEtw0y9r8RzBlSCSNxLhgDY14UWBMIEhAIo8O4CKK
QHQzcGANfcR/Y0PvJUPfKUQRpS6QUHCgBMsNuzRPTkEwo4QdTRTu7CapriY1NobXuTM4J+VsrgEz
WrbPCrN9XUcr/QKCeAcZncP7aLPROmbJ9y2QY2jcEqV8ZYoihxGhpIX6pd0aFotIiMB9JZGQDWBP
EkxPUsXyOplsZjB2xyzorv2SZGauoq9rEafUL5WGHTNHltSzSSc/EgDu2KBjAdV2N28vNAi9uDxR
dWy+1TZGZWf7sZyLa2Nslmo+cl6XlTgMQCEcifgHhi7OyLkfgVlVa18mnDMYlsnn9IAi3u5wTN3y
kgvVhFKfhYRBALqi32zEm3izrzAn5J1d5UfYB167qeFGe0P3IsLmq9qWpjx4RaA5eKu9GvIc7coU
H2b3P7uC9P+O8X7LOffBdIoi7wPCSrv3/JbbelLLDDQbaY0goa3W9El9jEZg7e1kKD5U4gjWDzUJ
mx6KX8Xl2phZN6q3hRviIsHq7uknwlvIO8iXKJ+0GGcxkCJDs1WUIioXq5QznS0a73Hzj8LO0ptz
CSCcfocAcyEMtxbaH3ueJCC+XSgn7ieSza+Tzf1n/CPlWfEHbnPPV6UcXDVNUn8wgIMxqa5BuN7L
aew5WzpND/2LPS1E22qDYMRXDDHrcgv1WFAsxZq2FihxcPMPVPzwoDNeRJtiYPwlufucjaqgPIKg
Eseac9rgcOYIrC4+JA5RYEM99r1YnwWE3pFf8mRI6yaE+QwPbrPqqGCOMMAHmSjGfWVBQIG1HYHP
dAccIVAx/uJsdWnIDDp/SKSYBOjAeHcXvoZpAPya/0o60RXaohthRMX5jjRd0I680OnG/D3iuPvu
MSBZo9r/JPBXhZJB4wJ/J1guSmhNNsZIFMNfOGitfoDExxUZRvIldrIrzm==