<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvsebr9nYcnb31W2SQ72G+7J+c1u/siIJTH0MQL+KmabNwugaYedCAboQaF3LoEIhTv1HzMJ
UpWKuY5uc7Y3Pu1sccGsa8UAUFaBo6DHq9gClEJVv8uEsGscSRHttktJHrC5/2LupQCbC+XbdJvN
BHLnunXsj1LgB4jV8wFcv4ymQXIUdXZLKShwXH30g55uiJzTIngn5KEZ6cuEpreZLVZs9QpBZuyF
yRylzlJXuioHvdc8ZjQzLtTVGk8/9vUltkaceI8HRPscUoJljZ/eSEnuT0zePrUTM+QGy1msVSQ+
ZfdHTV/3mK3wMQ6X+/ji7kRsbRKXR8ndGVmMk9uITmRYTsKvHHVTAIRnkj7nNVqSu6/0aodgZOdV
5bYvQvFsnmmlxZIZVAfUDDdoA1l86ztJuqIh+orld3N/cAg4/hCY8oOtclt15auv7O2WYHJt7X/9
Qz1qftfSngueQvT1LeL5/oGP3Sj5qmpVZGf0VI82rvwE2hSuDlkd+cJCQ9raDGxD5kPkhsPqkUdn
e6P+FOgXEW3ycYl4GAdGuLZRrgDO+n1MSxRFreCj9/QyE6C6/7xegzPrNuqBKPtcxhZtRPxCDDEG
VEv8n5ou2sDrOrw8A7BiKvRLzyeoKCbte2LnSzAqnPvS/mYQLmMGKQyTUpelsx+QEaaZIdntRUGe
kBG6i79AT6BBMikx4claicKwJSKGqdwOqFFtAmldGS9KxLeMkvNky7/r8KSOUVpK+FY4pAF81DPA
e4a8mE5txQD/tJuk38mnRXlL5eU4wlVqWUlt9O8hnj0vUVuFCSJIC9Mj+nuUIpbZy2sJfO2kWaio
euP+cWMj2sGcMjCHMuMhi4duN9Ceo9My44csya5xUyqoUdZ3beY5ygs+PZLZKdhG0Jhw7UChg+d5
1k8FdJuGu72Hc/s6BhfOHCPh1eNj4teCMGxxbpemQSJSDfVkfT82jo5+wYXzx7cTRiKTK3CmgetW
cF25B7nZHuIGAkM4g+6t3WHHcw/sANW1kWwUbM5k6eDI2fH+74TnssKf8o+VJ1gzjGurgMNh8jFE
JklnZItnmuyzhOLDghb1FbBgbJhc+gDnn8mlHX2F4qKGcVN04JMaaeeH1/fwI2vTd5G2cqD+XAqa
RHAQRo0X9f+Mcn+rYNL2sr3b7XHLhoQdN2soeaiR7ryMmRw2vFPj7nB9YAIN8BYKHNqMB6UakCRK
uhJbpfIqQKw5II24MlKEkHkWwfckNHA/zLQych4NPSi5/DRsfSPS+OeBdBcNV9pZpcGsxPGnNfP+
hdeU3QdQT6CloDIKTpwUDEUKUSQtmjAfaf+5f7sBze8uBKPMUF/4ei+72TtkdYFzOtatwGUG6EkW
LcYQLfxTDtbMsWnrX66UR3RF7QLLovNR1UcTqMV0LiZArZPGioIZouoNbYrpxUtLWETkbVS0wGHS
kopI5y+GDSOohUBonGjyz2FqYxLzo+875nppLaVaEPNfxyFj7gQhj1zahSaU7EC8aPMn+35dO0ov
rzuFEeDYdaB+m2lXD1JFylX6URFt7uHWRF7VhoLoCNHffy03mzpdGLosihV+e3jYwP2QaFqYVG+F
bjI+hQw2qqbCUUeex7gEEcNSRO5jFWbL4zaT6nU4nqwrZfI+CAnI+ahfAv4hKQFfhjvTXcIHaHgy
SR0Y+cy1qce5T70LG1Eknvf8LkdyM/NzUjMBFIyGBFnxHNwW/tmQe0px5OVXibalYb5jc+4cPvY/
+ijSyYIilld5u573J1jajc2huvaLvKci9GVYlE2MhOEAWeXv8jht6Z/Wophg0kb9RHWdcoOnC2/g
Cu10DFKhQnKntz1UXUHb6O+TC/BSihXbtiOQXLqVXJFx2EKZ8InnivY5N0fm5RZUugVZC6z+ykyX
D34Rdol4Wz53aNNSMckMPWOq3Dgx047ZJ19/qqizvSOTBxXHPzZTT4fw/5gSQkQhbGY6Xxhyyc3B
rNba+fs5nnWZuV3ulDwg3NQmRmoN3BKdte4/Po5VSx/liTW1orL8Jr9LYr/Rb6CYfK//zvvq1EHS
D8ApxyY/jtY7Ly4P74DA2JZUPVeIxQsPkSL2gPyubz0WvPTfzwvKI/K+V1fTKJr8LslhX2qBZTI1
NEG1YTIWyLnQJ5o/ST2ZlP5y6IQmAPLcEM48PFJKk6+QqkuLEbLkc9UrjHv3rMhLUBs2iVB4618w
i91Ckuriw4YigTeNi57HkapO7/+Uv5jiBN/0gXI0rX6HC/JjYFbGjyTkSqjjXaatEObfkSosHmwP
XqggEMQhEEswDU8I/VU+zGuQUB96nWIG5GF4DwIzfRfZod7nl0S79hu=