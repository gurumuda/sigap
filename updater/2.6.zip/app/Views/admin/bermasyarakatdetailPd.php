<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/kPRJUvPLOvH2Zu5CCwdfYELMiOxkrUzTSPp9Fy7GDpgO/u5Sup0eZ1hXuJdqcf7VJpSvsU
qgsD0FWDL+FuRSbFrDrFHylTKkbzMKTAvJ5poQ2QUmS9wgW6lyXJof+y9NGnxKTQHGX7fsSDUec0
TV822LoeEvWX9QIh65GxZ11qKNLBC2X+tiwDaiQv1mvzhkN0s8AhTg07fIaXg/UE+9zIEjjGRmBK
05hyvd+Zq33jla5Kct3EfAzypXTm7XlnWRk7M28HRPscUoJljZ/eSEnuT0zRQEbqY280jzgowS6+
Zf/HOVz/7uyocHDaZQygJ/bz/mFBnyd03g9Kh8NyQKD8uCPXRg/CJUMwPhsIv/wBQsYqqCf2QLq6
fhyLrTy3mMZUVB3d9p+y0eQtQFf6mLss5f+wozkghjK+eSkB9akeD6pU+niWHbhgZaTddaw3gWZE
Xrc/x5nWiw1OuDtIGhAqLGW7dMTD2yDQ9/q7XRyNVz8RJePTARxBYmB11VTwkgONGCwQa6CrfQoB
g6Frj21ykXAwQDJGRczfot6vpeOIy7au0m0Hd5JnUJjglFtg4Hnzknct3fGibKD4GJFJMEMQpNa0
YQWq0nVNV74u+/3kRsQPMlYmEIK9OPnBsavO7YuK9KPI/x6oP4ByKpNwkg/cqq+oty65sieURnhA
VdDcT42ZT10nHeX3oUlWETwg1GYUHRK7+W2oNjwUxsGZ+ITWrGfRlR3re4pOsy6lL57sym+mLlAB
ccBpyfJ0GDg7nlEGJE82uaNMdfrhO1uCNxOkBtsVuboUo0/Wipg+MWu61CT8aQgnDeEUpOeJb4oL
4eJTfUgJM6BfMgSh6/U4Cy2zxEaIhk39L1bKvQd+kNDmkbj9V3qshA4begl6U3Bb/CoDsbPeQYUV
hf0G3H00xXy/hjvjdOTcuBb0QqyxuFGxWy5gpWTnfv1S+ToN6TZb/oaneGZ4NApcZHP6LibVlFBU
6iCa0sMvVC6AeZyqsDPbQizKNJxGKsvGeUzD85JlI+IamKxyQMqZXm/vyLM9o7AyFIZC9YNN+MR6
lyXpaFhDF+LZE2RKYSHCMLzqQ+mxUM33NIZv1njDlcCMWnMQG5+wdi/42sdbHAXF7m7pjrVT99dt
jccd4rCRfpgM6kvNfw/XH4X1Fu7SFzV4jEzwse8RkdB6DZQmrCHTW9E6uz8X2cScB7eQQNgp0ivt
PGfX+quLdBRyRMG6CIB4awtoTJw5Kbv5PvO/Idn2D4G93g7fbfRECekcKqehlmNiZ/Vhbf6vTzQ9
ZySQb97jFnGxzrgpQOTNu71r5lgnMvsNt27acs+LIG3m8jMtR//IjxA3WrKobXBdWyHkuIVvza02
tXKvp/vSyKHdbr8cb768o4J6aXp8Kivmz3xW5HieR/6Or/igbgEcWS1goy5hiDxvRaIXKtalND0f
2qBlaRKqgFH81NbRn9mjXhVpH5ftsz0NOCWDc5cMeIQiahya1rzDXURIcVqBXz35S4GREBsGDv4u
SAnayr9WgkUDoFk3lfDsY+R2JasQv6LatdNmCc22chyY5nRX6iYtVeHgsGYNE5PMH3PsdYqGGFl2
ndcTNrXvn9vv5ZYxCusqCO2m5lCTeR9dsfP5Jg7i6ZhjAjs6X1DiWFDi6yPWt/E/1sSkXUew/kcS
UF+1q1uwAYrE/wvGswRJhBJXXw4+BGcGzd/XFidFaX3nBaa1DIBqZYUqZZZqyLSCsHVTFVGLxVgj
gQccVgkatJ/4zu9nzjfiqQOf1/TYPgpifxHvTVyQDL5z3FGZbrwBRJXHYjoTGJSPr5bzQxtSHTQc
4SQfAzSpDzS8cGxnrKgNZbtv3PiRd3vGBYlxYPwpVL/r6aEQdKqtaQYpTUM70Tbvm1kTjfXhv639
pd8kbY7ZG8pNd67R42VaKNQtT72rGSDjj/JJtX9q0fgVXNTrPUKQoLgeB5e6dKUJwezlaXFGxAYX
uHboeSrIEL/ZEYJSThjL64TSs87WwUi69+byaTPITlByAdlhHngHLMuXbe8xCbC8sDtj7r0n0NdA
ZKupuOrnpXyokaPLv9MG+dQT1Uio4+5s1CGulo8kYAUDdAU7Ky88wZ+zTHZPwsgr+5UH7jJJagPC
DwfyHh6ha/HP5MGDB4u56tGkxNXHD9+iWDbuyWvRcc7gVNIkp9LQdVKWuNQEby7s5BAhN/5VG5Zw
U0WLHYPOMXL6Ub7Sp9g6Ksq5oPLPdPYKKjXRN3J08ZPR0bL4Q6nmuON4Cs7Anmg6n5wtT5JLwHGm
zU0YQIG+zWIAeVrg74z3AYrzRP/Wr6QIZ+YajY7Tis86Y1aU7LH5oEuxtTX+vBhyaaASUgObWFVm
y4KraB0AihbEL19tWE9zxIICnM2E32wFW1k1EsQJagovL+nG1Dnpg/g22fTl46JTrTzbn/tDP6kT
aol4ctb6joLdX710r3h96TFrxGMNu1CEu7WY49FIqOU/73Cs4ons8Mw6ZMn1rG4aFaO/6J1n/z2a
eVA65+4VcHHX6tXSAFYZL85LVjCQ9LYY34tQvHzS4FlatPSrEyJjBKxL6RNvv+XLaaP/fKpYxUBh
4OXXpen/3dBrIGz0522vCnT7mHbk4MgRd3j72grdVr4wVQ4mSW65EP/uGw5RQJ523pEtpFn+WFP3
3s/NxL32bJRXorAKrpC/fJccEaymO104VgT0X30b