$("#pilihhari").on("change", function () {
  hari = $(this).val();
  if (hari != "") {
    $("#tambahBarisJadwal").removeAttr("disabled");
  } else {
    $("#tambahBarisJadwal").attr("disabled", "");
  }
});

$("#tambahBarisJadwal").on("click", function () {
  hari = $("#pilihhari").val();

  $.ajax({
    type: "POST",
    url: "/ambil/barisjadwalguru",
    data: { hari },
    dataType: "json",
    success: function (data) {
      $("#tb").append(data);
      $("select").select2();
    },
  });
});

$("#tb").on("click", ".btnDelete", function () {
  $(this).closest("tr").remove();
});

$("#tb").on("click", ".btnCopyJadwal", function () {
  hari = $(this).closest("tr").find(".harii").val();
  kelas = $(this).closest("tr").find(".kelass").val();
  mapel = $(this).closest("tr").find(".mapell").val();
  jam_ke = $(this).closest("tr").find(".jamkee").val();

  if (hari != "" && kelas != "" && mapel != "" && jam_ke != "") {
    $.ajax({
      type: "POST",
      url: "/copy/barisjadwalguru",
      data: { hari, kelas, mapel, jam_ke },
      dataType: "json",
      success: function (data) {
        $("#tb").append(data);
        $("select").select2();
      },
      error: function (data) {
        console.log(data);
      },
    });
  } else {
    toastr_error("Sory bos", "Data belum lengkap");
  }
});

$("#hapusJadwal").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/jadwalguru",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Jadwal pelajaran " + data + " berhasil dihapus Bos ..."
              );
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#table-2").on("click", ".ubahJadwal", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datajadwalguru",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");

      $("#ubhari").val(data.jadwal.hari);
      $("#ukelas").val(data.jadwal.rombongan_belajar_id);
      $("#umapel").val(data.jadwal.mata_pelajaran_id);
      $("#ujam_ke").html(data.jam);

      $("#jadwal_id").val(data.jadwal.jadwal_id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#simpanDataJadwal").on("click", function () {
  id = $("#jadwal_id").val();
  hari = $("#ubhari").val();
  kelas = $("#ukelas").val();
  mapel = $("#umapel").val();
  jam_ke = $("#ujam_ke").val();

  $.ajax({
    url: "/ubah/datajadwalguru",
    type: "post",
    data: { id, hari, kelas, mapel, jam_ke },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      console.log(data);
      if (data === "1") {
        toastr_success("Mantap bos ku ..!", "Data berhasil diubah ...");
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
      if (data === "2" || data === "3") {
        toastr_error("Coba dicek lagi", "Mungkin ada duplikasi data bos ....");
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#hapusSemuaJadwalGuru").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus semua data jadwal",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/semuaJadwalGuru",
        type: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            "Semua Jadwal pelajaran berhasil dihapus Bos ..."
          );
        },
      }).done(function () {
        setTimeout(() => {
          location.reload();
        }, 4000);
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusJadwal", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data jadwal pelajaran hari " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/jadwalguru",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            "Jadwal " + data + " berhasil dihapus Bos ..."
          );
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusAgenda", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data agenda mengajar hari " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/agendaguru",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            "agenda hari " + data + " berhasil dihapus Bos ..."
          );
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".ubahAgenda", function () {
  id = $(this).data("idku");
  location.href = "/ubahAgendaGuru/" + id;
});

$("#pTgl").on("change", function () {
  const tgl = $(this).val();
  $.ajax({
    url: "/ambilHariMengajar",
    type: "POST",
    data: { tgl },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    dataType: "json",
    success: function (data) {
      $("#pHari").val(data.hari);
      $("#pKelas").removeAttr("disabled");
      $("#pKelas").html(data.kelas);

      setTimeout(() => {
        if (data.jmlkelas == 1) {
          ambilMapel();
        }
        if (data.jmlkelas == 0) {
          $("#pMapel").html('<option value="">Tidak Ada</option>');
        }
      }, 200);
    },
    error: function (e) {},
  });
});

$("#pKelas").on("change", function () {
  const kelas = $(this).val();
  const hari = $("#pHari").val();

  $.ajax({
    url: "/ambilMapelAgenda",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { hari, kelas },
    dataType: "json",
    success: function (data) {
      console.log(data);
      $("#pMapel").html(data);
    },
    error: function (e) {},
  });
});

function ambilMapel() {
  const hari = $("#pHari").val();
  const kelas = $("#pKelas").val();

  $.ajax({
    url: "/ambilMapelAgenda",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { hari, kelas },
    dataType: "json",
    success: function (data) {
      console.log(data);
      $("#pMapel").html(data);
    },
    error: function (e) {},
  });
}

$("#pHari").on("change", function () {
  const hari = $(this).val();
  if (hari != "") {
    $.ajax({
      url: "/ambilKelasAgenda",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { hari },
      dataType: "json",
      success: function (data) {
        $("#pKelas").removeAttr("disabled");
        $("#pKelas").html(data);
      },
      error: function (e) {},
    });
  }

  if (hari == "") {
    $("#pKelas").attr("disabled", "");
    $("#pKelas").html("");
  }
});

function konfirmasi() {
  const tanggal = $("#pTgl").val();
  const hari = $("#pHari").val();
  const kelas = $("#pKelas").val();
  const mapel = $("#pMapel").val();

  if (tanggal == "" || hari == "" || kelas == "" || mapel == "") {
    toastr_error(
      "Error bos .. !",
      "Pastikan data lengkap dan ada jadwal mengajar pada tanggal terpilih"
    );
    return false;
  }
}

$(".isiagenda").on("click", function () {
  pKelas = $(this).data("rombel");
  pMapel = $(this).data("mapelid");

  window.location.href = "/guru/isiagenda2/" + pKelas + "/" + pMapel;
});

$("#mapelCetak").on("change", function () {
  idMapel = $(this).val();
  if (idMapel != "") {
    $.ajax({
      url: "/ambilTP",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { idMapel },
      dataType: "json",
      success: function (data) {
        $("#tpCetak").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#tpCetak").on("change", function () {
  idMapel = $("#mapelCetak").val();
  tahunPelajaran = $(this).val();

  if (idMapel != "" && tahunPelajaran != "") {
    $.ajax({
      url: "/ambilBulan",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { idMapel, tahunPelajaran },
      dataType: "json",
      success: function (data) {
        $("#bulanCetak").html(data);
      },
      error: function (e) {},
    });
  }
});

function cekCetak() {
  mapelCetak = $("#mapelCetak").val();
  tpCetak = $("#tpCetak").val();
  bulanCetak = $("#bulanCetak").val();
  if (mapelCetak == "" || tpCetak == "" || bulanCetak == "") {
    toastr_error("Maaf bos ku,, !", "Data belum lengkap");
    return false;
  }
}

$("#mapel").on("change", function () {
  mata_pelajaran_id = $(this).val();

  if (mata_pelajaran_id != "") {
    $.ajax({
      url: "/guru/ambilKelas",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { mata_pelajaran_id },
      success: function (data) {
        $("#kelas").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#kelas").on("change", function () {
  mata_pelajaran_id = $("#mapel").val();
  rombongan_belajar_id = $(this).val();

  if (mata_pelajaran_id != "") {
    $.ajax({
      url: "/guru/ambilPenilaianKe",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { mata_pelajaran_id, rombongan_belajar_id },
      success: function (data) {
        $("#nilaiKe").html(data);
      },
      error: function (e) {},
    });
  }
});

function konfirmasinilai() {
  mata_pelajaran_id = $("#mapel").val();
  rombongan_belajar_id = $("#kelas").val();
  penilaian_ke = $("#nilaiKe").val();

  if (
    mata_pelajaran_id == "" ||
    rombongan_belajar_id == "" ||
    penilaian_ke == ""
  ) {
    toastr_error("Error bos .. !", "Pastikan data lengkap !");
    return false;
  }
}

$(".ref_kelas").on("change", function () {
  refKelas = $(this).val();
  jadwal_id = $(this).data("jadwal_id");
  kelas_id = $(this).data("kelas_id");
  mapel_id = $(this).data("mapel_id");

  $.ajax({
    url: "/simpan/refleksiGuruKelas",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { refKelas, jadwal_id, kelas_id, mapel_id },
    success: function (data) {
      toastr_success("Mantap.. !", "Data " + data + " berhasil disimpan");
    },
    error: function (e) {},
  });
});

$("#table-2").on("click", ".ubahPd", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datapd",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#modalUbahPd").modal("show");
      $("#nama").val(data.nama);
      $("#nisn").val(data.nisn);
      $("#jenis_kelamin").select2("val", data.jenis_kelamin);
      $("#sekolah_asal").val(data.sekolah_asal);
      $("#nik").val(data.nik);
      $("#tempat_lahir").val(data.tempat_lahir);
      $("#tanggal_lahir").val(data.tanggal_lahir);
      $("#nomor_telepon_seluler").val(data.nomor_telepon_seluler);
      $("#no_ortu").val(data.no_ortu);
      $("#alamat_jalan").val(data.alamat_jalan);
      $("#nama_ayah").val(data.nama_ayah);
      $("#nama_ibu").val(data.nama_ibu);
      $("#anak_keberapa").val(data.anak_keberapa);
      $("#email").val(data.email);
      $("#rfid").val(data.rfid);
      $("#peserta_didik_id ").val(data.peserta_didik_id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#simpanDataPd").on("click", function () {
  nama = $("#nama").val();
  nisn = $("#nisn").val();
  jenis_kelamin = $("#jenis_kelamin").val();
  sekolah_asal = $("#sekolah_asal").val();
  nik = $("#nik").val();
  tempat_lahir = $("#tempat_lahir").val();
  tanggal_lahir = $("#tanggal_lahir").val();
  nomor_telepon_seluler = $("#nomor_telepon_seluler").val();
  no_ortu = $("#no_ortu").val();
  alamat_jalan = $("#alamat_jalan").val();
  nama_ayah = $("#nama_ayah").val();
  nama_ibu = $("#nama_ibu").val();
  anak_keberapa = $("#anak_keberapa").val();
  email = $("#email").val();
  peserta_didik_id = $("#peserta_didik_id ").val();
  rfid = $("#rfid ").val();

  $.ajax({
    url: "/ubah/datapd",
    type: "post",
    data: {
      nama,
      nisn,
      jenis_kelamin,
      sekolah_asal,
      nik,
      tempat_lahir,
      tanggal_lahir,
      nomor_telepon_seluler,
      no_ortu,
      alamat_jalan,
      nama_ayah,
      nama_ibu,
      anak_keberapa,
      email,
      peserta_didik_id,
      rfid,
    },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data != "0") {
        toastr_success(
          "Mantap bos ku ..!",
          "Data " + data + " berhasil diubah ..."
        );
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#btncetakabsendibulan").on("click", function () {
  bulan = $("#bulan").val();

  if (bulan == "") {
    toastr_error("Maaf !", "Silakan pilih bulan yang akan dicetak");
  } else {
    window.location.href = "/guru/cetakAbsenPd/" + bulan;
  }
});

$("#table-2").on("click", ".tambahCatatan", function () {
  mapel = $(this).data("mapel");
  kdromb = $(this).data("kdromb");
  strkelass = $(this).data("strkelass");

  $("#tambahCatatanKelas").modal("show");
  $("#strkelass").html(strkelass);

  $("#mapel").val(mapel);
  $("#kdromb").val(kdromb);
});

$("#table-2").on("click", ".lihatCatatan", function () {
  mapel = $(this).data("mapel");
  kdromb = $(this).data("kdromb");
  strkelas = $(this).data("strkelas");

  $("#lihatCatatanKelas").modal("show");
  $("#strkelas").html(strkelas);

  $.ajax({
    url: "/ambil/catatanKelas",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { mapel, kdromb },
    success: function (data) {
      $("#lihatCatatan").html(data);
    },
    error: function (e) {},
  });
});

$("#lihatCatatan").on("click", ".hpscat", function () {
  idcatatan = $(this).data("cctid");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data ini ",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/catatanKelas",
        type: "post",
        data: { idcatatan },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", "data berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#ambilDariKehadiran").on("click", function () {
  rombongan_belajar_id = $(this).data("romb");
  tanggal = $(this).data("tangg");

  $.ajax({
    url: "/ambil/dataKehadiran",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { rombongan_belajar_id, tanggal },
    dataType: "json",
    success: function (data) {
      if (data.length > 0) {
        data.forEach((element) => {
          $(
            "input:radio[name=absensi_" +
              element.peserta_didik_id +
              "]:nth(" +
              (element.status - 1) +
              ")"
          ).attr("checked", true);
        });
        swal(data.length + " orang tercatat tidak masuk !");
      } else {
        swal("Tidak ada catatan absensi !");
      }
    },
    error: function (e) {},
  });
});

$("#btntambahbarangmodal").on("click", function () {
  spesifikasi = $("#spesifikasi").val();
  ruang = $("#ruang").val();
  kode_barang = $("#kode_barang").val();
  nama_barang = $("#nama_barang").val();
  merk_model = $("#merk_model").val();
  no_seri = $("#no_seri").val();
  ukuran = $("#ukuran").val();
  tahun_perolehan = $("#tahun_perolehan").val();
  bahan = $("#bahan").val();
  harga_barang = $("#harga_barang").val();
  jumlah_barang = $("#jumlah_barang").val();
  satuan = $("#satuan").val();
  keadaan = $("#keadaan").val();
  keterangan = $("#keterangan").val();

  if (
    kode_barang &&
    spesifikasi &&
    nama_barang &&
    tahun_perolehan &&
    jumlah_barang &&
    satuan
  ) {
    $.ajax({
      url: "/simpann/barangModal",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: {
        spesifikasi,
        ruang,
        kode_barang,
        nama_barang,
        merk_model,
        no_seri,
        ukuran,
        tahun_perolehan,
        bahan,
        harga_barang,
        jumlah_barang,
        satuan,
        keadaan,
        keterangan,
      },
      success: function (data) {
        console.log(data);
        if (data == "0") {
          toastr_error(
            "Maaf !",
            "Ada duplikasi kode barang. data gagal disimpan"
          );
        }
        if (data == "1") {
          toastr_success("Mantap bos !", "Data berhasil disimpan");
          $("#spesifikasi").val("");
          $("#ruang").val("");
          $("#ruang").val("");
          $("#kode_barang").val("");
          $("#nama_barang").val("");
          $("#merk_model").val("");
          $("#no_seri").val("");
          $("#ukuran").val("");
          $("#tahun_perolehan").val("");
          $("#bahan").val("");
          $("#harga_barang").val("");
          $("#jumlah_barang").val("1");
          $("#satuan").val("Buah");
          $("#keadaan").val("3");
          $("#keterangan").val("");
        }
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
    toastr_error("Maaf !", "Silakan lengkapi data");
  }
});

$("#cetakBarang").on("click", function () {
  location.href = "/guru/cetakBm";
});

$("#table-2").on("click", ".ubahbarangmodal", function () {
  inventaris_id = $(this).data("idnya");

  $("#ubahBarangModal").modal("show");
  $.ajax({
    url: "/ambil/detialbarangmodall",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    dataType: "json",
    data: { inventaris_id },
    success: function (data) {
      $("#uinventaris_id").val(data.inventaris_id);
      $("#uspesifikasi").val(data.spesifikasi_id);
      $("#uruang").val(data.ruang_id);
      $("#unama_barang").val(data.nama_barang);
      $("#umerk_model").val(data.merk_model);
      $("#uno_seri").val(data.no_seri);
      $("#uukuran").val(data.ukuran);
      $("#ubahan").val(data.bahan);
      $("#utahun_perolehan").val(data.thn_buat_beli);
      $("#ukode_barang").val(data.kode_barang);
      $("#uharga_barang").val(data.harga);
      $("#ukeadaan").val(data.keadaan);
      $("#uketerangan").val(data.keterangan);
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#cetakDetailBarangModal").on("click", function () {
  location.href = "/guru/cetakDetailBarangModal/";
});

$("#table-2").on("click", ".hapusBarangModal", function () {
  inventaris_id = $(this).data("ida");
  nama_barang = $(this).data("namanya");
  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data barang " + nama_barang,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/barangmodall/" + inventaris_id,
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data === "1") {
            toastr_success("Mantap !", "Data barang berhasil dihapus");
          } else {
            toastr_error("Maaf Bos !", "Sepertinya data gagal dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {},
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".statusReq", function () {
  id = $(this).data("id");
  nilai = $(this).val();

  $.ajax({
    url: "/statusIjin",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { id, nilai },
    dataType: "json",
    success: function (data) {
      // data.forEach((element) => {
      //   toastr_success(
      //     "Mantap !",
      //     "Data permohonan ijin " +
      //       element.nama +
      //       " tanggal " +
      //       element.tanggal +
      //       " dengan alasan " +
      //       element.alasan +
      //       " " +
      //       element.status
      //   );
      // });

      const delayLoop = (delay) => {
        return (element, i) => {
          setTimeout(() => {
            toastr_success(
              "Mantap !",
              "Data permohonan ijin " +
                element.nama +
                " tanggal " +
                element.tanggal +
                " dengan alasan " +
                element.alasan +
                " " +
                element.status
            );
          }, i * 2000);
        };
      };

      data.forEach(delayLoop(2000));
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#mataPelajaran").on("change", function () {
  mata_pelajaran_id = $(this).val();

  if (mata_pelajaran_id != "") {
    $.ajax({
      url: "/guru/ambilLevelKelas",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { mata_pelajaran_id },
      success: function (data) {
        $("#kelasnya").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#kelasnya").on("change", function () {
  kelasnya = $(this).val();
  if (kelasnya != "") {
    $.ajax({
      url: "/guru/ambilPerangkat",
      type: "GET",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      success: function (data) {
        $("#perangkat").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#perangkat").on("change", function () {
  perangkat = $(this).val();
  if (perangkat != "") {
    $.ajax({
      url: "/guru/ambilTipeFile",
      type: "POST",
      data: { perangkat },
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      success: function (data) {
        $("#fileTipe").html("Jenis file yang diijinkan adalah : " + data);
        $("#file_perangkat").removeAttr("disabled");
        $("#file_perangkat").attr("accept", data);
      },
      error: function (e) {},
    });
  }
});

function konfirmasiUpPerangkat() {
  mataPelajaran = $("#mataPelajaran").val();
  kelasnya = $("#kelasnya").val();
  perangkat = $("#perangkat").val();
  file_perangkat = $("#file_perangkat").val();

  if (
    mataPelajaran == "" ||
    kelasnya == "" ||
    perangkat == "" ||
    file_perangkat == ""
  ) {
    toastr_error("Error bos .. !", "Pastikan data lengkap !");
    return false;
  }
}

$("#table-2").on("click", ".hapusperangkatku", function () {
  dataperangkat_id = $(this).data("id");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data data ini ",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/perangkatku",
        type: "POST",
        data: { dataperangkat_id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data == "1") {
            toastr_success("Mantap !", "Data berhasil dihapus");
          } else {
            toastr_error("Maaf Bos !", "Sepertinya data gagal dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#kelas_positif").on("change", function () {
  rombongan_belajar_id = $(this).val();

  if (rombongan_belajar_id != "") {
    $.ajax({
      url: "/ambil/siswaPelanggar",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { rombongan_belajar_id },
      success: function (data) {
        $("#pd_positif").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#kebiasaan").on("change", function () {
  kebiasaan_id = $(this).val();

  if (kebiasaan_id != "") {
    $.ajax({
      url: "/ambil/poinpositif",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { kebiasaan_id },
      success: function (data) {
        $("#poin").val(data.poin);
      },
      error: function (e) {},
    });
  }
});

$("#table-2").on("click", ".btnHpsDataKebiasaan", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/dataPositifSiswa",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".ijinKegiatan", function () {
  nama = $(this).data("nama");
  peserta_didik_id = $(this).data("id");
  kegiatansekolah_id = $("#kegiatanid").val();

  $.ajax({
    url: "/ijinkegiatansekolah",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { peserta_didik_id, kegiatansekolah_id },
    success: function (data) {
      if (data == "1") {
        toastr_success("Ok !", nama + " ijin tidak mengikuti kegiatan");
      }
      if (data == "3") {
        toastr_warning("Ok !", "ijin " + nama + " dicabut");
      }
      if (data == "0") {
        toastr_error("Maaf !", "data gagal disimpan");
      }
      if (data == "2") {
        toastr_error("Maaf !", nama + " tercatat mengikuti kegiatan");
      }
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#table-2").on("click", ".manualHadirKegiatan", function () {
  nama = $(this).data("nama");
  peserta_didik_id = $(this).data("id");
  kegiatansekolah_id = $("#kegiatanid").val();
  swt = $(this).data("switch");

  $.ajax({
    url: "/hadirmanualkegiatansekolah",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { peserta_didik_id, kegiatansekolah_id },
    success: function (data) {
      if (data == "1") {
        toastr_success("Ok", nama + " hadir dikegiatan ini");
        $("#swt" + swt).attr("disabled", "");
      } else {
        toastr_warning("Ok", nama + " dinyatakan tidak hadir");
      }
    },
    error: function (e) {},
  });
});

$("#tanggal").on("change", function () {
  tanggal = $(this).val();

  $.ajax({
    url: "/ambildataabsensiwali",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { tanggal },
    success: function (data) {
      console.log(data);
      $("#simpanbody").hide();
      $("#daritanggal").show().html(data);
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#table-2").on("click", ".detailIjinKeluar", function () {
  id = $(this).data("id");

  $.ajax({
    url: "/ambil/detailIjinKeluar",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#detailIjinKeluar").modal("show");
      // Ambil nama siswa dari data
      let namaCamelCase = toCamelCase(data.nama_siswa);

      // Masukkan ke dalam input
      $("#nama_siswa").val(namaCamelCase);

      $("#nama_kelas").val(data.nama_kelas);
      $("#hari").val(data.hari);
      $("#tanggal").val(data.tanggal);
      $("#tujuan").val(data.tujuan);
      $("#catatan").val(data.catatan);
      // Sesuaikan tinggi textarea setelah data diisi
      $("#detailIjinKeluar").on("shown.bs.modal", function () {
        $("#tujuan")
          .css("height", "auto")
          .css("height", $("#tujuan")[0].scrollHeight + "px");
        $("#catatan")
          .css("height", "auto")
          .css("height", $("#catatan")[0].scrollHeight + "px");
      });
      setuju = JSON.parse(data.setuju);
      let ulSetuju = $("#setuju");
      ulSetuju.empty(); // Kosongkan daftar sebelum menambahkan elemen baru

      $.each(setuju, function (index, item) {
        if ($.trim(item) !== "") {
          // Menghindari elemen kosong
          ulSetuju.append("<li>" + item + "</li>");
        }
      });
    },
    error: function (e) {
      console.log(e);

      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

// Fungsi untuk mengubah string menjadi CamelCase
function toCamelCase(str) {
  return str
    .toLowerCase()
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" "); // Gabungkan dengan spasi
}

// BARU 2.6
$("#table-2").on("click", ".lihatDetailBangunPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailBangunPagiPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".unduhJurnalGkihPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalGkihPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".unduhJurnalGkihKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalGkihKelas/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailIbadahPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailIbadahPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".unduhJurnalIbadahPd", function() {
  pd_id = $(this).data('id');
  document.location.href = "/unduhJurnalIbadahPd/"+pd_id;
});

$("#table-2").on("click", ".lihatDetailOlahragaPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailOlahragaPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".unduhJurnalOlahragaPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalOlahragaPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailMakanPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailMakanPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".unduhJurnalMakanPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalMakanPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailBelajarPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailBelajarPd/"+peserta_didik_id;
});
$("#table-2").on("click", ".unduhJurnalBelajarPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalBelajarPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailBermasyarakatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailBermasyarakatPd/"+peserta_didik_id;
});
$("#table-2").on("click", ".unduhJurnalBermasyarakatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalBermasyarakatPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailTidurCepatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/guru/lihatDetailTidurCepatPd/"+peserta_didik_id;
});
$("#table-2").on("click", ".unduhJurnalTidurCepatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalTidurCepatPd/"+peserta_didik_id;
});