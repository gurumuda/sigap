$(".logs").load("/load/logs/5").first().fadeIn("slow");

setInterval(function () {
  $(".logs").load("/load/logs/5").fadeIn("slow");
}, 45000);

$("#hapusSemuaLog").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus logs aktivitas",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusLogs",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data === "1") {
            toastr_success("Mantap !", "Logs aktivitas berhasil dikosongkan");
          } else {
            toastr_error(
              "Maaf Bos !",
              "Sepertinya ada data belum bisa direset"
            );
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {},
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#lihatSemuaLog").on("click", function () {
  $("#allLogs").modal("show");
  $("#dataSemuaLogs").load("/load/logs/tidak");
});

$("#tambahBaris").on("click", function () {
  $.ajax({
    type: "POST",
    url: "/ambil/baris",
    data: { action: "addDataRow" },
    success: function (data) {
      $("#tb").append(data);
    },
  });
});

$("#tesKoneksi").on("click", function () {
  $.ajax({
    url: "/tesKoneksi",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    dataType: "json",
    success: function (data) {
      if (data) {
        toastr_success("Mantap !!!", "Koneksi ke dapodik berhasil dibuat");
      } else {
        toastr_error(
          "Walah !!",
          "Sepertinya ada yang salah pada pengaturan koneksi dapodik"
        );
      }
    },
    error: function (e) {},
  });
});

$("#btnResset").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Melakukan reset data aplikasi. Sebaiknya backup database sebelum mereset data !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/resetData",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data === "1") {
            toastr_success("Mantap !", "Database berhasil di reset");
            setTimeout(() => {
              window.location.href = "/logOut";
            }, 3000);
          } else {
            toastr_error(
              "Maaf Bos !",
              "Sepertinya ada data belum bisa direset"
            );
          }
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#pilihhari").on("change", function () {
  hari = $(this).val();
  if (hari != "") {
    $("#tambahBarisJadwal").removeAttr("disabled");
  } else {
    $("#tambahBarisJadwal").attr("disabled", "");
  }
});

$("#tambahBarisJadwal").on("click", function () {
  hari = $("#pilihhari").val();
  ptk_id = $("#ptk_id").val();
  $.ajax({
    type: "POST",
    url: "/ambil/barisjadwal",
    data: { hari, ptk_id },
    dataType: "json",
    success: function (data) {
      $("#tb").append(data);
      $("select").select2();
    },
  });
});

$("#tb").on("click", ".btnDelete", function () {
  $(this).closest("tr").remove();
});

$("#tb").on("click", ".btnCopyJadwal", function () {
  hari = $(this).closest("tr").find(".harii").val();
  kelas = $(this).closest("tr").find(".kelass").val();
  mapel = $(this).closest("tr").find(".mapell").val();
  jam_ke = $(this).closest("tr").find(".jamkee").val();
  ptk_id = $("#ptk_id").val();

  $.ajax({
    type: "POST",
    url: "/copy/barisjadwal",
    data: { hari, kelas, mapel, jam_ke, ptk_id },
    dataType: "json",
    success: function (data) {
      $("#tb").append(data);
      $("select").select2();
    },
    error: function (data) {
      console.log(data);
    },
  });
});

$("#simpanDataSekolah").on("click", function () {
  const npsn = $("#inputNPSN").val();
  const nama = $("#inputNamaSekolah").val();
  const alamat = $("#inputAlamatSekolah").val();
  const website = $("#inputWeb").val();
  const email = $("#inputEmailSekolah").val();
  const tlp = $("#inputTelepon").val();
  const tahunPelajaran = $("#inputTahunPelajaran").val();
  const kepalaSekolah = $("#inputNamaKepalaSekolah").val();
  const nipKepsek = $("#inputNIPKepsek").val();
  const inputLibur = $("#inputLibur").val();
  const jamMasuk = $("#jamMasuk").val();
  const api = $("#inputApi").val();
  const timezone = $("#timezone").val();
  const apitok = $("#inputtoken").val();

  ganjil = "";
  genap = "";
  if ($("#ganjil").is(":checked")) {
    ganjil = "on";
  }
  if ($("#genap").is(":checked")) {
    genap = "on";
  }

  $.ajax({
    url: "/ubah/sekolah",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: {
      npsn,
      nama,
      alamat,
      website,
      email,
      tlp,
      tahunPelajaran,
      kepalaSekolah,
      nipKepsek,
      ganjil,
      genap,
      inputLibur,
      jamMasuk,
      api,
      timezone,
      apitok,
    },
    success: function (data) {
      if (data === "1") {
        toastr_success("Mantap ..!", "Data sekolah berhasil disimpan Bos ...");
      } else {
        toastr_error("Waduu ..!", "Sepertinya data gagal disimpan nih Bos ...");
      }

      setTimeout(() => {
        location.reload();
      }, 4000);
    },
    error: function (e) {
      console.log(e);
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#simpanKoneksi").on("click", function () {
  koneksi = $("#koneksi").val();
  token = $("#token").val();
  if (koneksi != "" || token != "") {
    $.ajax({
      url: "/simpan/koneksi",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { koneksi, token },
      success: function (data) {
        if (data === "1") {
          toastr_success(
            "Mantap,, !",
            "Koneksi berhasil disimpan, silakan lakukan tes koneksi"
          );
        }
      },
      error: function (e) {},
    });
  } else {
    toastr_error("Maaf bos ku", "Silakan lengkapi data");
  }
});

$("#hapusPtk").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/ptk",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusKelas").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/kelas",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
              console.log(data);
            },
            error: function (e) {},
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusPd").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/pd",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusMapel").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/mapel",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusJampel").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/jampel",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Jam pelajaran " + data + " berhasil dihapus Bos ..."
              );
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#copyJampel").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    $("#copyJpModal").modal("show");
    dataId = [];
    $(".checker:checked").each(function () {
      id = $(this).data("idku");
      dataId.push(id);
    });

    $("#tombolCopyJampel").on("click", function () {
      hari = $("#hariTarget").val();
      if (hari != "") {
        $.ajax({
          url: "/copy/jampel",
          type: "POST",
          data: { dataId, hari },
          headers: { "X-Requested-With": "XMLHttpRequest" },
          success: function (data) {
            if (data === "1") {
              toastr_success(
                "Mantap ..!",
                "Jam pelajaran berhasil dicopy Bos ..."
              );
            } else {
              toastr_error(
                "Sory ya bos !",
                "Mungkin ada duplikasi data jam pelajaran"
              );
            }
          },
          error: function (e) {},
        }).done(function () {
          setTimeout(() => {
            location.reload();
          }, 2000);
        });
      } else {
        swal("Bangun bos !!!", "Pilih dulu harinya", "warning");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusJadwal").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/jadwal",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Jadwal pelajaran " + data + " berhasil dihapus Bos ..."
              );
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusSemuaJadwal").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus semua data jadwal",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/semuaJadwal",
        type: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            "Semua Jadwal pelajaran berhasil dihapus Bos ..."
          );
        },
      }).done(function () {
        setTimeout(() => {
          location.reload();
        }, 4000);
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#hapusSemuaJampel").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus semua data jam pelajaran",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/semuaJampel",
        type: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            "Semua Jam pelajaran berhasil dihapus Bos ..."
          );
        },
      }).done(function () {
        setTimeout(() => {
          location.reload();
        }, 4000);
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#setGuru").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Ubah status " + jml + " orang yang terpilih sebagai guru",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/jadikanGuru",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap bos ku ..!",
                data + " sekarang adalah guru ..."
              );
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#setNotGuru").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Ubah status " + jml + " orang yang terpilih jadi TU",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/jadikanTU",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap bos ku ..!",
                data + " sekarang adalah TU ..."
              );
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#ambilPtk").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Mengambil data PTK dari dapodik",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/ambilDapodik/getPengguna",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              data + " data PTK berhasil diambil Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error(
              "Hemm ..!",
              "Sepertinya tidak ada data baru nih Bos ..."
            );
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya data gagal diambil nih Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#ambilKelas").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Mengambil data Kelas dari dapodik",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/ambilDapodik/getRombonganBelajar",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              data + " data kelas berhasil diambil ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error(
              "Hemm ..!",
              "Sepertinya tidak ada data baru nih Bos ..."
            );
          }
        },
        error: function () {
          console.log();
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya data gagal diambil nih Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#ambilPd").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Mengambil data Peserta Didik dari dapodik",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/ambilDapodik/getPesertaDidik",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (Number(data.split("-")[0]) > 0) {
            toastr_success(
              "Mantap ..!",
              data.split("-")[0] + " data Peserta Didik berhasil diambil ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else if (Number(data.split("-")[1]) > 0) {
            toastr_success(
              "Mantap ..!",
              data.split("-")[1] +
                " data Peserta Didik berhasil disesuaikan ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error(
              "Hemm ..!",
              "Sepertinya tidak ada data baru nih Bos ..."
            );
          }
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya data gagal diambil nih Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#sesuaikanPd").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Sesuaikan data kelas dan semester Peserta Didik",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/sesuaikanDataPd",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            data + " data kelas berhasil disesuaikan ..."
          );

          setTimeout(() => {
            location.reload();
          }, 3000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya data gagal disesuaikan nih Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#ambilMapel").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Mengambil data mata pelajaran dari dapodik",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/ambilDapodik/getMapel",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              data + " data mata pelajaran berhasil diambil Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error(
              "Hemm ..!",
              "Sepertinya tidak ada data baru nih Bos ..."
            );
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya data gagal diambil nih Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#simpanDataPtk").on("click", function () {
  id = $("#ptk_id").val();
  nama = $("#nama").val();
  nip = $("#nip").val();
  jenis_kelamin = $("#jenis_kelamin").val();
  tempat_lahir = $("#tempat_lahir").val();
  tanggal_lahir = $("#tanggal_lahir").val();
  username = $("#username").val();
  no_hp = $("#no_hp").val();
  alamat = $("#alamat").val();
  pinLogin = $("#pinLogin").val();
  password = $("#password").val();
  agama_id_str = $("#agama_id_str").val();

  $.ajax({
    url: "/ubah/dataptk",
    type: "post",
    data: {
      id,
      nama,
      nip,
      jenis_kelamin,
      tempat_lahir,
      tanggal_lahir,
      username,
      no_hp,
      alamat,
      pinLogin,
      password,
      agama_id_str,
    },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data != "0") {
        toastr_success(
          "Mantap bos ku ..!",
          "Data " + data + " berhasil diubah ..."
        );
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#simpanDataKelas").on("click", function () {
  id = $("#rombongan_belajar_id").val();
  nama = $("#nama").val();
  tingkat_pendidikan_id = $("#tingkat_pendidikan_id").val();
  username = $("#username").val();
  password = $("#password").val();
  wali = $("#wali").val();
  jenis_rombel = $("#jenis_rombel").val();

  $.ajax({
    url: "/ubah/datakelas",
    type: "post",
    data: {
      id,
      nama,
      tingkat_pendidikan_id,
      username,
      password,
      wali,
      jenis_rombel,
    },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data != "0") {
        toastr_success(
          "Mantap bos ku ..!",
          "Data " + data + " berhasil diubah ..."
        );
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#simpanDataPd").on("click", function () {
  nama = $("#nama").val();
  nisn = $("#nisn").val();
  jenis_kelamin = $("#jenis_kelamin").val();
  agama_id_str = $("#agama_id_str").val();
  sekolah_asal = $("#sekolah_asal").val();
  nik = $("#nik").val();
  tempat_lahir = $("#tempat_lahir").val();
  tanggal_lahir = $("#tanggal_lahir").val();
  alamat_jalan = $("#alamat_jalan").val();
  nama_ayah = $("#nama_ayah").val();
  nama_ibu = $("#nama_ibu").val();
  anak_keberapa = $("#anak_keberapa").val();
  email = $("#email").val();
  peserta_didik_id = $("#peserta_didik_id ").val();
  nomor_telepon_seluler = $("#nomor_telepon_seluler ").val();
  no_ortu = $("#no_ortu ").val();
  rfid = $("#rfid ").val();

  $.ajax({
    url: "/ubah/datapd",
    type: "post",
    data: {
      nama,
      nisn,
      jenis_kelamin,
      agama_id_str,
      sekolah_asal,
      nik,
      tempat_lahir,
      tanggal_lahir,
      alamat_jalan,
      nama_ayah,
      nama_ibu,
      anak_keberapa,
      email,
      peserta_didik_id,
      nomor_telepon_seluler,
      no_ortu,
      rfid,
    },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data != "0") {
        toastr_success(
          "Mantap bos ku ..!",
          "Data " + data + " berhasil diubah ..."
        );
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#simpanDataMapel").on("click", function () {
  id = $("#mata_pelajaran_id").val();
  nama_mata_pelajaran = $("#nama_mata_pelajaran").val();
  kode_mapel = $("#kode_mapel").val();

  $.ajax({
    url: "/ubah/datamapel",
    type: "post",
    data: { id, nama_mata_pelajaran, kode_mapel },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data != "0") {
        toastr_success(
          "Mantap bos ku ..!",
          "Data " + data + " berhasil diubah ..."
        );
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#simpanDataJampel").on("click", function () {
  id = $("#jampel_id").val();
  hari = $("#uhari").val();
  jam_ke = $("#ujam_ke").val();
  mulai = $("#umulai").val();
  selesai = $("#uselesai").val();

  $.ajax({
    url: "/ubah/datajampel",
    type: "post",
    data: { id, hari, jam_ke, mulai, selesai },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data != "0") {
        toastr_success(
          "Mantap bos ku ..!",
          "Data " + data + " berhasil diubah ..."
        );
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
      if (data === "0") {
        toastr_error("Coba dicek lagi", "Mungkin ada duplikasi data bos ....");
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#simpanDataJadwal").on("click", function () {
  id = $("#jadwal_id").val();
  ptk = $("#upkt").val();
  hari = $("#ubhari").val();
  kelas = $("#ukelas").val();
  mapel = $("#umapel").val();
  jam_ke = $("#ujam_ke").val();

  $.ajax({
    url: "/ubah/datajadwal",
    type: "post",
    data: { id, ptk, hari, kelas, mapel, jam_ke },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data === "1") {
        toastr_success("Mantap bos ku ..!", "Data berhasil diubah ...");
        setTimeout(() => {
          location.reload();
        }, 2000);
      }
      if (data === "2" || data === "3") {
        toastr_error("Coba dicek lagi", "Mungkin ada duplikasi data bos ....");
      }
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya data gagal disimpan nih Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".ubahPtk", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/dataptk",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#nama").val(data.nama);
      $("#nip").val(data.nip);
      $("#username").val(data.username);
      $("#no_hp").val(data.no_hp);
      $("#alamat").val(data.alamat);
      $("#ptk_id").val(data.ptk_id);
      $("#jenis_kelamin").val(data.jenis_kelamin);
      $("#agama_id_str").val(data.agama_id_str);
      $("#tanggal_lahir").val(data.tanggal_lahir);
      $("#tempat_lahir").val(data.tempat_lahir);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".ubahKelas", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datakelas",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#nama").val(data.nama);
      $("#tingkat_pendidikan_id").val(data.tingkat_pendidikan_id);
      $("#username").val(data.username);
      $("#rombongan_belajar_id").val(data.kelas_id);
      $("#wali").val(data.ptk_id);
      $("#jenis_rombel").val(data.jenis_rombel);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".ubahPd", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datapd",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#nama").val(data.nama);
      $("#nisn").val(data.nisn);
      $("#jenis_kelamin").val(data.jenis_kelamin);
      $("#agama_id_str").val(data.agama_id_str);
      $("#sekolah_asal").val(data.sekolah_asal);
      $("#nik").val(data.nik);
      $("#tempat_lahir").val(data.tempat_lahir);
      $("#tanggal_lahir").val(data.tanggal_lahir);
      $("#alamat_jalan").val(data.alamat_jalan);
      $("#nama_ayah").val(data.nama_ayah);
      $("#nama_ibu").val(data.nama_ibu);
      $("#anak_keberapa").val(data.anak_keberapa);
      $("#email").val(data.email);
      $("#peserta_didik_id ").val(data.peserta_didik_id);
      $("#nomor_telepon_seluler ").val(data.nomor_telepon_seluler);
      $("#no_ortu ").val(data.no_ortu);
      $("#rfid").val(data.rfid);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".ubahJampel", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datajampel",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#uhari").val(data.hari);
      $("#ujam_ke").val(data.jam_ke);
      $("#umulai").val(data.mulai);
      $("#uselesai").val(data.selesai);
      $("#jampel_id").val(data.jampel_id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".ubahJadwal", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datajadwal",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#upkt").val(data.jadwal.ptk_id);
      $("#ubhari").val(data.jadwal.hari);
      $("#ukelas").val(data.jadwal.rombongan_belajar_id);
      $("#umapel").val(data.jadwal.mata_pelajaran_id);
      $("#ujam_ke").html(data.jam);

      $("#jadwal_id").val(data.jadwal.jadwal_id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#ubhari").on("change", function () {
  hari = $(this).val();
  if (hari != "") {
    $.ajax({
      url: "/ambil/jamke",
      type: "post",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { hari },
      success: function (data) {
        $("#ujam_ke").html(data);
      },
    });
  }
});

$("#table-2").on("click", ".ubahMapel", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datamapel",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#nama_mata_pelajaran").val(data.nama_mata_pelajaran);
      $("#kode_mapel").val(data.kode_mapel);
      $("#mata_pelajaran_id").val(data.mata_pelajaran_id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".hapusPtk", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/ptk",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusKelas", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/kelas",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusPd", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/pd",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusMapel", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/mapel",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusJampel", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");
  ke = $(this).data("ke");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data jam pelajaran " + ke + " hari " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/jampel",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusJadwal", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");
  ke = $(this).data("ke");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data jadwal pelajaran " + ke + " hari " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/jadwal",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success(
            "Mantap ..!",
            "Jadwal " + data + " berhasil dihapus Bos ..."
          );
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".abc", function () {
  var idnyaa = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data berita ini",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/pemberitahuan",
        type: "post",
        data: { idnyaa },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", "Data berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 2000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$(".select2").select2({
  dropdownParent: $(".modal-body, .form-group"),
});

$("#table-2").on("click", ".tampilAnggota", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/anggotaRombel",
    type: "post",
    data: { id },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    dataType: "json",
    success: function (data) {
      $("#tampilanAnggota").modal("show");
      $("#dataRombel").html(data);
      $("#dataIdKelas").html(id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Sepertinya coba tanyakan ke polsek Bos ... "
      );
    },
  });
});

$("#dataRombel").on("click", ".anggotaku", function () {
  id = $(this).data("id");
  nama = $(this).data("nama");
  rombongan_belajar_id = $(this).data("rombel");
  tp = $(this).data("tp");
  whichtr = $(this).closest("tr");

  if (nama === "") {
    nama = "TANPA NAMA";
  }

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama + " dari rombel",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/anggotaRombel",
        type: "post",
        data: { id, rombongan_belajar_id, tp },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data == 1) {
            whichtr.remove();
            toastr_success("Mantap ..!", "data berhasil dihapus Bos ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#matapelajaran").on("change", function () {
  id = $(this).val();
  if (id != "") {
    $.ajax({
      url: "/ambil/pengajar",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { id },
      dataType: "json",
      success: function (data) {
        $("#penipu").html(data);
        $("select").select2();
      },
      error: function (e) {},
    });
  }
});

$("#penipu").on("change", ".gurunya", function () {
  data_pembelajaran_id = $(this).data("id");
  ptk_id = $(this).val();

  $.ajax({
    url: "/ubah/pembelajaran",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { data_pembelajaran_id, ptk_id },
    success: function (data) {
      if (data === "1") {
        toastr_success("Mantap !", "data pengajar berhasil diubah");
      }
    },
    error: function (e) {},
  });
});

$("#penipu").on("change", ".kelasnya", function () {
  data_pembelajaran_id = $(this).data("id");
  kelas_id = $(this).val();

  $.ajax({
    url: "/ubah/kelasPembelajaran",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { data_pembelajaran_id, kelas_id },
    success: function (data) {
      if (data === "1") {
        toastr_success("Mantap !", "data kelas berhasil diubah");
      }
    },
    error: function (e) {},
  });
});

$("#select_kelas").on("change", function () {
  id = $(this).val();
  if (id != "") {
    $.ajax({
      url: "/ambil/pdnya",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { id },
      success: function (data) {
        $("#sortable1").html(data);
      },
      error: function (e) {},
    });

    $.ajax({
      url: "/ambil/semuapdnya",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { id },
      success: function (data) {
        $("#sortable2").html(data);
      },
      error: function (e) {
        console.log(e);
      },
    });
  }
});

$("#btnDaftarAnggotaKelas").on("click", function () {
  jml = $(".checker:checked").length;
  kelas = $("#select_kelas").val();

  if (kelas == "") {
    toastr_error("Maaf bos ku ..!", "Pilih dulu kelasnya");
    return false;
  }

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Memasukkan " + jml + " data siswa yang terpilih ke kelas",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/daftarkan/pdkeKelas",
            type: "POST",
            data: { id, kelas },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + "...");
            },
            error: function (e) {},
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 2000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu data siswanya", "warning");
  }
});

$("#simpanAturPembelajaran").on("click", function () {
  id_rombel = $("#kelasPembelajaran").val();
  id_mapel = $("#mapelPembelajaran").val();
  id_guru = $("#guruPembelajaran").val();
  jpMapel = $("#jpMapel").val();

  if (id_rombel != "" && id_mapel != "" && id_guru != "" && jpMapel != "") {
    $.ajax({
      url: "/simpanDataPembelajaran",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { id_rombel, id_mapel, id_guru, jpMapel },
      success: function (data) {
        console.log(data);
        if (data.includes("0")) {
          toastr_error(
            "Maaf bos",
            "kemungkinan tidak semua data disimpan karena masalah duplikasi"
          );
        } else {
          toastr_success("Mantap,, !", "Semua data berhasil disimpan");
        }
      },
      error: function (e) {},
    }).done(function () {
      setTimeout(() => {
        location.reload();
      }, 2000);
    });
  } else {
    toastr_error("Maaf bos ku", "lengkapi datanya");
  }
});

$("#penipu").on("click", ".hapusPembelajaran", function () {
  pembelajaran_id = $(this).data("id");
  mytr = $(this).closest("tr");

  $.ajax({
    url: "/hapus/pembelajaran",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { pembelajaran_id },
    success: function (data) {
      if (data === "1") {
        toastr_success("Mantap,,", "data berhasil dihapus");
        mytr.remove();
      }
    },
    error: function (e) {},
  });
});

$("#hapusSemuaPtk").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Semua data PTK",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusSemuaPtk",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              "Semua data PTK berhasil dihapus Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error("Hemm ..!", "Sepertinya ada kesalahan sistem ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Coba tanyakan ke Pak RT, mungkin tau penyebabnya ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaGuru").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Semua data Guru",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusSemuaGuru",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              "Semua data Guru berhasil dihapus Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error("Hemm ..!", "Sepertinya ada kesalahan sistem ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Coba tanyakan ke Pak RT, mungkin tau penyebabnya ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaKelas").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Semua data kelas",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusSemuaKelas",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              "Semua data kelas dan anggotanya berhasil dihapus Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error("Hemm ..!", "Sepertinya ada kesalahan sistem ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Coba tanyakan ke Pak RT, mungkin tau penyebabnya ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaPd").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Semua data peserta didik",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusSemuaPd",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              "Semua data peserta didik berhasil dihapus Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error("Hemm ..!", "Sepertinya ada kesalahan sistem ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Coba tanyakan ke Pak RT, mungkin tau penyebabnya ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaMapel").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Semua data mata pelajaran",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusSemuaMapel",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              "Semua data mata pelajaran berhasil dihapus Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error("Hemm ..!", "Sepertinya ada kesalahan sistem ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Coba tanyakan ke Pak RT, mungkin tau penyebabnya ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaPembelajaran").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Akan menghapus semua data pembelajaran",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapusSemuaPembelajaran",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data > 0) {
            toastr_success(
              "Mantap ..!",
              "Semua data mata pelajaran berhasil dihapus Bos ..."
            );
            setTimeout(() => {
              location.reload();
            }, 3000);
          } else {
            toastr_error("Hemm ..!", "Sepertinya ada kesalahan sistem ...");
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Coba tanyakan ke Pak RT, mungkin tau penyebabnya ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".cetakAgenda", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/dataAgendaGuru",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#formCetakAgenda").modal("show");
      $("#ptk_id").val(id);
      $("#mapelCetak").html(data);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#mapelCetak").on("change", function () {
  idMapel = $(this).val();
  ptk_id = $("#ptk_id").val();

  if (idMapel != "") {
    $.ajax({
      url: "/ambil/tahunPelajaran",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { idMapel, ptk_id },
      dataType: "json",
      success: function (data) {
        $("#tpCetak").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#tpCetak").on("change", function () {
  idMapel = $("#mapelCetak").val();
  tahunPelajaran = $(this).val();
  ptk_id = $("#ptk_id").val();

  if (idMapel != "" && tahunPelajaran != "") {
    $.ajax({
      url: "/ambil/bulan",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { idMapel, tahunPelajaran, ptk_id },
      dataType: "json",
      success: function (data) {
        $("#bulanCetak").html(data);
      },
      error: function (e) {},
    });
  }
});

function cekCetak() {
  mapelCetak = $("#mapelCetak").val();
  tpCetak = $("#tpCetak").val();
  bulanCetak = $("#bulanCetak").val();
  if (mapelCetak == "" || tpCetak == "" || bulanCetak == "") {
    toastr_error("Maaf bos ku,, !", "Data belum lengkap");
    return false;
  }
}

$("#cetakHadirHari").on("click", function () {
  location.href = "/cetak/hadirhari";
});

$("#table-2").on("click", ".lihatKehadiran", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/dataHadirGurudiKelas",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      // console.log(data);
      $("#lihatHadirnya").modal("show");
      $("#tampiHadirGuru").html(data);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#btnAmbilHariLibur").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Anda akan mengambil data hari libur dari https://publicholidays.co.id/",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      location.href = "/ambilharilibur";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaHariLibur").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Anda akan menghapus semua data hari libur",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      location.href = "/hapusSemuaHariLibur";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#cetakhadirtanggal").on("click", function () {
  tanggalMulai = $("#tanggalMulai").val();
  tanggalSelesai = $("#tanggalSelesai").val();

  if (tanggalMulai != "" && tanggalSelesai != "") {
    location.href =
      "/cetak/hadirtanggal/" + tanggalMulai + "/" + tanggalSelesai;
  } else {
    toastr_error("Walah boss...", "Data belum lengkap sudah mau dicetak");
  }
});

$("#btnGenAkunKelas").on("click", function () {
  location.href = "/genAkunkelas";
});

$("#table-2").on("click", ".detialAbs", function () {
  id = $(this).data("idku");
  namanya = $(this).data("namanya");
  kelas = $(this).data("kelas");
  mulai = $("#mulaitanggal").val();

  $.ajax({
    url: "/ambil/detailAbsenPd",
    type: "post",
    data: { id, mulai },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#exampleModal").modal("show");
      $("#namaSiswa").html(namanya + " Kelas " + kelas);
      $("#detailAb").html(data);
      $("#theid").val(id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#cetakDetailAbsPd").on("click", function () {
  id = $("#theid").val();
  mulai = $("#mulaitanggal").val();

  if (mulai != "") {
    tgl = mulai;
  } else {
    tgl = "nol";
  }
  location.href = "/cetakDetailAbsebPd/" + id + "/" + tgl;
});

$("#btnTambahKonsek").on("click", function () {
  ket_konsekuensi = $("#ketkonsek").val();

  if (ket_konsekuensi != "") {
    $.ajax({
      url: "/tambah/konsekuensi",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { ket_konsekuensi },
      success: function (data) {
        if (data != "0") {
          $("#myTable tr:last").after(data);
          toastr_success("Mantap bos,,", "Data berhasil ditambah");
          $("#ketkonsek").focus();
        }
      },
      error: function (e) {},
    });
  } else {
    toastr_error("Maaf bos", "data konsekuensi tidak boleh kosong");
  }
});

$(".btnhapuskonsekuensi").on("click", function () {
  id = $(this).data("id");
  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data yang masih digunakan akan menyebabkan error !, pastikan data ini sudah tidak digunakan",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      location.href = "/hapus/konsekuensi/" + id;
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusPelanggaran").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/listpelanggaran",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusSemuaPelanggaran").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Anda akan menghapus semua data pelanggaran",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      location.href = "/hapusSemuaListPelanggaran";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".ubahPelanggaran", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/datalistpelanggaran",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      console.log(data);
      $("#exampleModal").modal("show");
      $("#bodyubahpelanggaran").html(data);
      $("select").select2();
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".hapusPelanggaran", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/listpelanggaran",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#kelas_pelanggar").on("change", function () {
  rombongan_belajar_id = $(this).val();

  if (rombongan_belajar_id != "") {
    $.ajax({
      url: "/ambil/siswaPelanggar",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { rombongan_belajar_id },
      success: function (data) {
        $("#pd_melanggar").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#pelanggaran").on("change", function () {
  id_pelanggaran = $(this).val();

  if (id_pelanggaran != "") {
    $.ajax({
      url: "/ambil/konsekuensi",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { id_pelanggaran },
      success: function (data) {
        $("#poin_negatif").val(data[0].poin);
        $("#konsekuensi_diambil").html(data[1].konsekuensi);
      },
      error: function (e) {},
    });
  }
});

$("#table-2").on("click", ".btnHpsPelanggaran", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/pelanggaransiswa",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".hapusPrestasi", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data prestasi " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/prestasi",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#hapusSemuaAnggota").on("click", function () {
  id = $("#dataIdKelas").html();

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus semua anggota kelas ini",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/semuaAnggotaKelas",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data === "1") {
            toastr_success("Mantap ..!", "Semua data berhasil dihapus Bos ...");
            setTimeout(() => {
              location.reload();
            }, 4000);
          }
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#switchAbsen").on("change", function () {
  $.ajax({
    url: "/ubah/statusInputAbsen",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data === "1") {
        toastr_success("OK bos !", "Input absensi kelas diaktivkan");
      } else {
        toastr_success("OK bos !", "Input absensi kelas dinonaktivkan");
      }
    },
    error: function (e) {},
  });
});

async function test() {
  try {
    $.ajax({
      url: "/testAPI",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      success: function (data) {
        return data;
      },
      error: function (e) {
        console.log(e);
      },
    });
  } catch (error) {
    return null;
  }
}

$("#testAPI").on("click", function () {
  $("#loading").show();
  (async function () {
    let res = await test();
    if (res === "1") {
      $("#loading").hide();
      toastr_success("Mantap !", "Whatsapp API siap digunakan !");
    } else {
      await test();
      $("#loading").hide();
    }
  })();
});

function delay() {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve(42);
    }, 5000);
  });
}

async function test() {
  try {
    let a;
    $.ajax({
      url: "/testAPI",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      success: function (data) {
        a = data;
      },
      error: function (e) {
        console.log(e);
      },
    });
    await delay();
    return await a;
  } catch (error) {
    return null;
  }
}
// Start an IIFE to use `await` at the top level

$("#tombolKirimJadwal").on("click", function () {
  $.ajax({
    url: "/home/jadwalHariIni",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    dataType: "json",
    success: function (data) {
      jumlah = data.length;
      if (jumlah < 1) {
        swal("Maaf,, ! Tidak ada jadwal pada hari ini");
      } else {
        swal({
          title: "",
          text:
            "Anda akan mengirimkan jadwal " + jumlah + " orang guru hari ini",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        }).then((willDelete) => {
          if (willDelete) {
            $("#loading").show();
            $.ajax({
              url: "/home/kirimJadwalGuru",
              type: "GET",
              headers: { "X-Requested-With": "XMLHttpRequest" },
              success: function (data) {
                $("#loading").hide();
                setTimeout(() => {
                  $("#modalHasil").modal("show");
                  $("#tampilHasil").html(data);
                }, 1000);
              },
              error: function (e) {},
            });
          } else {
            swal("Pikir-pikir lagi yaa,, !");
          }
        });
      }
    },
    error: function (e) {},
  });
});

$("#cetakPdPerkelas").on("click", function () {
  window.location.href = "/home/cetakPdPerkelas";
});

$("#table-2").on("click", ".hpskelast", function () {
  id_ptk = $(this).data("idklst");
  nama = $(this).data("nmklst");

  swal({
    title: "",
    text: "Anda akan menghapus " + nama + " sebagai pengelola aset !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $("#loading").show();
      $.ajax({
        url: "/hapus/pengelolaAset",
        type: "POST",
        data: { id_ptk },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data == "1") {
            toastr_success("Mantap !", "Data berhasil dihapus");
          }
          setTimeout(() => {
            location.reload();
          }, 1000);
        },
        error: function (e) {},
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#copyDariSemesterLalu").on("click", function () {
  swal({
    title: "Sudah yakin !",
    text: "Anda akan menduplikat data kelas dari semester sebelumnya !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      document.location.href = "/duplikat/kelas";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#copyPembelajaran").on("click", function () {
  swal({
    title: "Sudah yakin !",
    text: "Anda akan menduplikat data pembelajaran dari semester sebelumnya !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      document.location.href = "/duplikat/pembelajaran";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#duplikatJampel").on("click", function () {
  swal({
    title: "Sudah yakin !",
    text: "Anda akan menduplikat data jam pelajaran dari semester sebelumnya !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      document.location.href = "/duplikat/jampel";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#copyJadwal").on("click", function () {
  swal({
    title: "Sudah yakin !",
    text: "Anda akan menduplikat data jadwal pelajaran dari semester sebelumnya !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      document.location.href = "/duplikat/jadwal";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#kelasCetak").on("change", function () {
  rombongan_belajar_id = $(this).val();

  $.ajax({
    url: "/ambil/BulanCetakAbsenSiswa",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { rombongan_belajar_id },
    success: function (data) {
      // console.log(data);
      $("#bulanCetak").html(data);
    },
    error: function (e) {},
  });
});

$("#table-2").on("click", ".dtlRankLanggar", function () {
  idnyal = $(this).data("idnyal");

  $.ajax({
    url: "/ambil/dtlKetRankLanggar",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { idnyal },
    success: function (data) {
      $("#tampilDtlRankPel").modal("show");
      $("#dataDetailPel").html(data);
    },
    error: function (e) {},
  });
});

$("#cekVersiApp").on("click", function () {
  $.ajax({
    url: "/cekVersiApp",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      // console.log(data);
      $("#modalcekversi").modal("show");
      $("#dataversi").html(data);
    },
    error: function (e) {
      swal("Gagal terhubung dengan server SIGAP, check koneksi internet !");
    },
  });
});

$("#dataversi").on("click", "#btnUpdateSc", function () {
  $("#modalcekversi").modal("hide");
  swal({
    title: "Konfirmasi !",
    text: "Anda akan melakukan Update aplikasi SIGAP",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $("#loading").show();

      $.ajax({
        url: "/updateApp",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        dataType: "json",
        success: function (data) {
          // console.log(data.code);
          $("#loading").hide();
          let listHtml = "";
          if (data.db === "1" || data.db === "2") {
            if (data.prosesdb.length > 0) {
              listHtml += "<ul>";
              data.prosesdb.forEach(function (item) {
                listHtml += `<li>${item}</li>`;
              });
              listHtml += "</ul>";
            } else {
              listHtml += "Tidak ada perubahan struktur database";
            }
          }

          if (data.code === "1" && data.db === "1") {
            $("#hasilUpdate").modal("show");
            $("#infoyangdiupdate").html("Code dan Database");
            head =
              "<h4>Update code dan database berhasil</h4><br>Daftar perubahan/penambahan database :<br>";
            $("#tampilHasilUpdate").html(head + listHtml);
          }
          if (data.code === "1" && data.db === "0") {
            $("#hasilUpdate").modal("show");
            $("#infoyangdiupdate").html("Code Aplikasi");
            head =
              "<h4>Update code berhasil, Silakan cek pembaharuan database</h4>";
            $("#tampilHasilUpdate").html(head);
          }
          if (data.code === "1" && data.db === "3") {
            toastr_success("Mantap !", "Code Aplikasi berhasil diperbaharui");
          }
          if (data.code === "2") {
            toastr_error("Maaf !", "Gagal membaca file updater !");
          }
          if (data.code === "0") {
            toastr_error(
              "Maaf !",
              "Tidak bisa melakukan ekstraksi file update"
            );
          }
          if (data.code === "3") {
            toastr_error("Maaf !", "Aplikasi sudah versi terbaru !");
          }
          if (data.code === "4") {
            toastr_error(
              "Maaf !",
              "Gagal mengunduh file updater dari server SIGAP !"
            );
          }
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});


$("#dataversi").on("click", "#btnUpdateDatabase", function () {
  $("#modalcekversi").modal("hide");
  swal({
    title: "Konfirmasi !",
    text: "Anda akan melakukan Update database SIGAP",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $("#loading").show();
      $.ajax({
        url: "/updateDatabase",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        dataType: "json",
        success: function (data) {
          $("#loading").hide();
          let listHtml = "";
          if (data.status === "1" || data.status === "2") {
            if (data.prosesdb.length > 0) {
              listHtml += "<ul>";
              data.prosesdb.forEach(function (item) {
                listHtml += `<li>${item}</li>`;
              });
              listHtml += "</ul>";
            } else {
              listHtml += "Tidak ada perubahan struktur database";
            }
          }

          if (data.status === "1") {
            $("#hasilUpdate").modal("show");
            $("#infoyangdiupdate").html("Database");
            head =
              "<h4>Update database berhasil</h4><br>Daftar perubahan/penambahan :<br>";
            $("#tampilHasilUpdate").html(head + listHtml);
          }
          if (data.status === "2") {
            $("#hasilUpdate").modal("show");
            head =
              "<h4>Update database berhasil</h4><br>Daftar perubahan/penambahan :<br>";
            $("#tampilHasilUpdate").html(head + listHtml);
          }
          if (data.status === "0") {
            toastr_error("Waduw error bos !", "Database gagal diperbaharui");
          }
          if (data.status === "3") {
            toastr_error("Hemm !", "Versi database sudah yang paling baru");
          }
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#btntambahpeserta").on("click", function () {
  pst = $("#tambahPeserta").val();

  if (pst != "") {
    $.ajax({
      url: "/ambil/pesertaKegiatan",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { pst },
      success: function (data) {
        console.log(data);
        $("#modal_tambah_peserta_kegiatan").modal("hide");
        $("#tambahPeserta").val("");
        $("#tambahPeserta")
          .children("#" + pst)
          .hide();
        if (pst === "alltcr") {
          $("#tambahPeserta").children("#tcr").hide();
        }
        if (pst === "allcls") {
          $("#tambahPeserta").children("#cls, #std").hide();
        }
        $("#tampil_peserta").append(data);
        $(".select2").select2();
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
    swal("Peserta belum dipilih,, !");
  }
});

$("#table-2").on("click", ".hapusKegiatanSekolah", function () {
  nama = $(this).data("nama");
  id = $(this).data("id");
  swal({
    title: "Konfirmasi !",
    text: "Hapus kegiatan " + nama + " ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusKegiatanSekolah",
        type: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        data: { id },
        success: function (data) {
          if (data == "1") {
            toastr_success("Mantap !", "Data berhasil dihapus");
            setTimeout(() => {
              window.location.reload();
            }, 3000);
          }
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".kirimKegiatan", function () {
  id = $(this).data("id");
  nama = $(this).data("nama");
  swal({
    title: "Konfirmasi !",
    text: "Kirim kehadiran kegiatan " + nama + " ke WA ortu ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/kirimKehadiranKegiatan",
        type: "POST",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        data: { id },
        success: function (data) {
          console.log(data);

          toastr_success(
            "Mantap !",
            data + " pesan akan dikirimkan ke whatsapp"
          );
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hpsPesaWa").on("click", function () {
  swal({
    title: "Konfirmasi !",
    text: "Hapus data pesan ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusPesanWA",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data == "1") {
            toastr_success("Mantap !", "data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#tampilRouter").on("click", function () {
  $.ajax({
    url: "/cekRouter",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#modaltampilRouter").modal("show");
      $("#tampilannya").html(data);
    },
    error: function (e) {
      toastr_error("Maaf bos !!", "Gagal menghubungkan ke router");
    },
  });
});

$("#generateUserMikrotik").on("click", function () {
  swal({
    title: "Konfirmasi !",
    text: "Generate seeder user mikrotik ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/genUserMikrotik",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success("Mantap !", data + " data berhasil dibuat");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#updatemk").on("click", function () {
  swal({
    title: "Pastikan sudah terkoneksi dengan router !",
    text: "Update status user mikrotik ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/updateUserMikrotik",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success("Mantap !", data + " data berhasil diupdate");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSemuaUM").on("click", function () {
  swal({
    title: "Hapus semua user !",
    text: "Aksi ini juga menghapus user di router ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusSemuaUM",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap !", "data berhasil dihapus");
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".hpsum", function () {
  id = $(this).data("id");
  nama = $(this).data("nama");

  swal({
    title: "Konfirmasi hapus " + nama,
    text: "Aksi ini juga menghapus user di router ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusUserMikrotik",
        type: "POST",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success("Mantap !", "data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#aktivsemUM").on("click", function () {
  swal({
    title: "Aktivasi !",
    text: "Aktivkan semua user ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/aktivkansemuaUM",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap !", "data berhasil diaktivkan");
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#resetsemUM").on("click", function () {
  swal({
    title: "Reset Counter !",
    text: "Reset data byte-out semua user ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/resetsemUM",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success("Mantap !", "data berhasil diaktivkan");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".resetum", function () {
  id = $(this).data("id");
  nama = $(this).data("nama");

  swal({
    title: "Konfirmasi reset !",
    text: "Reset byte-out " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/resetusermikrotik",
        type: "POST",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success("Mantap !", "data berhasil direset");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#hapusSeeder").on("click", function () {
  swal({
    title: "Hapus data seeder ?",
    text: "Hapus data seeder dan user mikrotik ?",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusSeeder",
        type: "GET",
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data > 0) {
            toastr_success("Mantap !", "data berhasil diaktivkan");
          }
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".activum", function () {
  id = $(this).data("id");
  nama = $(this).data("nama");

  swal({
    title: "Konfirmasi aktivasi !",
    text: "Aktivkan user " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/aktivkanUM",
        type: "POST",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap !", "user berhasil diaktivkan");

          setTimeout(() => {
            window.location.reload();
          }, 2000);
        },
        error: function (e) {
          console.log(e);
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#cetakKartuTerpilih").on("click", function () {
  jml = $(".checker:checked").length;
  var oTable = $("#table-2").dataTable();

  if (jml > 0) {
    idnya = [];

    $(".checker:checked", oTable.fnGetNodes()).each(function () {
      id = $(this).data("idku");
      idnya.push(id);
    });
    $.ajax({
      url: "/pilih/multiKartu",
      type: "POST",
      data: { idnya },
      headers: { "X-Requested-With": "XMLHttpRequest" },
      success: function (data) {
        window.open("/cetak/multiKartu", "_blank");
      },
      error: function (e) {},
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#table-2").on("click", ".btnHapusFoto", function () {
  id = $(this).data("idnya");
  namanya = $(this).data("nama");

  swal({
    title: "Sudah yakin !",
    text: "Anda akan menghapus foto " + namanya + " !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapus/fotoPd",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap", "Data berhasil dihapus");
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);

          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#simpanDataPerangkat").on("click", function () {
  nama_perangkat = $("#nama_perangkat").val();
  jenis_file = $("#jenis_file").val();
  jenis_perangkat = $("#jenis_perangkat").val();

  if (nama_perangkat != "" && jenis_file != "" && jenis_perangkat != "") {
    $.ajax({
      url: "/tambahDataPerangkat",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { nama_perangkat, jenis_file, jenis_perangkat },
      success: function (data) {
        if (data === "1") {
          toastr_success("Ok bos", "Data berhasil disimpan");
        } else {
          toastr_error("Maaf ", "Data gagal disimpan");
        }
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
    toastr_error("Maaf ", "Data tidak lengkap !");
  }
});

$("#modalTambahPerangkat").on("hidden.bs.modal", function () {
  window.location.reload();
});

$("#table-2").on("click", ".detailPerangkat", function () {
  ptk_id = $(this).data("guru");
  perangkatajar_id = $(this).data("prgid");

  $.ajax({
    url: "/ambil/dataPerangkatGuru",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { ptk_id, perangkatajar_id },
    dataType: "json",
    success: function (data) {
      $("#detailPerangkatGuru").modal("show");
      $("#datanyaDetail").html(data);
      // console.log(data);
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#table-2").on("click", ".hapusperangkatajar", function () {
  perangkatajar_id = $(this).data("id");
  nama_perangkat = $(this).data("nama");

  swal({
    title: "Sudah yakin menghapus data " + nama_perangkat + " !",
    text: "Aksi ini juga menghapus seluruh file " + nama_perangkat + " !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusperangkatajar",
        type: "post",
        data: { perangkatajar_id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".dtkehadirankegiatan", function () {
  peserta_didik_id = $(this).data("id");

  $.ajax({
    url: "/ambildetailhadirkegiatan",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { peserta_didik_id },
    success: function (data) {
      $("#modaldetailpesertakegiatan").modal("show");
      $("#tampildetailhadirkegiatan").html(data);
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#table-2").on("click", ".manualHadirKegiatan", function () {
  nama = $(this).data("nama");
  peserta_didik_id = $(this).data("id");
  kegiatansekolah_id = $("#kegiatanid").val();
  swt = $(this).data("switch");

  $.ajax({
    url: "/hadirmanualkegiatansekolah",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { peserta_didik_id, kegiatansekolah_id },
    success: function (data) {
      if (data == "1") {
        toastr_success("Ok", nama + " hadir dikegiatan ini");
        $("#swt" + swt).attr("disabled", "");
      } else {
        toastr_warning("Ok", nama + " dinyatakan tidak hadir");
      }
    },
    error: function (e) {},
  });
});

$("#table-2").on("click", ".ijinKegiatan", function () {
  nama = $(this).data("nama");
  peserta_didik_id = $(this).data("id");
  kegiatansekolah_id = $("#kegiatanid").val();

  $.ajax({
    url: "/ijinkegiatansekolah",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { peserta_didik_id, kegiatansekolah_id },
    success: function (data) {
      if (data == "1") {
        toastr_success("Ok !", nama + " ijin tidak mengikuti kegiatan");
      }
      if (data == "3") {
        toastr_warning("Ok !", "ijin " + nama + " dicabut");
      }
      if (data == "0") {
        toastr_error("Maaf !", "data gagal disimpan");
      }
      if (data == "2") {
        toastr_error("Maaf !", nama + " tercatat mengikuti kegiatan");
      }
    },
    error: function (e) {},
  });
});

$("#table-2").on("click", ".ubahKebiasaan", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/kebiasaan",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      // console.log(data);
      $("#exampleModal").modal("show");
      // $("#bodyubahpelanggaran").html(data);
      // $("select").select2();
      $("#kebiasaan_id").val(data.kebiasaan_id);
      $("#nama_kebiasaan").val(data.nama_kebiasaan);
      $("#deskripsii").text(data.deskripsi);
      $("#poin").val(data.poin);
    },
    error: function (e) {
      // console.log(e);

      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".hapusKebiasaan", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/listkebiasaan",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#hapusKebiasaan").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/listkebiasaan",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
            },
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#hapusSemuaKebiasaan").on("click", function () {
  swal({
    title: "Sudah yakin bos ?",
    text: "Anda akan menghapus semua data kebiasaan",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      location.href = "/hapusSemuaListKebiasaan";
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#kelas_positif").on("change", function () {
  rombongan_belajar_id = $(this).val();

  if (rombongan_belajar_id != "") {
    $.ajax({
      url: "/ambil/siswaPelanggar",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { rombongan_belajar_id },
      success: function (data) {
        $("#pd_positif").html(data);
      },
      error: function (e) {},
    });
  }
});

$("#kebiasaan").on("change", function () {
  kebiasaan_id = $(this).val();

  if (kebiasaan_id != "") {
    $.ajax({
      url: "/ambil/poinpositif",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      dataType: "json",
      data: { kebiasaan_id },
      success: function (data) {
        $("#poin").val(data.poin);
      },
      error: function (e) {},
    });
  }
});

$("#table-2").on("click", ".btnHpsDataKebiasaan", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/dataPositifSiswa",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#searchInput").on("keyup", function () {
  var value = $(this).val().toLowerCase();
  $("#sortable2 li").filter(function () {
    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
  });
});

$(function () {
  let isProcessing = false;
  $("#sortable1, #sortable2")
    .sortable({
      connectWith: ".connectedSortable",
      start: function (event, ui) {
        ui.item.data("startlist", ui.item.parent().attr("id"));
        isProcessing = false; // Reset the flag when dragging starts
      },
      update: function (event, ui) {
        if (isProcessing) return; // If already processing, skip the rest

        var startList = ui.item.data("startlist");
        var newList = ui.item.parent().attr("id");

        // Only save data if the item was moved to a different list
        if (startList !== newList) {
          isProcessing = true; // Set the flag to indicate processing started

          var kelas = $("#select_kelas").val(); // id kelas
          var id = ui.item.data("id"); // id siswa

          $.ajax({
            url: "/daftarkan/pdkeKelas",
            method: "POST",
            headers: {
              "X-Requested-With": "XMLHttpRequest",
            },
            data: {
              id: id,
              kelas: kelas,
              startList: startList,
            },
            success: function (response) {
              console.log("Data saved successfully");
              toastr_success("Mantap !", response);
              isProcessing = false; // Reset the flag once processing is done
            },
            error: function (jqXHR, textStatus, errorThrown) {
              console.error("Error saving data: " + textStatus, errorThrown);
              isProcessing = false; // Reset the flag even if there's an error
            },
          });
        }
      },
    })
    .disableSelection();
});

function cekformatimportbpast() {
  var checkboxes = document.querySelectorAll(".checker");
  var isChecked = false;
  for (var checkbox of checkboxes) {
    if (checkbox.checked) {
      isChecked = true;
      break;
    }
  }
  if (!isChecked) {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
    return false;
  }
  $("#downFormatGuru").modal("hide");
  return true;
}

$("#uploadtodrive").on("change", function () {
  $.ajax({
    url: "/ubah/statusUploadDrive",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data === "1") {
        toastr_success("OK bos !", "Upload file ke drive diaktivkan");
      }
      if (data == "2") {
        toastr_error("Sorry bos !", "Salah satu penyimpanan harus aktif");
        setTimeout(() => {
          window.location.reload();
        }, 3000);
      }
      if (data == "0") {
        toastr_success("OK bos !", "Upload file ke drive di non-aktivkan");
      }
    },
    error: function (e) {},
  });
});

$("#uploadtoserver").on("change", function () {
  $.ajax({
    url: "/ubah/statusUploadServer",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      if (data === "1") {
        toastr_success("OK bos !", "Upload file ke server diaktivkan");
      }
      if (data == "2") {
        toastr_error("Sorry bos !", "Salah satu penyimpanan harus aktif");
        setTimeout(() => {
          window.location.reload();
        }, 3000);
      }
      if (data == "0") {
        toastr_success("OK bos !", "Upload file ke server di non-aktivkan");
      }
    },
    error: function (e) {},
  });
});

$("#testingDrive").on("click", function () {
  $.ajax({
    url: "/testingDrive",
    type: "GET",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    dataType: "json",
    success: function (data) {
      if (data.status == "1") {
        swal("Mantap !!!", data.pesan, "success");
      } else {
        swal("Maaf bos !!!", data.pesan, "warning");
      }
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#table-2").on("click", ".ubahAgendaSekolah", function () {
  id = $(this).data("idku");

  $.ajax({
    url: "/ambil/dataAgendaSekolah",
    type: "post",
    data: { id },
    dataType: "json",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      $("#ubahAgendaSekolah").modal("show");
      $("#utanggal").val(data.tanggal);
      $("#usampai").val(data.sampai);
      $("#uagenda").val(data.agenda);
      $("#utipe").val(data.tipe);
      $("#agendasekolah_id").val(data.agendasekolah_id);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#table-2").on("click", ".hapusAgendaSekolah", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/agendaSekolah",
        type: "post",
        data: { id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-4").on("click", ".hapusGaleri", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  swal({
    title: "Sudah yakin bos ?",
    text: "Menghapus data " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: "/hapus/galeri",
        type: "post",
        data: { id, nama },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          toastr_success("Mantap ..!", data + " berhasil dihapus Bos ...");
          setTimeout(() => {
            location.reload();
          }, 4000);
        },
        error: function (e) {
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Sepertinya coba tanyakan ke polsek Bos ... "
          );
        },
      });
    } else {
      swal("Ok lah kalo gak jadi,, !");
    }
  });
});

$("#table-2").on("click", ".detailabsenpdkbm", function () {
  id = $(this).data("idku");
  nama = $(this).data("nama");

  $.ajax({
    url: "/ambil/detailabsenpdkbm",
    type: "post",
    data: { id },
    headers: { "X-Requested-With": "XMLHttpRequest" },
    success: function (data) {
      // console.log(data);
      $("#modalDetailAbsenPdKbm").modal("show");
      $("#namanya").html(nama);
      $("#idpddetail").val(id);
      $("#tampildetailabsenpdkbm").html(data);
    },
    error: function (e) {
      toastr_error(
        "Waduu ..! Ada kesalahan sistem",
        "Silakan hubungi puskesmas terdekat Bos ... "
      );
    },
  });
});

$("#cetakdetailabsensikbm").on("click", function () {
  peserta_didik_id = $("#idpddetail").val();
  window.open("/cetakdetailabsenpdkbm/" + peserta_didik_id, "_blank");
});

$("#table-2").on("click", ".lihatberkaspd", function () {
  berkaspd_id = $(this).data("berkaspd_id");

  $.ajax({
    url: "/ambil/berkaspd",
    type: "POST",
    headers: {
      "X-Requested-With": "XMLHttpRequest",
    },
    data: {
      berkaspd_id,
    },
    success: function (data) {
      if (data.url) {
        $("#tampilberkaspdf").attr("src", data.url);
        setTimeout(() => {
          $("#tampilBerkas").modal("show");
        }, 1000);
      } else {
        console.error("Gagal mengambil URL file");
      }
    },
    error: function (e) {
      console.log(e);
    },
  });
});

$("#simpanDataBerkasPd").on("click", function () {
  nama_berkas = $("#nama_berkas").val();
  jenis = $("#jenis").val();

  if (nama_berkas != "" && jenis != "") {
    $.ajax({
      url: "/tambahDataBerkasPd",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { nama_berkas, jenis },
      success: function (data) {
        if (data === "1") {
          toastr_success("Ok bos", "Data berhasil disimpan");
        } else {
          toastr_error("Maaf ", "Data gagal disimpan");
        }
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
    toastr_error("Maaf ", "Data tidak lengkap !");
  }
});

$("#modalTambahBerkasPd").on("hidden.bs.modal", function () {
  window.location.reload();
});

$("#table-3").on("click", ".hapusjenisberkaspd", function () {
  jenisberkas_id = $(this).data("id");
  nama_berkas = $(this).data("nama");

  swal({
    title: "Sudah yakin menghapus data " + nama_berkas + " !",
    text: "Aksi ini juga menghapus seluruh file " + nama_berkas + " !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusjenisberkaspd",
        type: "post",
        data: { jenisberkas_id },
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#table-2").on("click", ".copyAnggotanya", function () {
  kelas_id = $(this).data("idku");
  $("#modalPilihAnggota").modal("show");
  $.ajax({
    url: "/tampilKelasYgLalu",
    type: "POST",
    headers: { "X-Requested-With": "XMLHttpRequest" },
    data: { kelas_id },
    dataType: "json",
    success: function (data) {
      // console.log(data);
      $("#tampilKelasSemesterLalu").html(data.html);
      $("#rommbongan_belajar_id").val(data.rombongan_belajar_id);
    },
    error: function (e) {
      console.log(e);
    },
  });
});


$("#table-2").on("click", ".hapusPesertaKegiatan", function() {
    pdid = $(this).data('id');
    nama = $(this).data('nama');

    swal({
    title: "",
    text: "Anda akan menghapus data " + nama + " dari peserta terjadwal !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusPesertaKegiatan",
        type: "post",
        data: { pdid},
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });

});

$(function(){
    function validasiNilai(){
        let istimewa = $("#istimewa").val();
        let baik     = $("#baik").val();
        let cukup    = $("#cukup").val();

        // cek apakah ketiganya sudah terisi
        if(istimewa !== "" && baik !== "" && cukup !== ""){
            istimewa = parseInt(istimewa);
            baik     = parseInt(baik);
            cukup    = parseInt(cukup);

            if(cukup >= baik || baik >= istimewa){
                toastr_error(
                  "Waduu ..! Ada kesalahan sistem",
                  "Nilai harus sesuai: Cukup < Baik < Istimewa"
                );
                $("#simpanAturBangun").attr("disabled", "disabled")
            } else {
              $("#simpanAturBangun").removeAttr("disabled")
            }
        }
    }
    $("#istimewa, #baik, #cukup").on("change", function(){
        validasiNilai();
    });
});

$("#table-2").on("click", ".lihatDetailBangun", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailBangunPagi/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailBangunPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailBangunPagiPd/"+peserta_didik_id;
  
});

$("#table-2").on("click", ".unduhJurnalGkihPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalGkihPd/"+peserta_didik_id;
  
});

$("#table-2").on("click", ".unduhJurnalGkihKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalGkihKelas/"+kelas_id;
});


$("#btnAturListIbadah").on("click", function() {
  agama = $("#agama").val()
  if (agama != '') {
    $.ajax({
      url: "/ambilTabelSetListAgama",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { agama },
      success: function (data) {
        // console.log(data);
        $("#tampilSetIbadah").html(data);
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
      toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
  }
});

$("#tampilSetIbadah").on("click",".btnHapusListIbadahRutin", function() {
  let btn = $(this); // simpan referensi tombol
  let id = btn.data('id');
  let nama = btn.data('nama');

  swal({
    title: "",
    text: nama+" akan dihapus dari daftar !",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusIbadahRutin",
        type: "post",
        data: {id},
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          // console.log(data);
          if (data == '2') {
            toastr_error(
                "Maaf ..! Ada kesalahan sistem",
                "Data ini berkorelasi dengan tabel beribadah "
              );
          }
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
            
            // hapus baris tanpa reload
            btn.closest("tr").remove(); 
            // kalau bukan tabel, bisa pakai .closest(".nama-class-container").remove();
          }

        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });
});

$("#tampilSetIbadah").on("click", "#btnTambahIbadahRutin", function() {
  $("#modalTambahListIbadah").modal("show");
  agama = $("#agama").val()
  $("#agm").html(agama)
});

$("#btnProsesTambahIbadah").on("click", function() {
 agama = $("#agama").val()
ibadah = $("#ibd").val()
urutan = $("#urutan").val()

  if (agama != '' && urutan !='') {
    $.ajax({
      url: "/prosesTambahListIbadah",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { agama, ibadah, urutan},
      success: function (data) {
        if (data != '0') {
          toastr_success("Mantap", "Ibadah "+data+" berhasil berhasil ditambah");
           // Reload tabel agar sinkron dengan database
          $.ajax({
            url: "/ambilTabelSetListAgama",
            type: "POST",
            headers: { "X-Requested-With": "XMLHttpRequest" },
            data: { agama },
            success: function (tableData) {
              $("#tampilSetIbadah").html(tableData);
            }
          });
        } else {
          toastr_error(
            "Maaf..",
            "Sudah ada data ibadah tersebut "
          );
        }
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
      toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
  }
});

$("#tampilSetIbadah").on("click",".btnUbahIbadahRutin", function() {
  let id = $(this).data('id');

   $.ajax({
      url: "/ambilEditListIbadah",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { id },
      dataType: 'json',
      success: function (data) {
        $("#modalUbahIbadahRutin").modal("show");
        $("#ibadahnyaa").val(data.ibadah)
        $("#statusnya").val(data.status)
        $("#urutannya").val(data.urutan)
        $("#idnyaa").val(data.id)     
      }
    });
});

$("#btnProsesSimpanUbahIbadah").on("click", function() {
  ibadah = $("#ibadahnyaa").val()
  aktiv = $("#statusnya").val()
  id = $("#idnyaa").val()
  agama = $("#agama").val()
  urutan = $("#urutannya").val()

  if (ibadah != '') {
    $.ajax({
      url: "/prosesUbahListIbadah",
      type: "POST",
      headers: { "X-Requested-With": "XMLHttpRequest" },
      data: { ibadah, aktiv, id, agama, urutan },
      success: function (data) {
        if (data != '0') {
          toastr_success("Mantap", "Ibadah "+data+" berhasil berhasil diubah");
           // Reload tabel agar sinkron dengan database
          $.ajax({
            url: "/ambilTabelSetListAgama",
            type: "POST",
            headers: { "X-Requested-With": "XMLHttpRequest" },
            data: { agama },
            success: function (tableData) {
              $("#tampilSetIbadah").html(tableData);
            }
          });
        } else {
          toastr_error(
            "Maaf..",
            "Sudah ada data ibadah tersebut "
          );
        }
      },
      error: function (e) {
        console.log(e);
      },
    });
  } else {
      toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
  }
});

$("#table-2").on("click", ".lihatDetailBeribadah", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailBeribadah/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailIbadahPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailIbadahPd/"+peserta_didik_id;
  
});

$("#table-2").on("click", ".unduhJurnalBeribadahKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalBeribadahKelas/"+kelas_id;
});

$("#table-2").on("click", ".unduhJurnalIbadahPd", function() {
  pd_id = $(this).data('id');
  document.location.href = "/unduhJurnalIbadahPd/"+pd_id;
});

$("#table-2").on("click", ".lihatDetailOlahraga", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailOlahraga/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailOlahragaPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailOlahragaPd/"+peserta_didik_id;
  
});

$("#table-2").on("click", ".hapusJurnalOlahragaPd", function() {
    id = $(this).data('id');
    nama = $(this).data('nama');

    swal({
    title: "",
    text: "Anda akan menghapus data tanggal " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusJurnalOlahragaPd",
        type: "post",
        data: {id},
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });

});

$("#hapusOlahragaTerpilih").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/olahragaTerpilih",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Data olahraga " + data + " berhasil dihapus Bos ..."
              );
            },
            error: function(e) {
              console.log(e);
            }
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#table-2").on("click", ".unduhJurnalOlahragaKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalOlahragaKelas/"+kelas_id;
});

$("#table-2").on("click", ".unduhJurnalOlahragaPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalOlahragaPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailMakan", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailMakan/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailMakanPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailMakanPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".hapusJurnalMakanPd", function() {
    id = $(this).data('id');
    nama = $(this).data('nama');
    swal({
    title: "",
    text: "Anda akan menghapus data tanggal " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusJurnalMakanPd",
        type: "post",
        data: {id},
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });

});

$("#hapusMakanTerpilih").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/makanTerpilih",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Data " + data + " berhasil dihapus Bos ..."
              );
            },
            error: function(e) {
              console.log(e);
            }
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#table-2").on("click", ".unduhJurnalMakanKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalMakanKelas/"+kelas_id;
});

$("#table-2").on("click", ".unduhJurnalMakanPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalMakanPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailBelajar", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailBelajar/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailBelajarPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailBelajarPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".hapusJurnalBelajarPd", function() {
    id = $(this).data('id');
    nama = $(this).data('nama');
    swal({
    title: "",
    text: "Anda akan menghapus data tanggal " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusJurnalBelajarPd",
        type: "post",
        data: {id},
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });

});

$("#hapusBelajarTerpilih").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/belajarTerpilih",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Data " + data + " berhasil dihapus Bos ..."
              );
            },
            error: function(e) {
              console.log(e);
            }
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#table-2").on("click", ".unduhJurnalBelajarKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalBelajarKelas/"+kelas_id;
});

$("#table-2").on("click", ".unduhJurnalBelajarPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalBelajarPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailBermasyarakat", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailBermasyarakat/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailBermasyarakatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailBermasyarakatPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".hapusJurnalBermasyarakataPd", function() {
    id = $(this).data('id');
    nama = $(this).data('nama');
    swal({
    title: "",
    text: "Anda akan menghapus data tanggal " + nama,
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then((yakin) => {
    if (yakin) {
      $.ajax({
        url: "/hapusJurnalBermasyarakataPd",
        type: "post",
        data: {id},
        headers: { "X-Requested-With": "XMLHttpRequest" },
        success: function (data) {
          console.log(data);
          if (data == "1") {
            toastr_success("Mantap", "Data berhasil dihapus");
          }
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        },
        error: function (e) {
          console.log(e);
          toastr_error(
            "Waduu ..! Ada kesalahan sistem",
            "Silakan hubungi puskesmas terdekat Bos ... "
          );
        },
      });
    } else {
      swal("Pikir-pikir lagi yaa,, !");
    }
  });

});

$("#hapusBermasyarakatTerpilih").on("click", function () {
  jml = $(".checker:checked").length;

  if (jml > 0) {
    swal({
      title: "Sudah yakin bos ?",
      text: "Menghapus " + jml + " data yang terpilih",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        $(".checker:checked").each(function () {
          id = $(this).data("idku");
          $.ajax({
            url: "/hapus/bermasyarakatTerpilih",
            type: "POST",
            data: { id },
            headers: { "X-Requested-With": "XMLHttpRequest" },
            success: function (data) {
              toastr_success(
                "Mantap ..!",
                "Data " + data + " berhasil dihapus Bos ..."
              );
            },
            error: function(e) {
              console.log(e);
            }
          }).done(function () {
            setTimeout(() => {
              location.reload();
            }, 4000);
          });
        });
      } else {
        swal("Ok lah kalo gak jadi,, !");
      }
    });
  } else {
    swal("Bangun bos !!!", "Pilih dulu datanya", "warning");
  }
});

$("#table-2").on("click", ".unduhJurnalBermasyarakatKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalBermasyarakatKelas/"+kelas_id;
});

$("#table-2").on("click", ".unduhJurnalBermasyarakatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalBermasyarakatPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".lihatDetailTidurCepat", function() {
  kelas_id = $(this).data('id');
  document.location.href = "lihatDetailTidurCepat/"+kelas_id;
});

$("#table-2").on("click", ".lihatDetailTidurCepatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/home/lihatDetailTidurCepatPd/"+peserta_didik_id;
});

$("#table-2").on("click", ".unduhJurnalTidurCepatKelas", function() {
  kelas_id = $(this).data('id');
  document.location.href = "/unduhJurnalTidurCepatKelas/"+kelas_id;
});

$("#table-2").on("click", ".unduhJurnalTidurCepatPd", function() {
  peserta_didik_id = $(this).data('id');
  document.location.href = "/unduhJurnalTidurCepatPd/"+peserta_didik_id;
});

// BARU 2.6