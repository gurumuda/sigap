<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPorCE3Fza804+Fwj432I6JHy+Gnemf8Du+04NeIzihMpdpqWkU5ksW9FjeF1BIRxjq1Xi3fH
MGssMKkpU1uBnuIu+/rLouvnFJt4/jTopQMpNs78+bWnbfjuDCvNt0X2AO0rmfLbtdB3lULvl2y2
AvalfTiMH7QfBITb2Ww5ig1navrSak9b60epjESd4KsjpdkrKoVXaFDs42qo6tQA/PdLP22UvB7d
VdG7BSXSlkt9tDHlXtpTPcP8O458PIt4PZTguojx9Q1/WUdxtap3hmfxisDDQCJKNBNuo7mSQUoc
eBBSHVykrw74HGDWDnqlJZ0vziyxojKgwrLx0LMVChzuYkZAV9GFd7s3fvGOQH/1wDTj6L+TJEFs
2wl//X8ssSputKigtGeffZ2OgZHbVy1OFK2Ynpy12GtJwXHIoNDNxaDpzjeP9+tgveiCN/qsRQ3g
aXPMr1oAAfp6merDFzts9+QnM90slsNY/+AmVVrbr5E+O9SWDs9/zhMvMyXt6eGpnivKWO8TqOdc
TAl0Bt17A+BTZy6jd9BvZm+ZBiuaaPWl9EBjgeGKa+nDT55VayscGnfCqYmLUgGJkla2OfUOyHPi
kbYWRsDYxjtLcKIyrOb7Aajq/RdNDXbkXCjq68dVmCP+/tAda4GJhy6UbMBYdBsC0K6FhGs4xB5Z
ADvpjw+s79xvTS/iyTPJ3NEmXgAFi+i5Fo2W/h7SsWQT/zg78yYYrRwLdb2c78V4tPHfXDpfQEx/
6YRLiX4geRu6178jhgd3Vu0H9Sl1gyCLuPsJXIDjSDCvfUcw789M1WDx79a/bMveb6FyYFE1j7N0
TIFRTgKOqMJQQ8DOX25aCbp+xMTFWkqhDs+rRyihqQSGdyK8ZTpkhrYaAbiL2KmGLNiExRkfUvXn
mS7kmMTYHk2ONvw2LsA0hrbWVA23tw/QEco3SMNWQk+zunOOnSRj1eLKKyDrmQXCvsuJhG21yV2y
9vwk9rh/CoOwP/fftZeCoDjXdXcIYPgwKC+zt31RDw+jkd62LPAtLNSbKSpFWdMsH7LvM4pFXh+i
rchxL1NCvrQZiyaAACopeIhX39dOaBdx8wEUTDF5t53zgBDgc19HUtW4xwYrW6sgNtn2HTZeP2ry
ceLXlVmYbr2WjjxRAmvRMxHx2dNgHJWbfzuSz9Za+a12yuh2PEFASvD53JkYNRBKOvjuloMltGxC
8PoEOcnZVSrJN/n1ZM06d5nM9/n3x/H1LinIb1Mn+nw1iDj+eNeOHk02xIXBxO9x/yYd/iXyYSWX
oqSCvC8PI7K9aG+TzumhoV3SEYH3j5OAa15PZb5tPOTaSlz3rckw2jNLtyXxvesl53zPk+t3QnWQ
S7MYViETnfvoB7Sudy/HOwy+ZnWp/xSXsM+S43WBvHx+lrDUMPX+9od/mHSFYbpxZhnJ+WywKfD1
ZhCMfXcdrwFlH7gDz4YAX/rtsB/l6PAhCiQjoDwmz+CoUDj8ZLaNDSjq+WvM6LLdGA3NHIZthTfV
fBfQjSUl0K4PK4NKWFqjLzQfVaFF4fY54kzbDSnGX7sgfNlaP0kVaZVLvapwHaY2g5U9GVMjPnj+
72kKleX2QIiDp9dueRY5AoQoZrY5ftm0JquIr8m6RyiNvp7k64F6qxvr5FAnnYjg/JgpI/A6WY8a
e+yL0y4zMqk9JEkW2SAUqwHY35MfFnk2FzuErHRMvWSuDuVXxGUP14QqDutoc09CHhB+WjOmQgxD
gbnS641l238HJEUNBG4HqEo0viZTqubOpV2RXeJ1+HvCC+pMYeiootYTSKvwLv3x34UWbQq8bFG1
NZ3JzAEPqmg9A2+1UyOa8sQ5mIt1DjBN7Y1ig5QWeUxt3kbsCe6DwUgi0st46IKBXq9GMwAEjjG5
8YTO3vPrxgUdpt+33vQQkaghGiPCHueOo4olAK4C1wufc/awDpqtQnYMhzSXzmwl0K+jM+UEpn0e
DZZkDceRv885a+zObVQbfEXA7fDIPI4v9QxjzZ2FeYuSGd7dJF0ab5zpanXTNhDykR/R+eou8jqZ
nm8BQRl8ffjK1u2kxkEMIXcjSknUf9Kquu6lJglebbJaiDCb5gqMWisrWZG9Wi03wIQEPJhoTyBZ
N3jUKwndSbLYD/Lt6ykvYinxivtaBeWUVxIAYSxMfNLotvcV3wDTyLAH49/b1elc3OF3wclfyoh6
LyCQxNw9h30qfnw14b7cM56J6pVbTe/+kpg5w1jgrBwkQS/ytM8Ae66kFRMA3SxDVMtH0BCidfC/
DR4xguDoFQ4IT7A4YPxst8Hf2LserzlK1v8NoBW+wn55vDTdWa/cjuVelzUz/yEHI609G1YXoEIx
0t6qDw6SLF8vxgXUzWtCEMnb474Le2Y+38nJYYurtn+F/tieUGY8EUZ6IUxbJ1ozMEtexQcxYThX
tggKrZQjYdOAkTfrnLTO8/5ppclhlP3o31PFLAwxu8Utohp7uW6dfWUDgVB+NUF0JFQEsUwENYGQ
7z2RFokJHAO+FmwParoI183b00FzjdDY1ip2pF1vmi2fOqzjFZwPcCrUmWaQrwntiVWB41XnQK0C
hfnzWDn4R3CFTAcc76FTHDJXjG0lwALzVqiL+rTb/zzUTIe+VMor72Kou3Pc7vs5AmgK8xetXzFP
HbAmWsa3UcWiaGSK9lpXJqetGr/HWVO6jy8ULf46IaZjMxKIfBZSfkgM6EuFoMf+ae18EuRewA5W
ji8NsuY2R9rOekTjErkzz/f6g8rlIqn2IEYvZJBG7XFBFc9jf/1Eu0hHdiAHbsMlDwidJ7cjGl6O
B0y2sG2QtRJR4c8iJWC3vJMFDOoAWeLJfRh4sDZKH+FX7GlyJYtIlwbmrL/PVGiNedhPrrYxoOKF
t0u9xY5ZkVmJqD8m+Ixa33q+3d1qVMfakoFZYdy=