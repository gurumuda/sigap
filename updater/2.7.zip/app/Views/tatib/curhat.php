<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPv3mDeU4N8keKK6ZfCsWKsqqeAOWoBIwEwEuEgYJxHf/kMUUGEMxwvlXXf5lqrUbtgKNHU3u
DwAzzqHNpUeR/PivUXpoDFDaCHx6buoCAgU3TL+q2uWgOQSmLmW0k8wX5pLFPAIBTc3yKnDXyZ4W
k/ZiY4AlvJxOOxxBu+hAJyV/Gv2Abg6ja2opPCB+jDfF+EI5M4/UPH0wUdt3agweGiJCWRAZl6/o
OFMIh9kOa6OJwOLS+xjs7d3lVk76WKehxvhPAtibe7+1wVlUJCEl2dkpOpbplh29k1nZNA/UTQOW
jT1l/zFxiBvcMMpZnTzXeOfp3ODKhU69ZrGcvGkGnnpFNGVI+SBBQ8ALvQ9+oRJbexJ5AoFLMBeT
fNRMMrFn52gNNQJvgWGKaNPAogDEV7rH+igw1xPGadZuZIIfhbOp1RLAG385EMHwHLc/JQG+fVSD
+GQ9suoWs2hGWvzYSuAhnrzDzRvSjyg7G8HJZOcLKnYsamPg0CpLExeWuBzHyeJ8JpSxdE+TGszP
FpwZNyQcJdGDesaQcrrVv5hXU2uf0x76caDcpIYoTbMcX47g3ywADy9rLd+xpIt9eLIYrMmgJESO
nsgZ/hUzZMUW5+TmhjnNFycsZnAMP1fUu3s+XN3FStQFyHZm48eNyYKuEb/r2xfAtSUFjg+VXQHV
oJ57gvrtyPXp770SjpTtRC7EWSInsijuucBqDFokXxxhUEICsBUvzsX9ZSSqlyaFhkOOejkkCLit
R/XhwxA95LODXV1Q0bS2Ta8G0uRoRyOWNsAbyL2F0FUjVz4jyvlHfa5oPqMEvfEMnB/8KHl5Z5Ri
B8bK8okMHMnlmSac7NtvtpuWkfI/7HA2dvmVJTER9acO/23uWmsgMcaMdhdvbrMKMSLuy9pIPf7+
jsKUVD0Hr1QbahQ0oSbg1vYb0xKUQIM01xfXQhPHPN27j+TG54eTeOelnz7MihWNxPbjBk8t6XTW
Oucr/Fd8MV/NIYN//qowJxX4GyhmYfjlMoaHcYwDR6usHFNFsp3clFz/iRHjXjAtdhdXaRdBFfaa
TG7hBqC5obm7UOgrXYaut1HnQX4j+7xCpI+u6gY/7APkMgPD75Qm1iuTth5Dpn7Ro99J/BxuCfuM
E/iLSTbxemWKWdiX/rWzhZNKT8yEKGHPHjIf8YNPtF/ABRm8vFnWmBYX3dXAy9rlJmVvrgc2o4e4
AF9DvcBcVYqToMDUmnoN84mdzX2cTfM4XuscLer3PiCDh6HDRHkgMMTXrgVwmHpY90e7ijsg39n7
4toNuV5iLm1LTbJZVNHMhKojMnsqh/QYBgHC9lv45Vx2Lxy8//cozMwgKSiS/KJ08ezZR6u+YFai
mVoiXBw9Cm2CjljX99rOJnYqWEu1TS58iP1BaNfntWjMIW5SBu1/tdNyJi0zYTzVLEvV3LiB5Kx4
lFnfxH68fp/SxsLtStAogOOW6dj0pd5S19Rh5eLRWHfkE19UZOlY++OSgzv/v3DaftCZdFRVGhJr
Gf51e1q9CTA8eW195c/GHHG/+t56h/sFj1MSpguluhgMTRe2QIij+L4WLdlMvVtd0/XsNDBzj4rp
Ek+EuwTjpEHBOhOU5A4vkTOvzblTU6PJCIUhfvWhsW7IaPETFqVvLv+HDBBD7f0hyKx9MPwLrsMZ
AVkKWB7Ma7mZy45jBOJsDSsYYqwSD9YuvM1Z2hfYa2i/5zjzeRvmJwkbOvUS+rlRqPyOzyorOSKb
SwNuPC2s+2tImhiblc9P+ybJSe/rR5ZWQwupqwgYCIPB8b24s6xNet3XBGrG+KHh4U9U2/QEYSND
e1Vs0p1TMihmqW983FpVFzsk9FOucj1/34jQHd+2tmZkuPhndvB0kvevjLSgfWau9VGl9vslXlbr
Y/Tj2rFmVLbv9f+Bfi9gqUk/3jvll6Vb9H5MZ0UgbC5oB+V65mCkjVLq98Te6tr9SldJBvXOJ9V/
HaG07nGHelLKo4mgZM22ZO49ai8kHM5NIJei4FAIzRqBaFlpkoIF8P0YHcPSL9J9WqscrZPE5MMe
1tGftX98nfrCL+wK71qLH7GSj6REhVXOb+HHoPwGsrKS8u1dayBt71CnZiVXwssIgFzVjycvTOcn
JEgPpLyrkxb0JKkHKj2GqQHJ6NJzY9iYLB9KLBFt58AxsOehs5L94LQ3OVBOws6QY8khTjyqcSvw
+HDY7hoNqXV/g9pWnf21rsjkcFAyShoIcgQ5stpw9lljyqKrBHj6xyYmyuoUOwU1E3Vp1TCAfImi
dM+M41iE9RqxUlLeSxouu+dtBw5wQOVba738eEQmqs3Tba7VwD5l+u+eIC7bYhdZ4dPr9JzbI0eV
b5C62tcAeVDSoaeg1k47g/e1L4daODOWSr6+xpiwN7RotWMiNjFlNJwXx1lBbzNvIp4DJyy6XstJ
9Dq6LsRciTM9c5f5/hOXNQ7f8G3U69t30vc5e5U3fRBWEOjtos4CuSPkWggHmCvXmBSW4BZE9GK8
OpyT02gSlalQ4HTZ9sFkJQz6GAmTpAUInvyWx6UpaJiJCXfbwDC0/wjaIGkW6zE0WmXU0uMbYN1z
Z2dHN4MczNYEkKASPM000RO9QX9i