<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPnpoCiA7KuVrNZwduVvVWWADnl8DaOfWV+m9wYBTaICjaBq+y8D3BvpR0wzwdi2B1dZo8KXS
p9icPofFQ7WPKXZUKZZECBR70BM0GLiuHGpbdphqHiYf/j3t7RWDVcAUUnezHULsb7S+JfqO2UjP
iXppQz8Q/p31ErUia0gqe5VCi4xVSc1JcFpaTvdYY3BekSeejrYk7gRhrxMfZMtexsOktuCOyDF/
VT8PskKjae1a7XwN9ZwidF8lakUduU76Ts8cv8WGAtibe7+1wVlUJCEl2dkpOxLj78P1o1sWcwyp
PAOWXFLWdc1lbrUJnS3kYfxo4O/wQKeDjJUDhbzlNzDMubrdlVtYPXPRf5VHTgn+OsFSBtk1xDXe
QBpkEQ7pn++MO0q9jAQt8v0r23/4rq+MdNxCAkuD+4Hn7Kfns0QRCd2csdQaZI9wjASZkyxsXizK
0Q4jNs80x8wWRdQrLTCG5DijJGBdYTOXRxT+Oj1hQeh3/3zj1f0OdHGazVLww6vqLJAlW8T3B0aR
6ifJ0uXphHXQ+1LKH1M2YeZqHgjrdz4Aiz9ts/1zKHkX/raZwKzSssx/W/uCCzJxT+FAg8Dsqpdp
ve0Opn9yI/1segXazcg5JxuqGBpHDKDX6Yc34t1EYeIkNGcRUfIAd7z7aLQD36skTy9JhFONDEMd
udU6MrVHxdHUTrIah2AldU6O11HSuPrvMx+fODX9t9+0Sem/QnNbuihoUHB/TDuULozKXZUkYLYV
9K+ttwbPj9IDj9MKHTmjO6Yz80j1cF7Lm2fFWnSjh+dosvTsy6/TPBswNuzUnpTdHaeUBKoHYQod
NSEdtY7XOAf38qWsxsxhgyoznb51DDYnS/RFxKP3vbjR/whjfpBpooe9KXsFKFMXYMwTz3bMMV5t
hekVsivW0QmYrzAM9go+8LQn1RQ0X4S1dUvQ/E2kDZkvZ7PsVKTA7OYzSP7mVozw+xEgQtcs1sD+
dqCaJvKKxsxtfTm75wv2SvhRh628YI/WYjmYFKAe17A9ABRkOXp40c5w9TY7HuEjJRaiYEnoDPU9
IuVH0CCkSD8DsSLk5WZ1Nd5iqcQR/tZySl80YOEFlYpic8LC4ig2eSME1WHDgNM5gkf3c1Y5NxBN
zKiW/dU5Wp9sYcHSNVTmWjNKLvw9hiF5Y2jmCPlLimezbTVDLs7RavmJzkAaPIETgy87PlYrtCnD
a/nnP5mA3CofDUQLHQyTfhFcVzY3UQVQ2lu8IWTK7ZjRALhyi1LhX1mkcCRGs0SLHSxkWfducBLy
MHRNRpK0UOk4JNuKYHbQeDCw7dhPcfT7DH+qdgLqWfiXWOvL+Kzo/ssqGsIQ1K5+iMVKPfaFURts
q6y17x+Z9S/fvGJ0oFaadZQWRaelVF1mH0iS9B7Gby+88MZ7IM4gigGLN6nhQQnjVMKAxhaGlkAG
LDdjx+iBzHhp1n5DUWHahE9kP72JtG0fLAKFUplmG1v4/02h67TlMY+eG7tcqTJllDAU+0b+6Yu7
CTAOgBv17HY/SB3Rkk8CPwHCg+9oazvHsM5+1gKtt0WkTUnhG61GruFFfdHupXHRlrCCTCSB59uu
CKryh1OsYMng/Y9BeCwS0ds0UfmjmclAdHgmFmquXpzsRW/KcAEXCSG1Ju5+hMHFY+LJ2bUJ2FCe
ANVCon8s8LzteT11Zh0MRLRQt5FFaryLSfN9g1ZNOY3PPujH729hCIzsoYdcdtqMwTO8W3x5pALS
rIyb4+ZCQfUC10eghDgtyfZkxTYkr/tZ6mHqWGum5KPbWQLCbZI7twkGQiqgIG4WjlP39D6vvzyk
w5qZ6caTfqLW49eMTZ0MBHJ4MwAUCNef5JSlg3hSLzVCrD3rjsCiwM5tIPQE2Ak92nCHnA+utD06
I9rFdvYAbHo6710LGmbU5veYtJFWFHs1xlft6IrrwzmEu7BeLlbXagbwYzi5bdSlE057G0P+Lw9T
6BPE4FtTvUoLNjzthYSRhAEt8WHc+KS7XuHBGCxlhMieJXrlSTYpub2BHXpFDD/Bh78T0kJ3VVyS
XZZIy8AxHCOaQ4vzkRme4+lEnhA+nr+D6Tqx6K3hb6GswMQYU18ob0tsVOnj8UE0d9Xp/LKVNCWC
nP4PT+4dJL4Z+Ma6IY7MGgo8SVL8Wpuxtc6d6oErQQeddR8d6+XhtfgxVBCgDhDd+86GaWxlXsm4
2XwxtWAOIzp6M2rAInwxOIuEpWodMr7l5C8jlFgJgXQPVBjZfmFoVWICnEjVOZ7d/ZwGvtukzh2A
n6lDhe9C0biSd2fIPHNe2+lcsi5XxwfVQCgtGx8+GpRY28WbP572OcjCoFwQYmISndD9Q5tsL4v1
N2RdzrC3Yt66EJsjmexYNC9Bof28MEpV7fnS/uB3jnPs4hoiNOsXRCB3sS8xf5nlYdYbXvD27qA+
t+EkgTR0Y+iCNa2bJNNwZC6x+5b1YumsirA1O3W7PEhlyc9Xl7mwipSZtD4biYZkvivLXq10taGi
DyUIs+hR2fZrmTh0Qmj/uPYA75XYzEu5FQxGHWfTNLRcMyuvXhoFuuT4Ad7T15slYPqDzz3tceft
qVjEUze9xHXYLu1kMk0GRe6KWbBUFx9eRpWNa4BNuC8+anU5K4CGrtU401KIR3/9GESdk3WtUoVu
Kvp3PTP2eC6Q0YewnjUzz6SM8A9+m3ySsfst2Swx8PvbCxkmpc1a8IEJtb1PMatQsAlj2NGpk5x/
pRwiblTfO0htz4f1vCJyAmbiOa0Q4WGHT1GkoPlka48Ct4nWLvX84mZsq11sJkT4tRa+TLztoStd
T7xCisZACOdNNrGieZTXwFQBEM9vf3C2UZG3g+l5OLGVXv9zNIcKCVaAc/g2oX276MC0QDKjaq5b
UH03vMe+AYJ6WY5qcQCQfijrxrV+nsPr49w5qgDGT82U0RZEnjBZ1Bn0hAk6mRDd7CIZ/TYzto/U
+XgCIdyl3cNqJMv+sJJel0T0kKEzJyw+x2einPyQIP5ZaeF44Z0FHQFYp1/+95QfUOrRY8D4MDJJ
u6+gnCimlOR+49l1n79k9O2j4QlIPwo+UXt32lyCXom0MeSj7PB8zeoNRJElULT16sVF082LBNdM
KNlb2AEM6jCTVk0BmbQY3opV9BveoxkEXto4cnWhKh8bdNYKtjuVy9U4CwB3CBMCyVk38NUW+sNS
WM7cWhiF07FpZ0tHrxqBJr4dWSFTm81vvfSP9DUAsYxXH4ZG5A3z5m7hfu+9nbcQrPqMC+rbN7Gg
I+fZJzcI7cy2EJkIVlg8kj0F/809h3ecD+t1iPG4fMuS/sekEcdUq5uPdwSa+UXT/vpr4QbjZCk5
oPrVEo2XbD3zjT4en8ehFzSzSGckurGdArYHR7s9rr8a54DeVeVGYr/E2UWcSqwWt1FFK6ek56zm
2uvHzyGPm4xRxJZLa3Kky+TxDpgkO2j8PjkYb8vTYi/Ys5e7QVhpurg7Nz+r0xan7fCwCV7Tkru2
y14lmsxbe1Jxtc593NGJAd9cyfR+FopRP9Bi/XuqWBGfI68j9EdhjqiziKJJm1jn8ChkqCe6tE5/
P7oz6gcXIzKSVvA2QDqt/AHsIqGfYZWD07IfgNK6mvdP06cBzO/oDs/6OjwxwXTeYziXn7sl3Y7K
KWRl2Zfqm4Yr7ll/yZK5UwUIJq3nXtI1BSNXVizkzyuMqSTEi92ny8EZBwK2T1NuEut4CGO/00tN
cIJfHtEggZrAUBGzlQJK7E+UXbgV1qeogBKg2kMZKny9g0meQFyaSfNUdsKD20eIIszgNb9zl3uA
Mui=