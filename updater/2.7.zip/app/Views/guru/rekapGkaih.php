<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrWUuN4jpDb6AD9qKambawb/kzaKzZJjEw6uHulRBTpaA/ABrNHccg4Xce/iLaMRmZE/AFJG
KjgysgNKvIUPkldtjjZ7AElYNfgPd6oh1//QlSUA93AwP+lvnbWwA7Dew2CAx7d/kK4q5VN3xhPj
jOwWZODrgyj6VcezloGsOgRGLzFEyxAx+4DCKYwTWDfOM9nVtjjqUmmJD6Og644Ph8XWyK7ME0/N
L5ZQTQYI0zqcdtYbQuAoCb3LiGcTa0PVaNtxAtibe7+1wVlUJCEl2dkpOsDmBQKFTlPo/cxpRQQW
jD1V/xN10gWOul3CfuLnJBp0OqoAneBkqaIPgSGmmXMt9G3mZGLSRhs9Xw2ydP18uCGXwFAxEdov
YabMfNhsCfSEAU4Pf6n/kOcL5cYdempQT3NGTXsMEJgPPNQEwBkmWNSR+kc7VjdVY+ImnjjYbXV/
DWmcaBpSgc0LQQtvJpr8e0ngrhdV+TxlJe7tpC/vMfWXZASYS2cp6yT38BSvLGBkhkDua+h03Rum
4g6+nv2r+4hs4v/t2NToKvWNhzAX/BLfZ7wxfd9etvreRjgkSFobWMx5r60adbXp5ZM/aFLX8PvK
YjCnq+4j9kR0vbQ67Vjsfd+MuLhkM6r4n58dcpc3fYOcjCHJnlBBGGL64B/49BSpzLXw257nR2R6
yBjNNshF0H3mgxptWPM6zbR4W8jF7XZmXKpl9juGre1b0cLlkcCiQ61SDGEujoUlEyTXMo2WfYEL
thXn8dF6dZi0xfaflnk7sjfbh0rXiMy0u4lwmwTsmMVilm+lVAkc/gNiXG6zO1CPZ4bUE0uNiGAb
eTpnnAibZhHzrzbzMn1I+HDa47aFf78Q+0ZGQ9RfpAEAh0E0VdZDa3ahZZdkrQrgTYAPtMzzkv97
GrS/ZQLZXDWTtyFnC8sJ5ejlJy1Altt7i613BBF/vuuvhJejQvxCnRZd8POiNXE8qMZsf8dFuuT1
txngohbdkhgH5l+Uso748gH8sMhaI6SK1hdsfuu22Quop3TdhcH147nS02Z2CDUNzafgpruKB8lr
Nsky2jbPYWmwf66nJjYjhypKsL7HEk6EbHdvCq47KVfWTMS0rr/FaBsdVDqfKl+Lf8GzvW7Z840x
mslz0KNAcJ1TQfLVtjoEa5CdhmJjxaD1k0KwwjJf+iFWMBLssWxvShOL9viIPywHEoL1u+DcDIbo
TdQ2o45+6wkRa7UcnV57ltZDezQDhqdWZUXMiMRZALMAGRUWJ0dq12cddVNTPrwHUjMqiiyRsIG+
7a4fcBZ78lIIkPqojAP8/iKDu2H+dyiSf55pheVRXPgh+xSwNdyY9QkUBOlRSzpjEiwm4rtBobUd
pIjl91Ihmmpzl+2wbMmayjVZR7o2mKS9tdUKnkEG71rsXrLWpo6NbqUYGVvEntm32OeM4tqo1PwS
m+HFTx+8vX4Jktu3WYN8Qy2zpjdIYCmm8FhzTqyVTbOOpTBBYfm2VcNVNUJ4z9tgcdSbiAt9t/pK
7fJVo1eJNHRIxWQ5ceW6np9EC/fWPZwJPj6IZY7YYCTkCeJMCSPkzwnUgZtgW5Iwk8ggC9XHCG3g
gU/UQinXQgpoGBVgsn8voGZ46jgMDWDcaxloYhns3EzZxkZrdWWETGz8Wu2S4G1hUh8ac+ohQ2+j
0OGvFN0rKCBgLG115Vuf9Hx/rX2dbuMCBVZBt5VDacBh0XGJTnXqKqOpDFFpfvzm7UofG0OQMDij
+aea10PLILLuzwWr1KCieX39/GH0twqXpdi9p+3uz0Afcd4tfs2+QCuTB6fkhe+mT5igk2mUHfl5
XzxKTnFpXlzopsW7CwehvuW6ux/pPqDIrKcpRqXjI0ALvffVK7aZ60i+smpZoQnpy/wFvXhI8zFp
A7QCDXQWeETtqbHo9L84qwx5nUSKEQI/WEBqNfqgLfsQ4m4hs4Hbi6lybXAsD7wGkAE9QKWfwygD
UMHp5+WdzdJolJeaeYKjK2cIInQ4T50+7bj6IdiqvGndh5vrGZxoSGfgvsn/12QtYdXvByFJM5Ef
dGCxIEtKsO+RpKxbLzde1SjoMhP1k1GEnY5DWuI6BL8EPT8psVtyCyg664K1lZJGM67EUrI92OPN
7BDg4AnEf21fM8o5znMgDqnG96a8QmrUX/8mvcx88CZumgIm69VNh112euTGlq2/WRSGaOimFvpx
ZSLJXL8CeWmt1bu62bXEv4y4TYiA/OGvpVkr51UF5PKJAYv4GRCwbbq/YeFORXzZV/QFkY9CoHGe
7YGnn/sHRdwOSP8ghLdfSvcD2Xrg5Y1OsnrhKiyPMerMQmL6ZzuCMvuWXz/FMDaFYgNaJirtZnkP
VHpj8EO+23hcUx9j2GMNPLejnxg9bWW2SduiLLfAnZcHrT23IChfvIcA2xwwNiFGGCMR9BicJTst
bCx1U3btv2UwLhvdCPFgmXkfcIOsr5rrd6xsjny+EXdSGwmPuXXlU01Oq2TUG4sB+G0GBadSy7YI
0i6nZiiffdMpzJMRpzDFT2HxzzfWh/2EqOBq80Xjx/bP5bkVa82V9eDVLf3fWUNPUY7//WjYoPOV
FnSbglQ5qdJ9+xHjYX2TeG4B+58inxmmwavjClkOuy+vNXRzd9X0pGSDrQ0Phi/nqq+CETHM6wwk
VSihOA2+SUAD707wExydnYzLY35y8vzS7lxNCNILupUMDljqKRvtMd9clHTgH78LOQ2/j0TllAQ/
SdiPeJ3c9CXRtv5hx/F//KGIAETcyLYaMx5ruflQ8UM966PU5zyQH35wFryKxyLgKZbyCVQhMpHa
EHKC7WWdf1lzaraR52dwD8Dgl+YNpldBNL9pv7jpKciW7m3ZBqxCM5jYVnweUd/4urID+PDJQ4pK
jHooGhPbzTimr8olRMXYse1MeFCEdqKWgP7UeaAhpKIWfVzXq/Yg5Dm1OGM8kQRBkZhE/d7CnY+b
LYLl9F+/aHgpA9JchUzeAokwc/5E3vi0vVObAUvR0GeDb18zbzXgu8zQbext0GQvbvJubLsWupz4
XKDEScoyWQabGbkCjbZcaDDGPzY3AMLDq/9AGOz7JQZZ065SZUmWp6+JQWv/DEcLy/hvYzJAM8H3
GxxO1KR1CQdXVs7H1cKx0i4m2JjHoPEzBpdFedpCCWWaoAwpHcNHoysxxqlzGe0d5G2zuFTj6uFO
AhN/CmSaYiHbxLj/UA50RG9FW6HPAQA5LYVj8exA/ieS6Py/fGyLUNbfO6aMjVnpmJqADKm7MMTB
ev4RJOTOcT40S/xVbkMhhmZWCihUsiqGUy/DYPzBvVn7wU/dgD6CInpzZlPUMbLZoBmcbNqq3+p9
3qltfGFb/qGrfeKx5oWB2ccxvVqdT/RLHSSLLO0xihqjcHElcnQwhpdMyGrD3AlPGC9yJSYJ86bk
ArXTxrQsdEqt45jJuiPwDIeI4meSXOlvMnGAaXSzgc51xPeQ3H+5zVRAVRuKjBpkVcLJ3YLgNpTP
cnPEB+GOoR7SUydNAVDitroAFMUfuzsKj1twiidQDiXfSVFn20r3mtOZUuAq/pTvN33i2uhJ/JKf
LkTDVQRrrklCZH76d/Wji00H6k5AdAk/og0hQTfpFxQXXCCHb5Ai3CkCxy9tbriecOCk5NZ4hWao
VD84E3SOHjbPf7z/4raq5ZhBWaZsY8bpjx9JVHraOvcncaUS8p34uPa5DPpRvwrwucB+aN/+JNRo
/Wn4T7tqQBFfATAJN1eSaUzqxn01LFcnVFbGC520whsq5lwni85qC7RDbH4R19FRkyEth2OHLlkg
Stf/ifFhofVXMxstnuHPjOWYxoW=