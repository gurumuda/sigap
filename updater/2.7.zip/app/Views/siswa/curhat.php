<?php //00553
// Aplikasi SIGAP
// Developer : yuwandianto
// Guru SMAN 1 Jorong - Kalimantan Selatan
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtGNdtiKjsDyuTiAM9Gpg13sY2T/BUb4lyrdfZXrq2iQRFH2cNXMRDfaMo6uzcy7SykRXzon
A34/0B3eDT9cVL3zMOgwikq8dlxfINFMBUPWt/yrp2U0f/5o6/XW8HDhbjQbUym3fgFbqrmGfeGe
SQj0OcSrXAlTIqA9VA91URwwfju5R81F+ZZA4WRuUAgeUuplBs426Nq4+eszOxatJl8TeaOtmvaA
izMVO0NZw8NedWJISrA76GO4Y4v/ed6gt0TQJiJpAtibe7+1wVlUJCEl2dkpOubgQNlv9e9N2vw9
hQOWzi1w/nyNawlPY5qlah6R1K+OH7vXm/w3yyLLzNNcw7eMHGXyVyKcsU6AP6ntxPGU/b1h/KcW
0FVimELpiPqc315iT76/brxqjGg1A3Lg92mNP9/Mvs5HXrPbJa7kHhoB0HyGLLDzoj6zYUmuHDKs
EgNQeHc9aVSwIPB1PDfBom+TNPyp8aMiZuSaodHbZo/O3uWlrTyJrkM5styXaCyTY6XpPZ7GMFns
0XW0kqYKlXAgOn8ivqklaR56A/Pn4/Vuxu4n+JTo1ivRmuw2NAHU/8yBhVnYqogd+jfrh4fKyFze
D8Ti9CGGxgBNxkFE4Ab0pd6M5fXYBdQkg2puRjcUzP8OX7h/kRbvjUzLD2zBuccopIJZquHM5Fly
qG0LAnhRXK7BsiMafzLsS/EjghbT3WXhjbTvI229PSydL+euU/1hINTutzFmUsj1X3JoPhhqsX3/
CBmgFTkpuG/87v7jjDusy2iNDmXoNZeNoWZC0JjX8bjKpnaZdfm+dHIC2O/1b/T0R5C85e5u8AOD
bgcj9hzRaW6U1x2yTQQofmWCj96Kc6L1vMijuLNe8JIwienm8cbeMkeh06RRnaTkwQwueHPpPsKb
Ri3Yc9LK799uCytXuLIAf6G9Zy1/9w59q2UUKwJZlLpZv2djeTlCreswMjb03ZAfLfOct95l7tDZ
bMpwy10I7YJMurUjZLNl2jSOy3Lro9tdFn7eETKjBq2v5VRKmKWfyzIEhRoU5rNQv9HDHhVKeHOG
sFz+BeqAFK2W1vlyPTE2/UqQ4YM4FHRp78wE2V7w6C96LSixAh+vkfWHJhB+HkdgJkTmUeQFMUYR
8cHKuVeirE26ye0tQrSr5xHcfC1l3PE/X86+JMJDs00KL7ZKVP//UN0rhx7ycdORrwCrc0XBJ/Su
HZZyK6TYX7CGrYbyVqCdNxyC7GWt4Il+VSpwzmEK3N4JL/m9pLQu7jVWMcoXrARkg5d4dbhPSVbO
5J2F+i+ldDvkfFU/8yx+zVUjiP/aW4zzi/+mDhXKwOGxgikQGxmfQvgFkxj9d1rJqF4ihmzTODJX
MbqYQFLCVEgEHCTL7tIJQZUE2T+DU1gyaavoZfdeDGoC9J3I9mvLfx2uSWL3xjq3JR4tXmoMXPfj
6oRBUH91VqHvLRhXhBpr5rtSO8+RMO7nEiOInPhgVUl7YMn62gJVn4kLDdlBNfg6C522+EdfTqBN
USKZMGrZpenpjCyoqMYNJn0l5OrVqEVnn6x4gtgZwsAq+Le3udzReb737uEhiI14TtuscIRcyy0r
EIDiMZsI95eO2CuMUN/UvFwwZoO1zbqiM0g7gOr3gjtFo1HUkyyfvXYlbDBWHwaMzbpY0FhBufN4
qousin7Nrfiw6f2XBmLQDe/LbNvCmHcav6h8EABSB+vpzEqdVqqNm8jxTCo8A5GSbaxoiVHE4WS5
oQ/AgiHSaMWVJZIPvhANelg4dthnGp/dQR3FEANu9kUczLRYQPFGxPx+EhByO0V1Acp5/lg0Qksr
IFY/PavT77DndBV6CgoP5Cz5BXZCDv7ZViSaMp+aDQ7hz5JMvBh/haUPat47ql83dpKqT7rDxDUV
cmLvy515YYuMLxYuAcEGOjbdZGAA6nx1p9WflnSYOH0nqj/2UDxeBRrUeCdT8f2yiPEsd/TIq9Yl
msXYbCv3IcPcnyP1puNVhg4xeQbdgw8vdURTuQllmj2hk/ZZJJfQ3LCJZKsllZ+Pr2+EU/zvacfu
6ZMmZ4P4jnxn4iV65uisJS5t7pFxaKHX1xMGk8rIEW7QYLvBFYUpU9RMs1dPisjaIw7P+7BJG5x7
ISLAtADj9eBkNbcRuzl3bbQoRmicWva69zqM+NgiK3CaylnbSlJ8XHyLyZjkh0MKmS+H7iU7UdB1
Nva97onPrkQxhp7RLqADeVUTGe7W5vaSh/yeE1OQXxZFHbjhSeEhaYA3zYokMMTNAKv7sHgz0L3e
nI5rQ0hsflQ3uMqAnVJQSTm8oN5i99iLhrWxTGjDudz93jhl5ZdrXWI3eftNQiraC8PnVbg3vkqJ
lHZYqvrCoKO3GNPZ+nLYhtLyrGiTXHjZKWxuXXroGmtTrwIo+z1MCFWu6tqHmqctNNn7jgD6qnIQ
qn7GtfmV5vYErnDo1qw9hGEzzxwExFS65FumG9tP4dssBoow8v+zgn1jTrrPbQOXTkA3/OJzTN6G
HO6AzclnX6SPL8ezygy2jw+sNEL7LXDX9zTH5YtUpU6LByIhfpSLU778w+0YG2yfUsfGwK0DawB2
dHAbjMhCdpkqCOpvKg6lJTfrSTByItGrdGrs1MOz9fVkkq3EpcD1FZFGtIyCb9ibSakqsFZFBvLr
Apd0cTJQeGed3W2JuAalsoPbeLwR/Zigmt2bM55/5Qt8SmixeVcLPi7KM9ULSrPa0VF3EGWgGhLS
Usym89Ozy78BPFLYKtx6TWkg2j8OyPWov/l9bBC8v/i2FcQ1a4SpWjEg3yG5xOOzwGAZxAb0kVkA
0N71/CK2mFvT7awFzOG8WPzm/K3cmPP5CjK2n9NwGikMvCk9QxVjy0kkjg6TmOGj1LBUnjZpxdul
E0/knCcmTl8bVzGoMQlPY0ckn6pOkr46qopzlNjON8HGuTfxkNANCi9Ohk05qcpei92LI2q44LQJ
3n1RJvK6r0HjbSZpR0o1WjS4Bhx9xEy3lJOzltfOpyblrdp+/Omcf0M93g7wvm3GfDY5yf1W9M3H
0mwbwFY5TlGG39WQpDWq9H7qlW6EiqD5hJkTk0FjdEhhaz0zVbR/YcriVyWUuqA/+krTuSWsWiRB
WJGKxTOroeiFKk+gkwywkLLgB19BTfLRC8QUlFrMFefJTZPIIPztnHwkpeYLQvnIAzosUe6Gf4J/
kzV1YWmumuHPAKNbSBBnupADdJsRbFQB1y78xrcOsrrybX97SGH2Eb0iIIUBtDBbkVMteXiAvG59
6xZzYe97EfPPk50nJhU1erW1NAG1dhCdWjSgPxpCodDvsjJUUpEe+mWYLIfD6gSQXjxUK3RS/32N
t/38eX2KK16db7DUTCZdoFbs1zCE1G4nLTI1HYAl9kiXSq6Z//6ibWR8k6NJGchDBzPiyd9TnFtx
YXzbzQhNcmZ63Rx42cGX2xd0KqAFBHTfuSylD3V4xrJfblTnsr+a9NkrVmPJoCx1cKqWUDPxdv1r
tsb5g3U8FJNWXwo4/WQU+LJvgGGDxo/wXED91K+Ji+UifR7AjFWnrJtjWTA0SxGkl+AVp/hTj2yj
7XVn9fGXDw++4tIY411/o23UP7wlG0KtjOZ3omPy5SNDKS89YnY/zrj8xeReYbcs6HiXcI8sn6Wb
DyL8bVt/eIv+yLUl2iOlmJGSIaFn0cfU46wpXLn0fNi5wgK=